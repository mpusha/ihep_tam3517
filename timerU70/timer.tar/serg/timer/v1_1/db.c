
#include "/usr/usera/voevodin/EqContStation/sh_ccydalib/sh_ccydalib.h"
#include "db.h"

static struct itimerval newval;
static sigset_t maska;
static struct sigaction xa;



// столбцы таблицы M_PD_ECS_TTIM_CHAN, строк 24  - массив структур не идёт - размер структуры кратен 8
double cur_t[24], new_t[24];
char cur_OO[24], new_OO[24];
char cur_Strt[24], new_Strt[24];


struct Imita cur_par, new_par;
static char Cur_stat[4];         // строка таблицы M_PD_ECS_TTIM_STAT состоит из 1 элемента, строк 4
struct k_opis buf;
static short i, coord[4], was_err,first_run; // my_cy - якобы регистр состояния, was_err - код ошибки внутри большого цикла
static short tab_ids[num_of_tabs];
static unsigned int j, Nc, up_count;

static int time_wait(int ms)              // задержка в миллисекундах
{
  int sig;
  newval.it_value.tv_sec=ms/1000;        // секунды
  newval.it_value.tv_usec=ms%1000*1000;  // микросекунды
  if(setitimer(ITIMER_REAL,&newval,0)) {
      perror("setitimer");
      return(1);
    }
  if(sigwait(&maska,&sig)) {
    perror("sigwait");
    return(1);
  }
  newval.it_value.tv_sec=0;  
  newval.it_value.tv_usec=0; 
  if(setitimer(ITIMER_REAL,&newval,0))  // стоп таймер
  {
    perror("setitimer2");
    return(1);
  }
  return(0);
}
static void handler(int a)
{
  switch (a)
  {
    case SIGALRM:
    break;
  }
}

void set_state(short my_cy)   // по 4-м битам заполняет таблицу M_PD_ECS_TTIM_STAT
{
  int c;
  short k;
  if(my_cy & 8)
    Cur_stat[1]=0x85;        // Imitation
  else
    Cur_stat[1]=6;           // Работа
  if(my_cy & 4)
    Cur_stat[2]=0x84;        // Imitator error
  else
    Cur_stat[2]=2;           // -
  if(my_cy & 2)
    Cur_stat[0]=0x81;        // Ручной
  else
    Cur_stat[0]=0;           // Автом.
  if(my_cy & 1)
    Cur_stat[3]=0x83;        // Timer error
  else
    Cur_stat[3]=2;           // -

  coord[0]=coord[2]=coord[3]=1;
  coord[1]=4;
  i=sh_dwtb(Cur_stat ,sizeof(Cur_stat), coord, tab_ids[3]);  // M_PD_ECS_TTIM_STAT
  if(i<0) {
    printf("Ошибка %x записи в таблицу M_PD_ECS_TTIM_STAT\n",i);
	syslog(LOG_NOTICE,"Ошибка %x записи в таблицу M_PD_ECS_WB_STAT\n",i);
    was_err=i;
  }
  if(!was_err) 
    sh_put_meas_er(0);     // сообщаю о нормальном состоянии системы
  else
    sh_put_meas_er(was_err);
}

int db_init(void)
{
  int db_status=0;
  
  newval.it_interval.tv_sec=0;
  newval.it_interval.tv_usec=0;
  newval.it_value.tv_sec=0;
  newval.it_value.tv_usec=0;
  if(setitimer(ITIMER_REAL,&newval,0)) {
    syslog(LOG_NOTICE,":test:setitimer:%s\n",strerror(errno));
    perror("setitimer");
	sleep(1);
    return(EXIT_FAILURE);
  }
  if(sigemptyset(&maska))          // SIGALRM используется с таймерами
  {
    syslog(LOG_NOTICE,":test:sigemptyset:%s\n",strerror(errno));
    perror("sigemptyset");
    sleep(1);
    return(EXIT_FAILURE);
  }
  if(sigaddset(&maska,SIGALRM))
  {
    syslog(LOG_NOTICE,":test:sigaddset:%s\n",strerror(errno));
    perror("sigaddset");
	sleep(1);
    return(EXIT_FAILURE);
  } 
  xa.sa_handler=handler;
  xa.sa_flags=SA_RESTART;
  if(sigaction(SIGALRM,&xa,NULL))  // set handler
  {
    syslog(LOG_NOTICE,":test:sigaction:%s\n",strerror(errno));
    perror("sigaction");
    sleep(1);
    return(EXIT_FAILURE);
  }

  if(i=API_ECSini())  // инициализация связи со связной программой
  {
    printf("Error in call API_ECSini = %d\n", i);
    if(i=API_ECSini()) {
       syslog(LOG_NOTICE,":test:Second error in call API_ECSini = %d\n", i);
       printf("Second errorin call API_ECSini = %d\n", i);
       sleep(1);
       return(EXIT_FAILURE);
    }
  }
  for(j=0;j<num_of_tabs;j++)  // открыть все таблицы
  {
    i=sh_optb(tb_names[j]);
    if(i<0) {
      tab_ids[j]=0;
      sh_put_meas_er(i);   // код ошибки
      sh_put_data_er(i);
	  syslog(LOG_NOTICE,"Ошибка %x открытия таблицы %s\n",i,tb_names[j]);
      printf("Ошибка %x открытия таблицы %s\n",i,tb_names[j]);
	  db_status|=1;
      continue;
    }
    tab_ids[j]=i;
  }
  coord[0]=coord[2]=coord[3]=1;     // first tuple/attr
  coord[1]=24;                      // last tuple
  i=sh_drtb((char *)&cur_t ,sizeof(cur_t), coord, tab_ids[1]);       // M_PD_ECS_TTIM_CHAN  attr 1
  if(i<0) {
    sh_put_data_er(i);
    printf("Ошибка %x чтения таблицы M_PD_ECS_TTIM_CHAN\n",i);
	db_status|=2;
  }
  coord[2]=coord[3]=2;     // attr 2
  i=sh_drtb((char *)&cur_OO ,sizeof(cur_OO), coord, tab_ids[1]);     // M_PD_ECS_TTIM_CHAN  attr 2
  if(i<0) {
    sh_put_data_er(i);
    printf("Ошибка %x чтения таблицы M_PD_ECS_TTIM_CHAN\n",i);
	db_status|=4;
  }
  coord[2]=coord[3]=3;     // attr 3
  i=sh_drtb((char *)&cur_Strt ,sizeof(cur_Strt), coord, tab_ids[1]); // M_PD_ECS_TTIM_CHAN  attr 3
  if(i<0) {
    sh_put_data_er(i);
    printf("Ошибка %x чтения таблицы M_PD_ECS_TTIM_CHAN\n",i);
	db_status|=8;
  }

  coord[1]=coord[2]=1;
  coord[3]=8;
  i=sh_drtb((char *)&cur_par ,sizeof(cur_par), coord, tab_ids[2]);  // M_PD_ECS_TIMIT
  if(i<0) {
    sh_put_data_er(i);
    printf("Ошибка %x чтения таблицы M_PD_ECS_TIMIT\n",i);
	db_status|=16;
  }

//  открыты все таблицы, управляющие данные прочитаны
//  ЗДЕСЬ надо прописать аппаратуру последними данными, которые были сохранены в БД
   was_err=0;         // первичный статус

  coord[0]=coord[1]=coord[2]=coord[3]=1;
  for(j=0; j<24; j++)  // записать имена каналов в таблицу
  {
    i=sh_dwtb(Ch_names[j] ,8, coord, tab_ids[0]);  // M_PD_ECS_TTIM_COMM
    if(i<0) {
      sh_put_data_er(i);
      printf("Ошибка %x записи в таблицу M_PD_ECS_TTIM_COMM \n",i);
	  db_status|=32;
      break; 
    }
    else
      sh_put_meas_er(0);  
    coord[1] += 1;
    coord[0]=coord[1];
  }
  sh_put_mess("Задача timerU70 начинает работу");
  first_run=1;
  up_count=sh_get_count()-1; // циклический счётчик действий сверху
  if(db_status==0) sh_put_data_er(0); //error not found
  return(db_status);
}

int db_process(unsigned int *imitatorUpdate,unsigned int *timerUpdate)
{ 
  int was_change=first_run;
  *imitatorUpdate=0;
  *timerUpdate=0;
  if(first_run){
    *imitatorUpdate=0xff; //update all parameters of imitator
    *timerUpdate=0x07ffffff; //update all parameters of timer
  }
  first_run=0;
  was_err=0;
  time_wait(300);        // ~33 раза за 10 секунд
  j=sh_get_count();      // циклический счётчик действий сверху
  if(j!=up_count) {      // есть новые данные сверху
    up_count=j;
// 1	
    coord[0]=coord[2]=1;
    coord[1]=1;
    coord[3]=8;
    i=sh_drtb((char *)&new_par ,sizeof(new_par), coord, tab_ids[2]);  // M_PD_ECS_TIMIT
    if(i<0) {
      was_err=i;
      sh_put_data_er(i);
      printf("Ошибка %x чтения таблицы M_PD_ECS_TIMIT\n",i);
      return(0);    // Ошибка БД - это криминал don't write data into HW
    }

    if(cur_par.NC != new_par.NC) {
//      printf("Параметр StartNC был %lg стал %lg\n",cur_par.NC,new_par.NC);
      cur_par.NC=new_par.NC;
      *imitatorUpdate|=1;
	  was_change=1;
    }
    if(cur_par.B1 != new_par.B1) {
//      printf("Параметр StartB1 был %lg стал %lg\n",cur_par.B1,new_par.B1);
      cur_par.B1=new_par.B1;
      *imitatorUpdate|=2;
	  was_change=1;
    }
    if(cur_par.B2 != new_par.B2) {
//      printf("Параметр StartB2 был %lg стал %lg\n",cur_par.B2,new_par.B2);
      cur_par.B2=new_par.B2;
      *imitatorUpdate|=4;
	  was_change=1;
    }
    if(cur_par.KC1 != new_par.KC1) {
//      printf("Параметр StartKC1 был %lg стал %lg\n",cur_par.KC1,new_par.KC1);
      cur_par.KC1=new_par.KC1;
      *imitatorUpdate|=8;
	  was_change=1;
    }
    if(cur_par.KC2 != new_par.KC2) {
//      printf("Параметр StartKC2 был %lg стал %lg\n",cur_par.KC2,new_par.KC2);
      cur_par.KC2=new_par.KC2;
      *imitatorUpdate|=0x10;
	  was_change=1;
    }
    if(cur_par.Tcycle != new_par.Tcycle) {
//      printf("Параметр Tcycle был %lg стал %lg\n",cur_par.Tcycle,new_par.Tcycle);
      cur_par.Tcycle=new_par.Tcycle;
      *imitatorUpdate|=0x20;
	  was_change=1;
    }
    if(cur_par.Mode != new_par.Mode) {
//      printf("Параметр Mode был %d стал %d\n",cur_par.Mode&255,new_par.Mode&255);
      cur_par.Mode=new_par.Mode;
      *imitatorUpdate|=0x40;
	  was_change=1;
    }
    if(cur_par.Regim != new_par.Regim) {
//      printf("Параметр Regime был %d стал %d\n",cur_par.Regim&255,new_par.Regim&255);
      cur_par.Regim=new_par.Regim;
      *imitatorUpdate|=0x80;
	  was_change=1;
    }
// 2
    coord[0]=coord[2]=coord[3]=1;     // first tuple/attr
    coord[1]=24;                      // last tuple
    i=sh_drtb((char *)&new_t ,sizeof(new_t), coord, tab_ids[1]);       // M_PD_ECS_TTIM_CHAN  attr 1
    if(i<0)
    {
      was_err=i;
      sh_put_data_er(i);
      printf("Ошибка %x чтения таблицы M_PD_ECS_TTIM_CHAN\n",i);
      return(0);    // Ошибка БД - это криминал don't write data into HW
    }
    coord[2]=coord[3]=2;              // attr 2
    i=sh_drtb((char *)&new_OO ,sizeof(new_OO), coord, tab_ids[1]);     // M_PD_ECS_TTIM_CHAN  attr 2
    if(i<0) {
      was_err=i;
      sh_put_data_er(i);
      printf("Ошибка %x чтения таблицы M_PD_ECS_TTIM_CHAN\n",i);
      return(0);    // Ошибка БД - это криминал don't write data into HW
    }
    coord[2]=coord[3]=3;              // attr 3
    i=sh_drtb((char *)&new_Strt ,sizeof(new_Strt), coord, tab_ids[1]); // M_PD_ECS_TTIM_CHAN  attr 3
    if(i<0) {
      was_err=i;
      sh_put_data_er(i);
      printf("Ошибка %x чтения таблицы M_PD_ECS_TTIM_CHAN\n",i);
      return(0);    // Ошибка БД - это криминал don't write data into HW
    }

    for(j=0;j<24;j++)      // для 24 значений
    {
      if(cur_t[j] != new_t[j]) {
//        printf("Параметр Time[%d] был %lg стал %lg\n",j,cur_t[j],new_t[j]);
        cur_t[j]=new_t[j];
        *timerUpdate|=(1<<j);
		was_change=1;
      }
      if(cur_OO[j] != new_OO[j]) {
//        printf("Параметр OnOff[%d] был %d стал %d\n",j,cur_OO[j]&255,new_OO[j]&255);
        cur_OO[j]=new_OO[j];
        *timerUpdate|=(1<<24);
		was_change=1;
      }
      if(cur_Strt[j] != new_Strt[j]) {
//        printf("Параметр StartFrom[%d] был %d стал %d\n",j,cur_Strt[j]&255,new_Strt[j]&255);
        if(j<12) *timerUpdate|=(1<<25); else *timerUpdate|=(1<<26);
        cur_Strt[j]=new_Strt[j];
		was_change=1;
      }
    }
    sh_put_data_er(0);  // подтверждение правильности введённых данных
  }
  return(was_change);
}	
