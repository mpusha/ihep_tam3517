//---------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>

//#include <QMessageBox>
#include <QSettings>
#include <string.h>
#include <math.h>
#include <time.h>
#include <cerrno>
#include <fcntl.h>
#include <cstdlib>
#include <iostream>
#include <ctime>

#include "db.h"
#include "ti.h"

#define COM_TIMEOUT 0.1
#define COM_WAIT    0.005

extern double cur_t[24];
extern char cur_OO[24];
extern char cur_Strt[24];
extern struct Imita cur_par;

//---------------------------------------------------------------------------


// constructor
Tti::Tti(unsigned char ComP,int Baud)
{
  comPort=ComP;
  baudRate=Baud;  
  iniFileName=QString("/home/work/.config/IHEP/tiu70.conf");
  timerState=0;
  imitatorState=0;
}

void Tti::OpenCom(void)
{
  if(!sg.Open(comPort,baudRate)) {
    perror("System error! Com port can't open!");
  }
}


void Tti::CloseCom(void)
{
  sg.Close() ;
}

void Tti::writeSerial(char *sendStr )
{
  int len=0;
  char *tmpStr;
  tmpStr=sendStr;
  while(*tmpStr++) len++;
  len++; // 0 char send too
  sg.Send(sendStr,len); // write chars
}

int Tti::readSerial(void)
{
  int cnt ;
  
  cnt=sg.Recv(&buf[0],32); //read chars

  return(cnt);
}
// ------------------------------------------------------------------------------
// Reset timer FPGA
int Tti::resetT(void)
{
  char buf[64],*pbuf,sbuf[255];
  int tmp,ret=2,n=REPCOM,z;
  clock_t begTime;
  double sec;

  while((ret>0)&&((n--)!=0)){
    buf[0]=0;
    pbuf=buf;
    if(!sg.Open(comPort,baudRate)) {
      perror("System error! Com port can't open!");
      ret=EXIT_FAILURE;
      break;
    }
    sg.Clean();
    writeSerial((char*)"1:TRS");
    begTime=clock();
    sec=0;
    z=0;
    do{
      while(((tmp=sg.Recv(pbuf,1))==0)&&(sec<COM_TIMEOUT)){
        z++;
        sec=((double)(clock()-begTime))/(double)CLOCKS_PER_SEC;
      }
      if(sec>=COM_TIMEOUT) break;
    }
    while(*pbuf++);
    printf("  Spend sec=%lf wait %d cycle\n",sec,z);
    sg.Close();
    if(sec>COM_TIMEOUT){
      errno=62; //sys_errlist[62]="Timer expired"
      sprintf(sbuf,"  Timeout in function TUt24Comm::resetT rep=%d",n);
      printf("%s\n",sbuf);
      perror(sbuf);
      ret=EXIT_FAILURE;
    }
    else {
      if(strncmp((const char*)buf,"T>OK",4)) {
        errno=6; //sys_errlist[6]= "No such device or address"
        sprintf(sbuf,"  Bad answer from MCU AtMega162 in function Tti::resetT rep=%d. MCU return '%s'",n,buf);
        printf("%s\n",sbuf);
        perror(sbuf);
        ret=EXIT_FAILURE;
      }
      else{
        ret=EXIT_SUCCESS;
      }
    }
    begTime=clock();
    sec=0;
    while(sec<COM_WAIT) sec=((double)(clock()-begTime))/(double)CLOCKS_PER_SEC; // wait
  }
  return(ret);
}

// Reset imitator FPGA
int Tti::resetI(void)
{
  char buf[64],*pbuf,sbuf[255];
  int tmp,ret=2,n=REPCOM,z;
  clock_t begTime;
  double sec;

  while((ret>0)&&((n--)!=0)){
    buf[0]=0;
    pbuf=buf;
    if(!sg.Open(comPort,baudRate)) {
      perror("System error! Com port can't open!");
      ret=EXIT_FAILURE;
      break;
    }
    sg.Clean();
    writeSerial((char*)"2:IRS");
    begTime=clock();
    sec=0;
    z=0;
    do{
      while(((tmp=sg.Recv(pbuf,1))==0)&&(sec<COM_TIMEOUT)){
        z++;
        sec=((double)(clock()-begTime))/(double)CLOCKS_PER_SEC;
      }
      if(sec>=COM_TIMEOUT) break;
    }
    while(*pbuf++);
    printf("  Spend sec=%lf wait %d cycle\n",sec,z);
    sg.Close();
    if(sec>COM_TIMEOUT){
      errno=62; //sys_errlist[62]="Timer expired"
      sprintf(sbuf,"  Timeout in function TUt24Comm::resetI rep=%d",n);
      printf("%s\n",sbuf);
      perror(sbuf);
      ret=EXIT_FAILURE;
    }
    else {
      if(strncmp((const char*)buf,"I>OK",4)) {
        errno=6; //sys_errlist[6]= "No such device or address"
        sprintf(sbuf,"  Bad answer from MCU AtMega162 in function Tti::resetI rep=%d. MCU return '%s'",n,buf);
        printf("%s\n",sbuf);
        perror(sbuf);
        ret=EXIT_FAILURE;
      }
      else{
        ret=EXIT_SUCCESS;
      }
    }
    begTime=clock();
    sec=0;
    while(sec<COM_WAIT) sec=((double)(clock()-begTime))/(double)CLOCKS_PER_SEC; // wait
  }
  return(ret);
}
//-------------------------------------------------------------------------------
// write channel ch 0-23 time in s
int Tti::setChTime(int ch,double timeS)
{
  char bufo[64],*pbuf,bufi[64],sbuf[255];
  int tmp,ret=2,n=REPCOM,z;
  clock_t begTime;
  double sec;

  while((ret>0)&&((n--)!=0)){
    bufo[0]=0;
    pbuf=bufo;
    if(!sg.Open(comPort,baudRate)) {
      perror("System error! Com port can't open!");
      ret=EXIT_FAILURE;
      break;
    }
    sg.Clean();
    sprintf(bufi,"1:TTW %d %d",ch,(int)(timeS*1000000.0)); // convert in us
    writeSerial(bufi);
    begTime=clock();
    sec=0;
    z=0;
    do{
      while(((tmp=sg.Recv(pbuf,1))==0)&&(sec<COM_TIMEOUT)){
        z++;
        sec=((double)(clock()-begTime))/(double)CLOCKS_PER_SEC;
      }
      if(sec>=COM_TIMEOUT) break;
    }
    while(*pbuf++);
    printf("  Spend sec=%lf wait %d cycle\n",sec,z);
    sg.Close();
    if(sec>COM_TIMEOUT){
      errno=62; //sys_errlist[5]="Timer expired"
      sprintf(sbuf,"  Write Ch %d timeout in function TUt24Comm::setChTime rep=%d",ch,n);
      printf("%s\n",sbuf);
      perror(sbuf);
      ret=EXIT_FAILURE;
    }
    else {
      if(strncmp((const char*)bufo,"T>",2)) {
        errno=6; //sys_errlist[6]= "No such device or address"
        sprintf(sbuf,"  Write Ch %d bad answer from MCU AtMega162 in function Tti::setChTime rep=%d. MCU return '%s'",ch,n,bufo);
        printf("%s\n",sbuf);
        perror(sbuf);
        ret=EXIT_FAILURE;
      }
      else{
        sscanf(bufo,"T>%d",&ret); //if all OK read 0 (EXIT_SUCCESS)
        if(ret!=EXIT_SUCCESS){
          errno=5; // sys_errlist[5]= "Input/output error
          sprintf(sbuf,"  Ch %d data don't write in function Tti::setChTime rep=%d. MCU return '%s'.",ch,n,bufo);
          printf("%s\n",sbuf);
          perror(sbuf);
        }
      }
    }
    begTime=clock();
    sec=0;
    while(sec<COM_WAIT) sec=((double)(clock()-begTime))/(double)CLOCKS_PER_SEC; // wait 10 ms
  }
  return(ret);
}
//----------------------------------------------------------------------------
// write channel enable map (1-en,0-dis)
int Tti::setChEn(int chEn)
{
  char bufo[64],*pbuf,bufi[64],sbuf[255];
  int tmp,ret=2,n=REPCOM,z;
  clock_t begTime;
  double sec;

  while((ret>0)&&((n--)!=0)){
    bufo[0]=0;
    pbuf=bufo;
    if(!sg.Open(comPort,baudRate)) {
      perror("System error! Com port can't open!");
      ret=EXIT_FAILURE;
      break;
    }
    sg.Clean();
    sprintf(bufi,"1:TEW %d",chEn);
    writeSerial(bufi);
    begTime=clock();
    sec=0;
    z=0;
    do{
      while(((tmp=sg.Recv(pbuf,1))==0)&&(sec<COM_TIMEOUT)){
        z++;
        sec=((double)(clock()-begTime))/(double)CLOCKS_PER_SEC;
      }
      if(sec>=COM_TIMEOUT) break;
    }
    while(*pbuf++);
    printf("  Spend sec=%lf wait %d cycle\n",sec,z);
    sg.Close();
    if(sec>COM_TIMEOUT){
      errno=62; //sys_errlist[5]="Timer expired"
      sprintf(sbuf,"  Timeout in function Tti::setChEn rep=%d.",n);
      printf("%s\n",sbuf);
      perror(sbuf);
      ret=EXIT_FAILURE;
    }
    else {
      if(strncmp((const char*)bufo,"T>",2)) {
        errno=6; //sys_errlist[6]= "No such device or address"
        sprintf(sbuf,"  Bad answer from MCU AtMega162 in function Tti::setChEn rep=%d. MCU return '%s'",n,bufo);
        printf("%s\n",sbuf);
        perror(sbuf);
        ret=EXIT_FAILURE;
      }
      else{
        sscanf(bufo,"T>%d",&ret); //if all OK read 0 (EXIT_SUCCESS)
        if(ret!=EXIT_SUCCESS){
          errno=5; // sys_errlist[5]= "Input/output error
          sprintf(sbuf,"  Data don't write in function Tti::setChEn rep=%d. MCU return '%s'.",n,bufo);
          printf("%s\n",sbuf);
          perror(sbuf);
        }
      }
    }
    begTime=clock();
    sec=0;
    while(sec<COM_WAIT) sec=((double)(clock()-begTime))/(double)CLOCKS_PER_SEC; // wait
  }
  return(ret);
}
//---------------------------------------------------------------------------
// set control word A (commutation source for channel 0-11) 2 bits on ch
int Tti::setCWA(int cw)
{
  char bufo[64],*pbuf,bufi[64],sbuf[255];
  int tmp,ret=2,n=REPCOM,z;
  clock_t begTime;
  double sec;

  while((ret>0)&&((n--)!=0)){
    bufo[0]=0;
    pbuf=bufo;
    if(!sg.Open(comPort,baudRate)) {
      perror("System error! Com port can't open!");
      ret=EXIT_FAILURE;
      break;
    }
    sg.Clean();
    sprintf(bufi,"1:TAW %d",cw);
    writeSerial(bufi);
    begTime=clock();
    sec=0;
    z=0;
    do{
      while(((tmp=sg.Recv(pbuf,1))==0)&&(sec<COM_TIMEOUT)){
        z++;
        sec=((double)(clock()-begTime))/(double)CLOCKS_PER_SEC;
      }
      if(sec>=COM_TIMEOUT) break;
    }
    while(*pbuf++);
    printf("  Spend sec=%lf wait %d cycle\n",sec,z);
    sg.Close();
    if(sec>COM_TIMEOUT){
      errno=62; //sys_errlist[5]="Timer expired"
      sprintf(sbuf,"  Timeout in function Tti::setCWA rep=%d.",n);
      printf("%s\n",sbuf);
      perror(sbuf);
      ret=EXIT_FAILURE;
    }
    else {
      if(strncmp((const char*)bufo,"T>",2)) {
        errno=6; //sys_errlist[6]= "No such device or address"
        sprintf(sbuf,"  Bad answer from MCU AtMega162 in function Tti::setCWA rep=%d. MCU return '%s'",n,bufo);
        printf("%s\n",sbuf);
        perror(sbuf);
        ret=EXIT_FAILURE;
      }
      else{
        sscanf(bufo,"T>%d",&ret); //if all OK read 0 (EXIT_SUCCESS)
        if(ret!=EXIT_SUCCESS){
          errno=5; // sys_errlist[5]= "Input/output error
          sprintf(sbuf,"  Data don't write in function Tti::setCWA rep=%d. MCU return '%s'.",n,bufo);
          printf("%s\n",sbuf);
          perror(sbuf);
        }
      }
    }
    begTime=clock();
    sec=0;
    while(sec<COM_WAIT) sec=((double)(clock()-begTime))/(double)CLOCKS_PER_SEC; // wait
  }
  return(ret);
}
//---------------------------------------------------------------------------------
// set control word B (commutation source for channel 12-23) 2 bits on ch
int Tti::setCWB(int cw)
{
  char bufo[64],*pbuf,bufi[64],sbuf[255];
  int tmp,ret=2,n=REPCOM,z;
  clock_t begTime;
  double sec;

  while((ret>0)&&((n--)!=0)){
    bufo[0]=0;
    pbuf=bufo;
    if(!sg.Open(comPort,baudRate)) {
      perror("System error! Com port can't open!");
      ret=EXIT_FAILURE;
      break;
    }
    sg.Clean();
    sprintf(bufi,"1:TBW %d",cw);
    writeSerial(bufi);
    begTime=clock();
    sec=0;
    z=0;
    do{
      while(((tmp=sg.Recv(pbuf,1))==0)&&(sec<COM_TIMEOUT)){
        z++;
        sec=((double)(clock()-begTime))/(double)CLOCKS_PER_SEC;
      }
      if(sec>=COM_TIMEOUT) break;
    }
    while(*pbuf++);
    printf("  Spend sec=%lf wait %d cycle\n",sec,z);
    sg.Close();
    if(sec>1){
      errno=62; //sys_errlist[5]="Timer expired"
      sprintf(sbuf,"  Timeout in function Tti::setCWB rep=%d",n);
      printf("%s\n",sbuf);
      perror(sbuf);
      ret=EXIT_FAILURE;
    }
    else {
      if(strncmp((const char*)bufo,"T>",2)) {
        errno=6; //sys_errlist[6]= "No such device or address"
        sprintf(sbuf,"  Bad answer from MCU AtMega162 in function Tti::setCWB rep=%d. MCU return '%s'",n,bufo);
        printf("%s\n",sbuf);
        perror(sbuf);
        ret=EXIT_FAILURE;
      }
      else{
        sscanf(bufo,"T>%d",&ret); //if all OK read 0 (EXIT_SUCCESS)
        if(ret!=EXIT_SUCCESS){
          errno=5; // sys_errlist[5]= "Input/output error
          sprintf(sbuf,"  Data don't write in function Tti::setCWB rep=%d. MCU return '%s'.",n,bufo);
          printf("%s\n",sbuf);
          perror(sbuf);
        }
      }
    }
    begTime=clock();
    sec=0;
    while(sec<COM_WAIT) sec=((double)(clock()-begTime))/(double)CLOCKS_PER_SEC; // wait
  }
  return(ret);
}

//--------------------------------------------------------------------------------------------------
// set imitator time 0 NC 1-B1 2 B2 3 KC1 4 KC2 5 TCycle
int Tti::setImitatorTime(int ch,double timeS)
{
  char bufo[64],*pbuf,bufi[64],sbuf[255];
  int tmp,ret=2,n=REPCOM,z;
  clock_t begTime;
  double sec;

  while((ret>0)&&((n--)!=0)){
    bufo[0]=0;
    pbuf=bufo;
    if(!sg.Open(comPort,baudRate)) {
      perror("System error! Com port can't open!");
      ret=EXIT_FAILURE;
      break;
    }
    sg.Clean();
    sprintf(bufi,"2:ITW %d %d",ch,(int)(timeS*1000.0)); // convert in ms
    writeSerial(bufi);
    begTime=clock();
    sec=0;
    z=0;
    do{
      while(((tmp=sg.Recv(pbuf,1))==0)&&(sec<COM_TIMEOUT)){
        z++;
        sec=((double)(clock()-begTime))/(double)CLOCKS_PER_SEC;
      }
      if(sec>=COM_TIMEOUT) break;
    }
    while(*pbuf++);
    printf("  Spend sec=%lf wait %d cycle\n",sec,z);
    sg.Close();
    if(sec>COM_TIMEOUT){
      errno=62; //sys_errlist[5]="Timer expired"
      sprintf(sbuf,"  Write Ch %d timeout in function TUt24Comm::setImitatorTime rep=%d",ch,n);
      printf("%s\n",sbuf);
      perror(sbuf);
      ret=EXIT_FAILURE;
    }
    else {
      if(strncmp((const char*)bufo,"I>",2)) {
        errno=6; //sys_errlist[6]= "No such device or address"
        sprintf(sbuf,"  Write Ch %d bad answer from MCU AtMega162 in function Tti::setImitatorTime rep=%d. MCU return '%s'",ch,n,bufo);
        printf("%s\n",sbuf);
        perror(sbuf);
        ret=EXIT_FAILURE;
      }
      else{
        sscanf(bufo,"I>%d",&ret); //if all OK read 0 (EXIT_SUCCESS)
        if(ret!=EXIT_SUCCESS){
          errno=5; // sys_errlist[5]= "Input/output error
          sprintf(sbuf,"  Ch %d data don't write in function Tti::setImitatorTime rep=%d. MCU return '%s'.",ch,n,bufo);
          printf("%s\n",sbuf);
          perror(sbuf);
        }
      }
    }
    begTime=clock();
    sec=0;
    while(sec<COM_WAIT) sec=((double)(clock()-begTime))/(double)CLOCKS_PER_SEC; // wait 10 ms
  }
  return(ret);
}

//----------------------------------------------------------------------------------------------
// set imitator regime 1 imitator on others auto mode
int Tti::setImitatorRegime(int regime)
{
  char bufo[64],*pbuf,bufi[64],sbuf[255];
  int tmp,ret=2,n=REPCOM,z;
  clock_t begTime;
  double sec;

  while((ret>0)&&((n--)!=0)){
    bufo[0]=0;
    pbuf=bufo;
    if(!sg.Open(comPort,baudRate)) {
      perror("System error! Com port can't open!");
      ret=EXIT_FAILURE;
      break;
    }
    sg.Clean();
    sprintf(bufi,"2:IMW %d",regime);
    writeSerial(bufi);
    begTime=clock();
    sec=0;
    z=0;
    do{
      while(((tmp=sg.Recv(pbuf,1))==0)&&(sec<COM_TIMEOUT)){
        z++;
        sec=((double)(clock()-begTime))/(double)CLOCKS_PER_SEC;
      }
      if(sec>=COM_TIMEOUT) break;
    }
    while(*pbuf++);
    printf("  Spend sec=%lf wait %d cycle\n",sec,z);
    sg.Close();
    if(sec>COM_TIMEOUT){
      errno=62; //sys_errlist[5]="Timer expired"
      sprintf(sbuf,"  Timeout in function Tti::setImitatorRegime rep=%d.",n);
      printf("%s\n",sbuf);
      perror(sbuf);
      ret=EXIT_FAILURE;
    }
    else {
      if(strncmp((const char*)bufo,"I>",2)) {
        errno=6; //sys_errlist[6]= "No such device or address"
        sprintf(sbuf,"  Bad answer from MCU AtMega162 in function Tti::setImitatorRegime rep=%d. MCU return '%s'",n,bufo);
        printf("%s\n",sbuf);
        perror(sbuf);
        ret=EXIT_FAILURE;
      }
      else{
        sscanf(bufo,"I>%d",&ret); //if all OK read 0 (EXIT_SUCCESS)
        if(ret!=EXIT_SUCCESS){
          errno=5; // sys_errlist[5]= "Input/output error
          sprintf(sbuf,"  Data don't write in function Tti::setImitatorRegime rep=%d. MCU return '%s'.",n,bufo);
          printf("%s\n",sbuf);
          perror(sbuf);
        }
      }
    }
    begTime=clock();
    sec=0;
    while(sec<COM_WAIT) sec=((double)(clock()-begTime))/(double)CLOCKS_PER_SEC; // wait
  }
  return(ret);
}

//------------------------------------------------------ Common function

void Tti::ValuesAnalyse(void)
{
}
int Tti::initialSystem(void)
{
  int status_db,status_hw,ret=EXIT_SUCCESS;
  char str[100];

  printf("Begin initialisation of DB.\n");
  sh_put_mess((char*)"Task timerU70 is starting.");
  status_db=db_init(); // initialization of DB 0 - if Ok. If was fatal error then exit
  printf("status=%d\n",status_db);
  if(status_db){
    printf("Task timerU70 can't read all data from DB error code [0x%x]!\n",status_db);
    syslog(LOG_NOTICE,"Task timerU70 can't read all data from DB error code [0x%x]!",status_db);
//    set_state(MESS_IMIT_ERR | MESS_TIMER_ERR);
//    sh_put_mess(str);
    sleep(1);
    ret=EXIT_FAILURE;
  }
  else
    printf("Initialisation of DB is successfull!\n");

  printf("Begin configuration and reset of timer FPGA.\n");
  if((status_hw=configureT24FPGA("/home/work/timer.rbf"))){ //fatal error
    sprintf(str,"Fatal error of timerU70 (timer FPGA configuration error [0x%x]). Program was terminated!",status_hw);
    printf("%s\n",str);
    syslog(LOG_NOTICE,"Fatal error of timerU70 (timer FPGA configuration error [0x%x]). Program was terminated!",status_hw);
    sh_put_mess(str);
    set_state(MESS_TIMER_ERR); // error in mg
    sh_put_meas_er(0x4010);// HW error
    sleep(1);
    exit(EXIT_FAILURE);
  }
  sleep(1);
  if(resetT()){
    printf("Reset timer FPGA is BAD!!!\n");
  }
  else
    printf("Configuration and reset of timer FPGA is successfull!\n");

  printf("Begin configuration and reset of imitator FPGA.\n");
  if((status_hw=configureImitatorFPGA("/home/work/imitator.rbf"))){ //fatal error
    sprintf(str,"Fatal error of timerU70 (timer FPGA configuration error [0x%x]). Program was terminated!",status_hw);
    printf("%s\n",str);
    syslog(LOG_NOTICE,"Fatal error of timerU70 (timer FPGA configuration error [0x%x]). Program was terminated!",status_hw);
    sh_put_mess(str);
    set_state(MESS_IMIT_ERR); // error in mg
    sh_put_meas_er(0x4010);// HW error
    sleep(1);
    exit(EXIT_FAILURE);
  }
  sleep(1);
  if(resetI()){
    printf("Reset imitator FPGA is BAD!!!\n");
  }
  else
    printf("Configuration and reset of imitator FPGA is successfull!\n");

  return(ret);
}

void Tti::getDataFromDB(void)
{
}
//---------------------------------------------------------
int  Tti::WriteImitatorData(unsigned int imitatorUpdate)
{
  int error=MESS_OK;
  QSettings *Ini;

  Ini = new QSettings(iniFileName,QSettings::NativeFormat) ;

  Ini->beginGroup("ImitatorParameters");

  if(imitatorUpdate&0x1&&(cur_par.Mode==2)){
    // update StartNC
    Ini->setValue("NC_user",cur_par.NC);
    printf("Imitator NC time value %8.6lf is writing into imitator HW\n",cur_par.NC);
    if(setImitatorTime(0,cur_par.NC)) { printf("Imitator NC time write BAD!!!\n"); error|=MESS_IMIT_ERR;}
    else
       printf("Imitator NC time write OK.\n");
  }
  if(imitatorUpdate&0x2&&(cur_par.Mode==2)){
    // update StartB1
    Ini->setValue("B1_user",cur_par.B1);
    printf("Imitator B1 time value %8.6lf is writing into imitator HW\n",cur_par.B1);
    if(setImitatorTime(1,cur_par.B1)) { printf("Imitator B1 time write BAD!!!\n"); error|=MESS_IMIT_ERR;}
    else
       printf("Imitator B1 time write OK.\n");
  }
  if(imitatorUpdate&0x4&&(cur_par.Mode==2)){
    // update StartB2
    Ini->setValue("B2_user",cur_par.B2);
    printf("Imitator B2 time value %8.6lf is writing into imitator HW\n",cur_par.B2);
    if(setImitatorTime(2,cur_par.B2)) { printf("Imitator B2 time write BAD!!!\n"); error|=MESS_IMIT_ERR;}
    else
       printf("Imitator B2 time write OK.\n");
  }
  if(imitatorUpdate&0x8&&(cur_par.Mode==2)){
   // update  StartKC1
    Ini->setValue("KC1_user",cur_par.KC1);
    printf("Imitator KC1 time value %8.6lf is writing into imitator HW\n",cur_par.KC1);
    if(setImitatorTime(3,cur_par.KC1)) { printf("Imitator KC1 time write BAD!!!\n"); error|=MESS_IMIT_ERR;}
    else
       printf("Imitator KC1 time write OK.\n");
  }
  if(imitatorUpdate&0x10&&(cur_par.Mode==2)){
    // update StartKC2
    Ini->setValue("KC2_user",cur_par.KC2);
    printf("Imitator KC2 time value %8.6lf is writing into imitator HW\n",cur_par.KC2);
    if(setImitatorTime(4,cur_par.KC2)) { printf("Imitator KC2 time write BAD!!!\n"); error|=MESS_IMIT_ERR;}
    else
       printf("Imitator KC2 time write OK.\n");
  }
  if(imitatorUpdate&0x20&&(cur_par.Mode==2)){
    // update Tcycle
    Ini->setValue("TCycle_user",cur_par.Tcycle);
    printf("Imitator TCycle time value %8.6lf is writing into imitator HW\n",cur_par.Tcycle);
    if(setImitatorTime(5,cur_par.Tcycle)) { printf("Imitator TCycle time write BAD!!!\n"); error|=MESS_IMIT_ERR;}
    else
       printf("Imitator TCycle time write OK.\n");
  }
  if(imitatorUpdate&0x40){
    // update Mode
    Ini->setValue("Mode",cur_par.Mode);
    if(cur_par.Mode==0){// normal cycle
      double NC=Ini->value("NC_normal",0.185).toDouble();
      double B1=Ini->value("B1_normal",0.225).toDouble();
      double B2=Ini->value("B2_normal",0.255).toDouble();
      double KC1=Ini->value("KC1_normal",2.225).toDouble();
      double KC2=Ini->value("KC2_normal",7.34).toDouble();
      double Tcycle=Ini->value("TCycle_normal",9.9).toDouble();
      printf("Imitator NC time value %8.6lf is writing into imitator HW\n",NC);
      if(setImitatorTime(0,NC)) { printf("Imitator NC time write BAD!!!\n"); error|=MESS_IMIT_ERR;}
      else
         printf("Imitator NC time write OK.\n");

      printf("Imitator B1 time value %8.6lf is writing into imitator HW\n",B1);
      if(setImitatorTime(1,B1)) { printf("Imitator B1 time write BAD!!!\n"); error|=MESS_IMIT_ERR;}
      else
         printf("Imitator B1 time write OK.\n");

      printf("Imitator B2 time value %8.6lf is writing into imitator HW\n",B2);
      if(setImitatorTime(2,B2)) { printf("Imitator B2 time write BAD!!!\n"); error|=MESS_IMIT_ERR;}
      else
         printf("Imitator B2 time write OK.\n");

      printf("Imitator KC1 time value %8.6lf is writing into imitator HW\n",KC1);
      if(setImitatorTime(3,KC1)) { printf("Imitator KC1 time write BAD!!!\n"); error|=MESS_IMIT_ERR;}
      else
         printf("Imitator KC1 time write OK.\n");

      printf("Imitator KC2 time value %8.6lf is writing into imitator HW\n",KC2);
      if(setImitatorTime(4,KC2)) { printf("Imitator KC2 time write BAD!!!\n"); error|=MESS_IMIT_ERR;}
      else
         printf("Imitator KC2 time write OK.\n");

      printf("Imitator TCycle time value %8.6lf is writing into imitator HW\n",Tcycle);
      if(setImitatorTime(5,Tcycle)) { printf("Imitator TCycle time write BAD!!!\n"); error|=MESS_IMIT_ERR;}
      else
         printf("Imitator TCycle time write OK.\n");
    }
    else if(cur_par.Mode==1){//shore cycle
      double NC=Ini->value("NC_short",0.185).toDouble();
      double B1=Ini->value("B1_short",0.225).toDouble();
      double B2=Ini->value("B2_short",0.255).toDouble();
      double KC1=Ini->value("KC1_short",2.225).toDouble();
      double KC2=Ini->value("KC2_short",3.5).toDouble();
      double Tcycle=Ini->value("TCycle_short",5).toDouble();
      printf("Imitator NC time value %8.6lf is writing into imitator HW\n",NC);
      if(setImitatorTime(0,NC)) { printf("Imitator NC time write BAD!!!\n"); error|=MESS_IMIT_ERR;}
      else
         printf("Imitator NC time write OK.\n");

      printf("Imitator B1 time value %8.6lf is writing into imitator HW\n",B1);
      if(setImitatorTime(1,B1)) { printf("Imitator B1 time write BAD!!!\n"); error|=MESS_IMIT_ERR;}
      else
         printf("Imitator B1 time write OK.\n");

      printf("Imitator B2 time value %8.6lf is writing into imitator HW\n",B2);
      if(setImitatorTime(2,B2)) { printf("Imitator B2 time write BAD!!!\n"); error|=MESS_IMIT_ERR;}
      else
         printf("Imitator B2 time write OK.\n");

      printf("Imitator KC1 time value %8.6lf is writing into imitator HW\n",KC1);
      if(setImitatorTime(3,KC1)) { printf("Imitator KC1 time write BAD!!!\n"); error|=MESS_IMIT_ERR;}
      else
         printf("Imitator KC1 time write OK.\n");

      printf("Imitator KC2 time value %8.6lf is writing into imitator HW\n",KC2);
      if(setImitatorTime(4,KC2)) { printf("Imitator KC2 time write BAD!!!\n"); error|=MESS_IMIT_ERR;}
      else
         printf("Imitator KC2 time write OK.\n");

      printf("Imitator TCycle time value %8.6lf is writing into imitator HW\n",Tcycle);
      if(setImitatorTime(5,Tcycle)) { printf("Imitator TCycle time write BAD!!!\n"); error|=MESS_IMIT_ERR;}
      else
         printf("Imitator TCycle time write OK.\n");
    }
    else//user cycle
    {
      // update StartNC
      printf("Imitator NC time value %8.6lf is writing into imitator HW\n",cur_par.NC);
      if(setImitatorTime(0,cur_par.NC)) { printf("Imitator NC time write BAD!!!\n"); error|=MESS_IMIT_ERR;}
      else
         printf("Imitator NC time write OK.\n");

      // update StartB1
      printf("Imitator B1 time value %8.6lf is writing into imitator HW\n",cur_par.B1);
      if(setImitatorTime(1,cur_par.B1)) { printf("Imitator B1 time write BAD!!!\n"); error|=MESS_IMIT_ERR;}
      else
         printf("Imitator B1 time write OK.\n");

      // update StartB2
      printf("Imitator B2 time value %8.6lf is writing into imitator HW\n",cur_par.B2);
      if(setImitatorTime(2,cur_par.B2)) { printf("Imitator B2 time write BAD!!!\n"); error|=MESS_IMIT_ERR;}
      else
         printf("Imitator B2 time write OK.\n");

     // update  StartKC1
      printf("Imitator KC1 time value %8.6lf is writing into imitator HW\n",cur_par.KC1);
      if(setImitatorTime(3,cur_par.KC1)) { printf("Imitator KC1 time write BAD!!!\n"); error|=MESS_IMIT_ERR;}
      else
         printf("Imitator KC1 time write OK.\n");

      // update StartKC2
      printf("Imitator KC2 time value %8.6lf is writing into imitator HW\n",cur_par.KC2);
      if(setImitatorTime(4,cur_par.KC2)) { printf("Imitator KC2 time write BAD!!!\n"); error|=MESS_IMIT_ERR;}
      else
         printf("Imitator KC2 time write OK.\n");

      // update Tcycle
      printf("Imitator TCycle time value %8.6lf is writing into imitator HW\n",cur_par.Tcycle);
      if(setImitatorTime(5,cur_par.Tcycle)) { printf("Imitator TCycle time write BAD!!!\n"); error|=MESS_IMIT_ERR;}
      else
         printf("Imitator TCycle time write OK.\n");
    }
    printf("Parameter Mode write\n");
  }
  if(imitatorUpdate&0x80){
    // update Regime
    Ini->setValue("Regime",cur_par.Regim);
    if(setImitatorRegime(cur_par.Regim)) {
      printf("Regime write BAD!!!\n"); error|=MESS_TIMER_ERR;
    }
    else
       printf("Regime=%d write OK.\n",cur_par.Regim);
    printf("Parameter Regime write into HW\n");

  }
  Ini->endGroup();
  delete Ini;
  fflush(stderr);
  fflush(stdout);
  return(error);
}
void Tti::SetManualCtrl(int ctrl)
{
  timerState=ctrl;
  QSettings *Ini;
  Ini = new QSettings(iniFileName,QSettings::NativeFormat) ;
  QString current="Control";
  Ini->beginGroup(current);
  Ini->setValue("ManualMode",ctrl);
  Ini->endGroup();
  delete Ini;
}

//------------------------------------------------------------------
int  Tti::WriteTimerData(unsigned int timerUpdate)
{  
  int error=MESS_OK;
  int OnOff,StStA,StStB,i;
  QSettings *Ini;

  Ini = new QSettings(iniFileName,QSettings::NativeFormat) ;
  QString current="TParameter";

  Ini->beginWriteArray(current+"_Time");
  for(i=0;i<24;i++)
    if(timerUpdate&(1<<i)){
    // update timer ch time value
      printf("Ch %d Time value %8.6lf is writing into timer HW\n",i,cur_t[i]);
      Ini->setArrayIndex(i);
      Ini->setValue("Time",cur_t[i]);
      if(setChTime(i,cur_t[i])) { printf("Ch %d write BAD!!!\n",i); error|=MESS_TIMER_ERR;}
      else
         printf("Ch %d write OK.\n",i);
    }
  Ini->endArray();
  if(timerUpdate&(1<<24)){
  // update timer ch  OnOff value
    printf("Parameter OnOff is writing into timer HW\n");
    OnOff=0;
    for(i=0;i<24;i++){
      OnOff|=(cur_OO[i]&1)<<i;
    }
    Ini->beginGroup(current);
    Ini->setValue("OnOffCh", OnOff);
    Ini->endGroup();
    if(setChEn(OnOff)) {
      printf("OnOff write BAD!!!\n"); error|=MESS_TIMER_ERR;
    }
    else
       printf("OnOff=0x%x write OK.\n",OnOff);
  }
  if(timerUpdate&(1<<25)){
  // update timer ch Start Value for ch 0-11
    printf("Parameter Start Value 0-11 write into timer HW\n");
    StStA=0;
    for(i=0;i<12;i++){
      StStA|=(cur_Strt[i]&3)<<(i*2);
    }
    Ini->beginGroup(current);
    Ini->setValue("StartCh0_11", StStA);
    Ini->endGroup();
    if(setCWA(StStA)) {
      printf("Start Value 0-11 write BAD!!!\n"); error|=MESS_TIMER_ERR;
    }
    else
       printf("Start Value 0-11=0x%x write OK.\n",StStA);
  }
  if(timerUpdate&(1<<26)){
  // update timer ch Start Value for ch 12-23
    printf("Parameter Start Value 12-23 write into timer HW\n");
    StStB=0;
    for(i=12;i<24;i++){
      StStB|=(cur_Strt[i]&3)<<((i-12)*2);
    }
    Ini->beginGroup(current);
    Ini->setValue("StartCh12_23", StStB);
    Ini->endGroup();
    if(setCWB(StStB)) {
      printf("Start Value 12-23 write BAD!!!\n"); error|=MESS_TIMER_ERR;
    }
    else
       printf("Start Value 12-23=0x%x write OK.\n",StStB);
  }
  delete Ini ;
  fflush(stderr);
  fflush(stdout);
  return(error);

}
//--------------------------------------------------------------------
void Tti::IniFileRead()
{
  int i;
  QSettings *Ini ;
  Ini = new QSettings(iniFileName,QSettings::NativeFormat);

  QString current="TParameter";
  Ini->beginReadArray(current+"_Time");
  for(int i=0;i<24;i++){
    Ini->setArrayIndex(i);
    cur_t[i]=Ini->value("Time",1).toDouble();
  }
  Ini->endArray();

  Ini->beginGroup(current);
  int OnOff=Ini->value("OnOffCh", 0).toInt();
  for(i=0;i<24;i++){
    cur_OO[i]=OnOff&1;
    OnOff>>=1;
  }
  int StStA=Ini->value("StartCh0_11", 0).toInt();
  for(i=0;i<12;i++){
    cur_Strt[i]=StStA&3;
    StStA>>=2;
  }
  int StStB=Ini->value("StartCh12_23", 0).toInt();
  for(i=12;i<24;i++){
    cur_Strt[i]=StStB&3;
    StStB>>=2;
  }
  Ini->endGroup();

  Ini->beginGroup("ImitatorParameters");
  cur_par.Mode=Ini->value("Mode",0).toInt();
  cur_par.Regim=Ini->value("Regime",2).toInt();
  if(cur_par.Mode==0){
    cur_par.NC=Ini->value("NC_normal",0.185).toDouble();
    cur_par.B1=Ini->value("B1_normal",0.225).toDouble();
    cur_par.B2=Ini->value("B2_normal",0.255).toDouble();
    cur_par.KC1=Ini->value("KC1_normal",2.225).toDouble();
    cur_par.KC2=Ini->value("KC2_normal",7.34).toDouble();
    cur_par.Tcycle=Ini->value("TCycle_normal",9.9).toDouble();
  }
  else if(cur_par.Mode==1){
    cur_par.NC=Ini->value("NC_short",0.185).toDouble();
    cur_par.B1=Ini->value("B1_short",0.225).toDouble();
    cur_par.B2=Ini->value("B2_short",0.255).toDouble();
    cur_par.KC1=Ini->value("KC1_short",2.225).toDouble();
    cur_par.KC2=Ini->value("KC2_short",3.5).toDouble();
    cur_par.Tcycle=Ini->value("TCycle_short",5).toDouble();
  }
  else{
    cur_par.NC=Ini->value("NC_user",0.185).toDouble();
    cur_par.B1=Ini->value("B1_user",0.225).toDouble();
    cur_par.B2=Ini->value("B2_user",0.255).toDouble();
    cur_par.KC1=Ini->value("KC1_user",2.225).toDouble();
    cur_par.KC2=Ini->value("KC2_user",7.34).toDouble();
    cur_par.Tcycle=Ini->value("TCycle_user",9.9).toDouble();
  }
  Ini->endGroup();
  delete Ini ;
}
//--------------------------------------------------------------------
int  Tti::getStatus(void)
{
  int status=0;
  static int cnt=0,state=0;
  if(((cnt++)&0xf)) return (state); //~5 s

  char bufo[64],*pbuf,bufi[64],sbuf[255];
  int tmp,ret=2,n=REPCOM,z;
  clock_t begTime;
  double sec;

  while((ret>0)&&((n--)!=0)){
    bufo[0]=0;
    pbuf=bufo;
    if(!sg.Open(comPort,baudRate)) {
      perror("System error! Com port can't open!");
      ret=EXIT_FAILURE;
      break;
    }
    sg.Clean();
    sprintf(bufi,"2:IST");
    writeSerial(bufi);
    begTime=clock();
    sec=0;
    z=0;
    do{
      while(((tmp=sg.Recv(pbuf,1))==0)&&(sec<COM_TIMEOUT)){
        z++;
        sec=((double)(clock()-begTime))/(double)CLOCKS_PER_SEC;
      }
      if(sec>=COM_TIMEOUT) break;
    }
    while(*pbuf++);
 //   printf("  Spend sec=%lf wait %d cycle\n",sec,z);
    sg.Close();
    if(sec>COM_TIMEOUT){
      errno=62; //sys_errlist[5]="Timer expired"
      sprintf(sbuf,"  Timeout in function Tti::getStatus rep=%d.",n);
      printf("%s\n",sbuf);
      perror(sbuf);
      ret=EXIT_FAILURE;
    }
    else {
      if(strncmp((const char*)bufo,"I>",2)) {
        errno=6; //sys_errlist[6]= "No such device or address"
        sprintf(sbuf,"  Bad answer from MCU AtMega162 in function Tti::getStatus rep=%d. MCU return '%s'",n,bufo);
        printf("%s\n",sbuf);
        perror(sbuf);
        ret=EXIT_FAILURE;
      }
      else{
        sscanf(bufo,"I>%d",&status);
        ret=0;
      }
    }
    begTime=clock();
    sec=0;
    while(sec<COM_WAIT) sec=((double)(clock()-begTime))/(double)CLOCKS_PER_SEC; // wait
  }
  //printf("State=0x%x\n",status);
  if (ret==EXIT_FAILURE) state|=MESS_IMIT_ERR;else state&=~((int)MESS_IMIT_ERR);
  if(timerState) state=MESS_TIMER_MANUAL;
  if(status&1) state|=MESS_IMIT_IMITATION;else state&=~((int)MESS_IMIT_IMITATION);
  //if(((status&2)==0)&&(ret!=EXIT_FAILURE)) system("shutdown -hP 0");

  return(state);
}
//-----------------------------------------------------------------------------
void Tti::exportStatus(int status)
{
  static int oldstatus=-1;
  if(status!=oldstatus){
    oldstatus=status;
    QSettings *Ini;
    Ini = new QSettings(iniFileName,QSettings::NativeFormat) ;
    QString current="Control";
    Ini->beginGroup(current);
    Ini->setValue("status",status);
    Ini->endGroup();
    delete Ini;
  }
}
