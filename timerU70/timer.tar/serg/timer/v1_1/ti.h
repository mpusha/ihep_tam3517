//---------------------------------------------------------------------------

#ifndef TI_H
#define TI_H
#include <QString>
#include <stdio.h>
#include <math.h>
#include <syslog.h>
#include "serial.h"

#define MESS_OK             0
#define MESS_TIMER_ERR      1
#define MESS_TIMER_MANUAL   2
#define MESS_IMIT_ERR       4
#define MESS_IMIT_IMITATION 8

#define  REPCOM 3

#define PAD_DCLK_FPGA 117

extern "C" int configureT24FPGA(char * fName);
extern "C" int configureImitatorFPGA(char * fName);
extern "C" int db_init(void);
extern "C" int db_process(unsigned int *imitatorUpdate,unsigned int *timerUpdate);
//extern "C" void updateMeas(void);
extern "C" short sh_put_meas_er(short er_code);
extern "C" short sh_put_data_er(short er_code);
extern "C" void sh_put_mess(char *mes);
extern "C" void set_state(short my_cy);
//---------------------------------------------------------------------------
// timer on 24 ch + imitator procedure
class Tti
{
  public:

  unsigned char comPort;
  int baudRate;
  char buf[64];
  int timerState,imitatorState;

  SerialGate sg;
  Tti(unsigned char ComP,int Boud) ; // constructor
  void ValuesAnalyse(void); // analyse input values 
  int  initialSystem(void);// initialization of system after all object has been created
  int  WriteImitatorData(unsigned int imitatorUpdate);// write data into imitator
  int  WriteTimerData(unsigned int timerUpdate);// write data into timer HW
  int  getStatus(void);// get status from system
  void getDataFromDB(void); 
  void IniFileRead();
  void SetManualCtrl(int ctrl); // set manual control
  void exportStatus(int status);

private:
// Rs232 function
  void OpenCom(void);
  void CloseCom(void);
  void writeSerial(char *);
  int readSerial(void);
  
  int resetT(void);
  int resetI(void);
  int setChTime(int ch,double timeS);
  int setChEn(int chEn);
  int setCWA(int cw);
  int setCWB(int cw);
  int setImitatorTime(int ch, double timeS);
  int setImitatorRegime(int regime);
  QString iniFileName;

} ;

#endif
