//---------------------------------------------------------------------------
#include <stdio.h>

#include <QMessageBox>
#include <QString>
#include <math.h>
#include <time.h>
#include <cerrno>
#include "ut24Communication.h"

// Rs485 processing
//---------------------------------------------------------------------------


// constructor
TUt24Comm::TUt24Comm(unsigned char ComP,int Baud)
{
  comPort=ComP;
  baudRate=Baud;  
}

void TUt24Comm::OpenCom(void)
{
  if(!sg.Open(comPort,baudRate)) {
    perror("System error! Com port can't open!");
  }
}


void TUt24Comm::CloseCom(void)
{
  sg.Close() ;
}

void TUt24Comm::writeSerial(char *sendStr )
{
  int len=0;
  char *tmpStr;
  tmpStr=sendStr;
  while(*tmpStr++) len++;
  len++; // 0 char send too
  sg.Send(sendStr,len); // write chars
}

int TUt24Comm::readSerial(void)
{
  int cnt ;
  
  cnt=sg.Recv(&buf[0],32); //read chars

  return(cnt);
}
// ------------------------------------------------------------------------------
// Reset FPGA
int TUt24Comm::reset(void)
{
  char buf[64],*pbuf,sbuf[255];
  int tmp,ret=2,n=REPCOM;
  time_t nowTime,begTime;
  double sec;

  while((ret>0)&&((n--)!=0)){
    buf[0]=0;
    pbuf=buf;
    if(!sg.Open(comPort,baudRate)) {
      perror("System error! Com port can't open!");
      ret=EXIT_FAILURE;
      break;
    }
    sg.Clean();
    writeSerial((char*)"TRS");
    time(&begTime);
    sec=0;
    do{
      while(((tmp=sg.Recv(pbuf,1))==0)&&(sec<1)){
        time(&nowTime);
        sec=difftime(nowTime,begTime);
      }
    }
    while((*pbuf++)&&(sec<1));
    sg.Close();
    if(sec>0.1){
      errno=62; //sys_errlist[62]="Timer expired"
      perror("Timeout in function TUt24Comm::reset");
      ret=EXIT_FAILURE;
    }
    else {
      if(strncmp((const char*)buf,"T>OK",4)) {
        errno=6; //sys_errlist[6]= "No such device or address"
        sprintf(sbuf,"Bad answer from MCU AtMega162 in function TUt24Comm::reset. MCU return '%s'",buf);
        perror(sbuf);
        ret=EXIT_FAILURE;
      }
      else{
        ret=EXIT_SUCCESS;
      }
    }
  }
  return(ret);
}
//-------------------------------------------------------------------------------
// write channel ch 0-23 time in s
int TUt24Comm::setChTime(int ch,double timeS)
{
  char bufo[64],*pbuf,bufi[64],sbuf[255];
  int tmp,ret=2,n=REPCOM;
  time_t nowTime,begTime;
  double sec;

  while((ret>0)&&((n--)!=0)){
    bufo[0]=0;
    pbuf=bufo;
    if(!sg.Open(comPort,baudRate)) {
      perror("System error! Com port can't open!");
      ret=EXIT_FAILURE;
      break;
    }
    sg.Clean();
    sprintf(bufi,"TTW %d %d",ch,(int)(timeS*1000000.0)); // convert in us
    writeSerial(bufi);
    time(&begTime);
    sec=0;
    do{
      while(((tmp=sg.Recv(pbuf,1))==0)&&(sec<1)){
        time(&nowTime);
        sec=difftime(nowTime,begTime);
      }
    }
    while((*pbuf++)&&(sec<1));
    sg.Close();
    if(sec>0.1){
      errno=62; //sys_errlist[5]="Timer expired"
      perror("Timeout in function TUt24Comm::setChTime");
      ret=EXIT_FAILURE;
    }
    else {
      if(strncmp((const char*)bufo,"T>",2)) {
        errno=6; //sys_errlist[6]= "No such device or address"
        sprintf(sbuf,"Bad answer from MCU AtMega162 in function TUt24Comm::setChTime. MCU return '%s'",bufo);
        perror(sbuf);
        ret=EXIT_FAILURE;
      }
      else{
        sscanf(bufo,"T>%d",&ret); //if all OK read 0 (EXIT_SUCCESS)
        if(ret!=EXIT_SUCCESS){
          errno=5; // sys_errlist[5]= "Input/output error
          perror("Data don't write in function TUt24Comm::setChTime. FPGA error");
        }
      }
    }
  }
  return(ret);
}
//----------------------------------------------------------------------------
// write channel enable map (1-en,0-dis)
int TUt24Comm::setChEn(int chEn)
{
  char bufo[64],*pbuf,bufi[64],sbuf[255];
  int tmp,ret=2,n=REPCOM;
  time_t nowTime,begTime;
  double sec;

  while((ret>0)&&((n--)!=0)){
    bufo[0]=0;
    pbuf=bufo;
    if(!sg.Open(comPort,baudRate)) {
      perror("System error! Com port can't open!");
      ret=EXIT_FAILURE;
      break;
    }
    sg.Clean();
    sprintf(bufi,"TEW %d",chEn);
    writeSerial(bufi);
    time(&begTime);
    sec=0;
    do{
      while(((tmp=sg.Recv(pbuf,1))==0)&&(sec<1)){
        time(&nowTime);
        sec=difftime(nowTime,begTime);
      }
    }
    while((*pbuf++)&&(sec<1));
    sg.Close();
    if(sec>0.1){
      errno=62; //sys_errlist[5]="Timer expired"
      perror("Timeout in function TUt24Comm::setChEn");
      ret=EXIT_FAILURE;
    }
    else {
      if(strncmp((const char*)bufo,"T>",2)) {
        errno=6; //sys_errlist[6]= "No such device or address"
        sprintf(sbuf,"Bad answer from MCU AtMega162 in function TUt24Comm::setChEn. MCU return '%s'",bufo);
        perror(sbuf);
        ret=EXIT_FAILURE;
      }
      else{
        sscanf(bufo,"T>%d",&ret); //if all OK read 0 (EXIT_SUCCESS)
        if(ret!=EXIT_SUCCESS){
          errno=5; // sys_errlist[5]= "Input/output error
          perror("Data don't write in function TUt24Comm::setChEn. FPGA error");
        }
      }
    }
  }
  return(ret);
}
//---------------------------------------------------------------------------
// set control word A (commutation source for channel 0-11) 2 bits on ch
int TUt24Comm::setCWA(int cw)
{
  char bufo[64],*pbuf,bufi[64],sbuf[255];
  int tmp,ret=2,n=REPCOM;
  time_t nowTime,begTime;
  double sec;

  while((ret>0)&&((n--)!=0)){
    bufo[0]=0;
    pbuf=bufo;
    if(!sg.Open(comPort,baudRate)) {
      perror("System error! Com port can't open!");
      ret=EXIT_FAILURE;
      break;
    }
    sg.Clean();
    sprintf(bufi,"TAW %d",cw);
    writeSerial(bufi);
    time(&begTime);
    sec=0;
    do{
      while(((tmp=sg.Recv(pbuf,1))==0)&&(sec<1)){
        time(&nowTime);
        sec=difftime(nowTime,begTime);
      }
    }
    while((*pbuf++)&&(sec<1));
    sg.Close();
    if(sec>0.1){
      errno=62; //sys_errlist[5]="Timer expired"
      perror("Timeout in function TUt24Comm::setCWA");
      ret=EXIT_FAILURE;
    }
    else {
      if(strncmp((const char*)bufo,"T>",2)) {
        errno=6; //sys_errlist[6]= "No such device or address"
        sprintf(sbuf,"Bad answer from MCU AtMega162 in function TUt24Comm::setCWA. MCU return '%s'",bufo);
        perror(sbuf);
        ret=EXIT_FAILURE;
      }
      else{
        sscanf(bufo,"T>%d",&ret); //if all OK read 0 (EXIT_SUCCESS)
        if(ret!=EXIT_SUCCESS){
          errno=5; // sys_errlist[5]= "Input/output error
          perror("Data don't write in function TUt24Comm::setCWA. FPGA error");
        }
      }
    }
  }
  return(ret);
}
//---------------------------------------------------------------------------------
// set control word B (commutation source for channel 12-23) 2 bits on ch
int TUt24Comm::setCWB(int cw)
{
  char bufo[64],*pbuf,bufi[64],sbuf[255];
  int tmp,ret=2,n=REPCOM;
  time_t nowTime,begTime;
  double sec;

  while((ret>0)&&((n--)!=0)){
    bufo[0]=0;
    pbuf=bufo;
    if(!sg.Open(comPort,baudRate)) {
      perror("System error! Com port can't open!");
      ret=EXIT_FAILURE;
      break;
    }
    sg.Clean();
     sprintf(bufi,"TBW %d",cw);
    writeSerial(bufi);
    time(&begTime);
    sec=0;
    do{
      while(((tmp=sg.Recv(pbuf,1))==0)&&(sec<1)){
        time(&nowTime);
        sec=difftime(nowTime,begTime);
      }
    }
    while((*pbuf++)&&(sec<1));
    sg.Close();
    if(sec>0.1){
      errno=62; //sys_errlist[5]="Timer expired"
      perror("Timeout in function TUt24Comm::setCWB");
      ret=EXIT_FAILURE;
    }
    else {
      if(strncmp((const char*)bufo,"T>",2)) {
        errno=6; //sys_errlist[6]= "No such device or address"
        sprintf(sbuf,"Bad answer from MCU AtMega162 in function TUt24Comm::setCWB. MCU return '%s'",bufo);
        perror(sbuf);
        ret=EXIT_FAILURE;
      }
      else{
        sscanf(bufo,"T>%d",&ret); //if all OK read 0 (EXIT_SUCCESS)
        if(ret!=EXIT_SUCCESS){
          errno=5; // sys_errlist[5]= "Input/output error
          perror("Data don't write in function TUt24Comm::setCWB. FPGA error");
        }
      }
    }
  }
  return(ret);
}
