#include <QtGui>
#include "ut24.h"

TUt24::TUt24()
{
  tComm=new TUt24Comm(2,19200);
configureFPGA("timer.rbf");
sleep(1);
  while(1){
 //   test();
//    for(int i=0; i<sys_nerr; i++)
//            printf("sys_errlist[%d] = \"%s\"\n", i, sys_errlist[i]);
   // tComm->WriteSerial(buf);
   // sleep(1);
   // printf("St=%d\n",tComm->ReadSerial());
   // printf("Buf %s\n",tComm->buf);
    //test();
    //sleep(1);
    tComm->reset();

    tComm->setChTime(0,5.9999);
    tComm->setChEn(7);
    tComm->setCWA(0);
    tComm->setCWB(0);
    QMessageBox msgBox;
    msgBox.setText("Error Load FPGA");
    msgBox.exec();

  }
}
TUt24::~TUt24()
{
}
int TUt24::test(void)
{
  if(configureFPGA("timer.fpga")){
    QMessageBox msgBox;
    msgBox.setText("Error Load FPGA");
    msgBox.exec();
  }else
  {
    QMessageBox msgBox;
    msgBox.setText("Load FPGA - OK");
    msgBox.exec();
  }

return 0;
}

