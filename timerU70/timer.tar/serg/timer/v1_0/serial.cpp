
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>                                                    
#include <sys/stat.h>                                                    
#include <fcntl.h>                                                        
#include <string.h>
#include <termios.h>                                                      
#include <unistd.h>
#include "serial.h"                                                     
#include <QString>                                                                                
//#define BAUDRATE B9600
#define MODEMDEVICE "/dev/ttyO1"                                          
#define _POSIX_SOURCE 1 /* POSIX compliant source */                      
                                                                                    
                                                                                
bool SerialGate::Open(int port, int baud)
{
  struct termios newtio;                                           
  unsigned int BAUDRATE;
  switch(baud){
  case 4800:
    BAUDRATE=B4800;
  break;
  case 9600:
    BAUDRATE=B9600;
  break;
  case 19200:
    BAUDRATE=B19200;
  break;
  default:
    BAUDRATE=B9600;
  break; 
  }
//  printf("%d %d\n",port,baud);
  QString str=QString("/dev/ttyO%1").arg(port-1);
//  printf("PORT %s\n",str.toAscii().data());
  fd = open(str.toAscii().data(), O_RDWR | O_NOCTTY );                             
  if (fd <0) {perror(MODEMDEVICE); return(false); }                                                                 
  memset(&newtio, 0,sizeof(newtio));                                         
  newtio.c_cflag = BAUDRATE | CS8 | CLOCAL | CREAD;             
  newtio.c_iflag = IGNPAR;                                                
  newtio.c_oflag = 0;                                                     
                                                                                
/* set input mode (non-canonical, no echo,...) */                       
  newtio.c_lflag = 0;                                                     
                                                                    
  newtio.c_cc[VTIME]    = 0;   /* inter-character timer unused */         
  newtio.c_cc[VMIN]     = 0;   /* blocking read until 5 chars received */ 
                                                                    
  tcflush(fd, TCIFLUSH);                                                  
  tcsetattr(fd,TCSANOW,&newtio);                                          

  this->state = true;
  return true;	
}

SerialGate::SerialGate()
{
  this->state = false;
}

SerialGate::~SerialGate()
{
  this->Close();
}

void SerialGate::Close()
{
  this->state = false;
  close(fd);
}

void SerialGate::Clean()
{
  if(!state)
    return;
  tcflush(fd, TCIFLUSH);                                                  
}

int SerialGate::Send(char* buff, int szBuff)
{
  if(!state)
    return 0;
  if(buff == NULL || szBuff <= 0)
  {
    return 0;
  }
//  printf("send\n");
  int lpdwBytesWrittens = 0;
  lpdwBytesWrittens=write(fd,buff,(size_t)szBuff);
  tcdrain(fd);
  return lpdwBytesWrittens;
}

int SerialGate::Recv(char* buff, int szBuff)
{
  if(!state)
    return 0;
  if(buff == NULL || szBuff <= 0)
  {
    return 0;
  }
  int dwBytesRead = 0;	
  dwBytesRead=read(fd,buff,(size_t) szBuff);	
  return dwBytesRead;
}
