//---------------------------------------------------------------------------

#ifndef UT24COMMUNICATION_H
#define UT24COMMUNICATION_H

#include "serial.h"
#define  REPCOM 3

//---------------------------------------------------------------------------

class TUt24Comm
{
  public:

  unsigned char comPort;
  int baudRate;
  char buf[64];

  SerialGate sg;
  TUt24Comm(unsigned char ComP,int Boud) ; // constructor
  int reset(void);
// Rs232 function
  void OpenCom(void);
  void CloseCom(void);
  int setChTime(int ch,double timeS);
  int setChEn(int chEn);
  int setCWA(int cw);
  int setCWB(int cw);
private:
  void writeSerial(char *);
  int readSerial(void);
} ;

#endif
