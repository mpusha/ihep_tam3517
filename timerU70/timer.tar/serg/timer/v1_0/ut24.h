#ifndef UT24_H
#define UT24_H
#include "ut24Communication.h"


#define PAD_DCLK_FPGA 117

extern "C" int configureFPGA(char * fName);

class TUt24
{

public:
  TUt24(void) ;  // constructor
  ~TUt24(void);  //destructor
  int test(void);
  TUt24Comm *tComm;
private:


};


#endif // UT24_H
