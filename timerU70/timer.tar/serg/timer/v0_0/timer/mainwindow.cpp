#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "ut24.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    TUt24 *ut24=new(TUt24);
}

MainWindow::~MainWindow()
{
    delete ui;
}
