#include <stdio.h>
#include<fcntl.h>
short zz;
main()
  {
	cstmer((short)0);
	printf("D=%d ",zz);
	cstmer((short)1);
	printf("V=%d\n",zz);
	exit(0);
  }

