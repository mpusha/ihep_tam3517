extern int 	ntp(short int); 
extern void    	ficom(char *, short int); 
extern int 	namn(char *, short int, char *, short int); 
extern int 	nnam(char *, short int, char *, short int, short int); 
extern int 	nfind(char *, short int, char *); 
extern int 	rlread(char *, short int, char *); 
extern int 	tor(short int, char *); 
extern int 	toc(char *, short, short); 
extern int 	cmps(char *, short, int, short); 
extern void    	movch(char *, char *, short int); 
extern void    	amovch(char *, char *, short int); 
extern void    	nini(char *, short int); 
extern void    	mfromd(char *, short int, char *, int, short int); 




