/*
	:          ws_fill_EC
	:      ----------------
	:  Fill EC_DESC_TABLE
*/

#include "/usr/usera/voevodin/remote/ccydalib/ccydalib.h"
#include <errno.h>
#include <stdio.h>
#include <sys/time.h>
#include <sys/signal.h>
#include <sys/types.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/wait.h>

static struct comput COMP;      /* COMPUTERS tuple */

static int    i,j,l;

static char buf[800];
static short tab_id,coord[7],k;
char bb[160];
extern char *cel_rd();
struct EC_DESCR {
        char  EC_name[20];
        char  VME_name[20];
        unsigned char BC;
        unsigned char RT;
        char BLD_name[16];
        char PRC_name[16];
        char OS_name[16];
        short busy_flag;
        } EC_struc;
struct tab_opis {
        short n_tup;
        short n_attr;
        short tup_len;
        short n_plan;
        char r_type;
        char stat;
        } t_opi;
static char *ref1[]={
                "Show current descriptions",
                "Clear all busy_flags",
                "Create new discriptions"
                };
main()
   {
    letini(0);
    j= *(short *)cel_rd(0,ncoms,r_l);  /* number of computers */
    k=inidbl(3);
    if(k)
      {
       printf("Err.inidbl = %x\n",k);
       exit(0);
      }
    k=setdbl(3);
    if(k)
      {
       printf("Err.setdbl = %x\n",k);
       exit(0);
      }
    tab_id=ropdbl("TABLE_OF_EC_DESCR","supersys");
    if(tab_id < 0)
      {
       printf("Err.to open TABLE_OF_EC_DESCR = %x\n",tab_id);
       exit(0);
      }
    k=rlpdbl(&t_opi,tab_id);
    if(k < 0)
      {
       printf("Err.rlpdbl = %x\n",k);
       exit(0);
      }
    if(!(i=oumenu(3,ref1,1)))
      exit(0);
    switch(i)
       {
        case 1:  /* show descriptions */
        coord[0]=coord[1]=coord[2]=coord[3]=coord[4]=coord[6]=1;
        coord[5]=t_opi.n_attr;
        for(i=1;i<=t_opi.n_tup;i++)
          {
           if((k=dtrdbl(&EC_struc,sizeof(EC_struc),coord,tab_id)) < 0)
             {
              printf("Err. %x to read to TABLE_OF_EC_DESCR tuple %d/n",k,coord[3]);
              exit(0);
             }
           if(EC_struc.EC_name[0])
             printf("%3d. %s connected via VME=%s BC=%d RT=%d\n     installed in %-16s CPU=%-16s OS=%-16s STATE=%d\n",
               coord[2],EC_struc.EC_name,
               EC_struc.VME_name,
               EC_struc.BC,
               EC_struc.RT,
               EC_struc.BLD_name,
               EC_struc.PRC_name,
               EC_struc.OS_name,
               EC_struc.busy_flag);
           ++coord[2];
           ++coord[3];
          }
        break;
        case 2:  /* clear busy_flags */
        l=0;
        coord[0]=coord[1]=coord[2]=coord[3]=coord[6]=1;
        coord[4]=coord[5]=t_opi.n_attr;
        for(i=1;i<=t_opi.n_tup;i++)
          {
           if((k=dtwdbl(&l,sizeof(short),coord,tab_id)) < 0)
             {
              printf("Err. %x to write to TABLE_OF_EC_DESCR tuple %d/n",k,coord[3]);
              exit(0);
             }
           ++coord[2];
           ++coord[3];
          }
        printf("busy_flags are cleared\n");
        break;
        case 3:  /* create new descriptions */
        coord[0]=coord[1]=coord[2]=coord[3]=coord[4]=coord[6]=1;
        coord[5]=t_opi.n_attr;
        for(i=1;i<=j;i++)
          {
           k=setdbl(0);
           if(k)
             {
              printf("Err.setdbl = %x\n",k);
              exit(0);
             }
           memset(&EC_struc,0,sizeof(EC_struc));
           if(re_tu(ncoms,i,&COMP))
             {
              printf("Err. to read COMPUTERS tuple %d/n",i);
              exit(0);
             }
           if(!COMP.ncompu)
             continue;  /* no computer */
           if(!COMP.bus_c)
             continue;  /* not Equipment Controller */
           l=COMP.ncompu;
           if((k=nnam(&l,t_f))<0)
             {
              printf("Err.from nnam for ncompu %x\n",k);
              exit(0);
             }
           if(l>sizeof(EC_struc.EC_name))
             l=sizeof(EC_struc.EC_name);
           *(buf_+k+l)=0;
           memcpy(EC_struc.EC_name,buf_+k,l);
           l=COMP.nhost;
           if((k=nnam(&l,t_f))<0)
             {
              printf("Err.from nnam for nhost %x\n",k);
              exit(0);
             }
           if(l>sizeof(EC_struc.VME_name))
             l=sizeof(EC_struc.VME_name);
           *(buf_+k+l)=0;
           memcpy(EC_struc.VME_name,buf_+k,l);
           EC_struc.BC=COMP.bus_c;
           EC_struc.RT=COMP.rem_t;
           if(re_tu(nhoms,COMP.nhom,EC_struc.BLD_name))
             {
              printf("Err. to read HOUSES tuple %d/n",COMP.nhom);
              exit(0);
             }
           if(re_tu(com_l,COMP.type_pro,EC_struc.PRC_name))
             {
              printf("Err. to read COMPUTER_LIST tuple %d/n",COMP.type_pro);
              exit(0);
             }
           if(re_tu(os_l,COMP.nos,EC_struc.OS_name))
             {
              printf("Err. to read OS_LIST tuple %d/n",COMP.nos);
              exit(0);
             }
           k=setdbl(3);
           if(k)
             {
              printf("Err.setdbl = %x\n",k);
              exit(0);
             }
           if((k=dtwdbl(&EC_struc,sizeof(EC_struc),coord,tab_id)) < 0)
             {
              printf("Err. to write to TABLE_OF_EC_DESCR tuple %d/n",coord[3]);
              exit(0);
             }
           l=coord[2];
           ++coord[2];
           ++coord[3];
           if(coord[2] > t_opi.n_tup)
             {
              printf("TABLE_OF_EC_DESCR is full!!!/n");
              exit(0);
             }
          }
        memset(&EC_struc,0,sizeof(EC_struc));
        while(coord[2] <= t_opi.n_tup)
          {
           if((k=dtwdbl(&EC_struc,sizeof(EC_struc),coord,tab_id)) < 0)
             {
              printf("Err. to write to TABLE_OF_EC_DESCR tuple %d/n",coord[3]);
              exit(0);
             }
           ++coord[2];
           ++coord[3];
          }
        printf("  %d ECs are described!\n",l);
       }
   }
char inpnum(j)
 short *j;
  {
  char c;
  int _a;
   printf("Select action: ");
   *j=0;
   scanf("%d",&_a);   *j=_a;
   c=getchar();
   return(c);
  }
oumenu(n,legptr,k)
 char *legptr[];
 short n,k;
  {
  char *p,**p1;
  short i,r,n1;
   p1=legptr;
   n1=n;
   printf("\n");
   for(i=1;n1>0;n1--)
     {
      p= *legptr;
      if((*legptr)[0])
        printf("%3d.%s\n",i,*legptr++);
      ++i;
     }
i2:
   r=0;
   if(inpnum(&r)!='\n')goto i2;
   if(r <0 || r > n)goto i2;
i3:
   legptr=p1;
   return(r);
  }

