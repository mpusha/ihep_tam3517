#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#include <fcntl.h>
#include <stdlib.h>

fd_set read_template;    /* For read from remote-line */
struct timeval wait;

int svt;    /* Socket */
char buf2[256],buf[1024*50];

static struct sockaddr_in sin;
struct hostent *hp;

int i, l, k;

int bc;   /* BC number */
int rt;   /* Remote Term. number */

static char *hm[]= {"dsoku1","dsoku2","dsoku3","dsoku4", "dsoku5"};

/*========================================*/
main (int argc, char* argv[]) {
/*========================================*/
 
 if (argc!= 4) {
 err1:
     printf("Host name-dsoku:");
     fgets(buf2,sizeof(buf2),stdin);
     sscanf(buf2,"%d",&i); if ( (i< 1) || (i> 5) ) goto err1;
     printf("BC=");
     fgets(buf2,sizeof(buf2),stdin);
     sscanf(buf2,"%d",&bc);
     printf("RT=");
     fgets(buf2,sizeof(buf2),stdin);
     sscanf(buf2,"%d",&rt);
  } else {
     sscanf(argv[1],"%d",&i); if ( (i< 1) || (i> 4) ) goto err1;
     sscanf(argv[2],"%d",&bc);
     sscanf(argv[3],"%d",&rt);
  }
 
  i= i-1;
  printf ("\nTerminal VPV. ( Host=%s. BC=%d. RT=%d )\n\n",hm[i],bc,rt);

  if (!(hp=gethostbyname(hm[i]))) {
     perror("gethostbyname");
     exit(0);
  }
  

    if((svt=socket(AF_INET,SOCK_DGRAM,0)) < 0 )    perror("VTsocket");
    sin.sin_family=AF_INET;
    sin.sin_port  = htons(0); 
    if(bind(svt,(struct sockaddr*)&sin,sizeof(sin)))   perror("VTbind");
    sin.sin_port  = htons(5998); 
    bcopy(hp->h_addr,&sin.sin_addr,hp->h_length);
 
    fcntl (0, F_SETFL, O_NONBLOCK);

    memset (buf2+2, 0, sizeof(buf2)-2);

    buf2[0]= bc;  /* Branch */
    buf2[1]= rt;  /* Remote */

  while( 1 )
  {  
    wait.tv_sec= 1;
    wait.tv_usec=0;
    FD_ZERO(&read_template);
    FD_SET(0,&read_template);
    FD_SET(svt,&read_template);
    if (select(FD_SETSIZE,&read_template,(fd_set*)0,(fd_set*)0,&wait) == -1)
    {
      perror( "select" );  continue;
    }
    if (FD_ISSET(0,&read_template))
    {
      fgets(buf2+2,sizeof(buf2)-2,stdin);
      l=2;
      while(buf2[l]!=0) {++l; if (buf2[l]== 0x0A) buf2[l]= 0x0D; }
      if (l> 2)
      {
         if((k=sendto(svt,buf2,l+1,0,(struct sockaddr*)&sin,sizeof(sin))) < 0)
	   perror("send");
         memset (buf2+2, 0, l-2);
      }
    }
    else
    if (FD_ISSET(svt,&read_template))
    {
      if((l=read(svt,buf,256))<0) perror("read");
      buf[l]=0;
      printf("%s",buf);
    }
  }
}
