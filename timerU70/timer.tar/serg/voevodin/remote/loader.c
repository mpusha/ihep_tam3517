#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

static struct sockaddr svt_from;
static struct sockaddr_in sin;
struct hostent *hp,*gethostbyname();

FILE *ioptr,*fopen(),*fls;
int    svt,ccvt;
short zz;
char buf[600],buf2[270],rltab[8000];
char c,bc,rt,*pbuf,*pbu;
static short i,j,k,l,n,ni,ncs,*ii;

static struct head {
        unsigned short dss;
        unsigned short dsp;
        unsigned short dcs;
        char prior;
        char tip;
        char nm[4];
        short peri;
        unsigned short leng;
        unsigned short dds;
        } *phead;
static struct rtit {
   unsigned short offset;
   unsigned short segm;
    } *item;
static struct task {
        unsigned short ip;
        char gost;
        } pts;
static struct shead {
  char x4d;
  char x5a;
  short lim;      /*image 512*/
  short lfi;      /*file 512 */
  short rtn;      /*num.of rel.tab.items*/
  short sh;       /*header 16*/
  short min;      /*16*/
  short max;
  short ss;
  short sp;
  short chs;
  short ip;
  short cs;
  short ofrtn;    /*offset rel.tab.*/
  short over;
   } *ph;
static struct segtab {
  char c0;
  char c1;                /* may be 80 */
  unsigned short dmax;    /* absol.addr.in par. */
  unsigned short dno;     /* related addr.in par. */
  unsigned short dmin;    /* length in par. */
  char sgn;
  char cln;
  char ovn;
  char csu;
        } *stb;
static struct pspbms {
  short of;
  char ds;
  char inter;
  char i20;     /*int 20*/
  char mem[4];
  char bs[2];   /*bytes num.in seg.*/
  char u1[2];
  char ta[4];
  char cb[4];
  char ee[4];
  char u2[58];
  char inter1;
  char i21;
  char retf;
   } psp;
static int fien,fil;
typedef struct shead *SHEAD;
typedef struct head *PHEAD;
typedef struct rtit *ITEM;

main()
  {
        psp.of=0;
        psp.ds=1;
        psp.inter=0xcd;
        psp.i20=0x20;
        psp.inter1=0xcd;
        psp.i21=0x21;
        psp.retf=0xcb;
        linum();
	zz=3;
begin:
	if(!fname())exit(0);
        strcpy(rltab+3000,buf);
	if(!fopn(0))goto begin;
        if(!fls) fls=fopen("d.lst","w");
        fprintf(fls,"%s\n",buf);
        c=fgetc(ioptr);
        buf[0]=c;            /* record type */
        if(c != 0x4d)
          {
erf:
           printf("\nERR.FILE FORMAT\n");
           fclose(ioptr);
           close(svt);
	   exit(0);
          }
        ph= (SHEAD)buf;
        j=1;
        for(i=sizeof(struct shead)-1;i>0;i--)
          buf[j++]=fgetc(ioptr);
        if(ph->x4d!=0x4d || ph->x5a!=0x5a)goto erf;
        pbuf=buf+sizeof(struct shead);
        phead=(PHEAD)(buf+sizeof(struct shead));
        pts.ip=ph->ip;
        pts.gost=0x80 | zz;
        phead->dss=ph->ss;
        phead->dsp=ph->sp;
        phead->dcs=ph->cs;
        phead->leng=ph->min +(ph->lfi<<5)-ph->sh +16+8;
c_01:
        printf("\nPRIORITY,TYPE,PROG.NAME:");
        scanf("%d",&i);
        if(getchar()!=',')goto c_01;
        phead->prior=i;
        scanf("%d",&i);
        if(getchar()!=',')goto c_01;
        phead->tip=i;
        c=j=0;
        for(i=4;i>0;i--)
          {
           if(c!='\n')
             {
              c=phead->nm[j++]=getchar();
              if(c=='\n')
              phead->nm[j-1]=' ';
             }
           else
             phead->nm[j++]=' ';
          }
        if(phead->nm[0]=='#')
          pts.gost &=0x7f;     /* start after load */
        while(c!='\n')c=getchar();
        if((phead->tip & 63)==3)
          {
           printf("\nPERIOD OF RESTARTING:");
           scanf("%d",&i);
           while(getchar()!='\n') ;
           phead->peri=i;
          }
fprintf(fls,"dss=%4x dsp=%4x dcs=%4x leng=%4x dds=%4x\n",
  phead->dss,phead->dsp,phead->dcs,phead->leng,phead->dds);
        bcopy(phead,buf2+3,16);
        buf2[0]=bc;
        buf2[1]=rt;
        buf2[2]=4;
        if(send_bl(buf2,128))goto bcelo;
        receive(pbuf,&k);
        if(*pbuf!=0)
          {
           printf("Reply on header(type 4)=%x length %d\n",*pbuf,k);
           goto bcelo;
          }
        pbuf += 5;
        k= *(short*)pbuf;        /*relocation constant*/
        printf("\nrelocation=%x\n",k);
        fprintf(fls,"relocation=%x\n",k);
        bcopy(&psp,buf2+3,sizeof(struct pspbms));
        buf2[2]=5;
        if(send_bl(buf2,sizeof(struct pspbms)+3)) goto bcelo;
        i=ph->ofrtn-sizeof(struct shead);
        while(i-- >0)
          fgetc(ioptr);        /*start of rel.tab.*/
        ni=ph->rtn;            /*num.of rel.tab.items*/
        ncs=0;
        if((i=ph->rtn*4)>sizeof(rltab))
          {
           printf("TOO MANY RELOCATION ITEMS\n");
           goto bcelo;
          }
        pbuf=rltab;
        item =(ITEM)rltab;
        while(i-- >0)
          *pbuf++ =fgetc(ioptr);       /*rel.tab.*/
        for(i=ni;i>0;i--)
          {
           if(item->offset & 0xfff0)
             {
              item->segm += (item->offset >> 4);
              item->offset &= 0x0f;
             }
           item->offset += ((item->segm&7)<<4);
           item->segm &= 0xfff8;
           item++;
          }
        i=(ph->sh<<4)-ph->ofrtn-(ph->rtn<<2);
        while(i--)
          fgetc(ioptr);    /*to image*/
        *(short*)buf=16;   /*from DS*/
        buf[2]=1;          /*as DS*/
        pbuf=buf+3;
        for(i=128;i>0;i--)
          {
           if(feof(ioptr))break;
           *pbuf++ =fgetc(ioptr);      /*first 128*/
           ++ncs;
          }
        while(ncs>0)
          {
           pbu=buf+3;
           pbuf=buf+3+128;
           for(i=128;i>0;i--)
             {
              if(feof(ioptr))break;
              *pbuf++ =fgetc(ioptr);
              ++ncs;
             }
           pbuf=buf+3+128;
           i= *(short*)buf-16;
           item=(ITEM)rltab;
           for(j=ni;j>0;j--)
             {
              if((unsigned)i==item->segm)
                {
                 ii=(short*)(pbu+item->offset);
                 *ii += k;     /*relocate*/
              fprintf(fls,"relocate seg=%x offs=%x \n",item->segm,item->offset);
                }
              ++item;
             }
           i=128+3;
/*           if(ncs<128)
             i=ncs+3;
*/
           bcopy(buf,buf2+3,i);
           buf2[2]=5;
           if(send_bl(buf2,i+3))goto bcelo;
           fprintf(fls,"tip=%d length=%d addr=%x data=%x %x\n",buf2[2],i,
             *(short *)(buf2+3),buf2[6]&255,buf2[7]&255);
           for(i=128;i>0;i--)
             *pbu++ = *pbuf++;
           ncs -= 128;
           *(unsigned*)buf += 8;
          }
        bcopy(&pts,buf2+3,3);
        buf2[2]=3;
        if(send_bl(buf2,128))goto bcelo;
        receive(buf,&i);
        if(*buf!=0)
          {
           printf("TASK SET ERR.= %d (get %d bytes)\n",*buf&255,i);
           goto bcelo;
          }
        printf("TASK LOADED\n");
bcelo:
        if(fls)
          {
           fclose(fls);
           fls=0;
          }
        close(svt);
        fclose(ioptr);
        exit(0);
   }
receive(bl_d,dl_bl)
 char *bl_d;
 short *dl_bl;
  {
   *dl_bl=recv(svt,bl_d,10,0);
   if(*dl_bl <= 0)
     perror("recv");
  }
send_bl(bl_d,dl_bl)
 char *bl_d;
 int dl_bl;
  {
   int cc;
   if((cc=send(svt,bl_d,dl_bl,0)) < 0)
     {
      perror("send");
      return(1);
     }
   if(bl_d[2]==5 )
     {
      cc=recv(svt,bl_d+3,2,0); /* wait for data block */
      if(cc<=0)
        {
         perror("recv on send");
         return(1);
        }
     }
   return(0);
  }
fname()
  {
   int i;
   printf("File name:");
   fgets(buf,sizeof(buf),stdin);
   i=0;
   while(buf[i])
     {
      if(buf[i]=='\n')
        buf[i]=0;
      ++i;
     }
   if(!buf[0]) return(0);
   return(1);
  }

linum()
  {
   int i;
    printf("Host name:");
    fgets(buf2,sizeof(buf2),stdin);
   i=0;
   while(buf2[i])
     {
      if(buf2[i]=='\n')
        buf2[i]=0;
      ++i;
     }
    if(!(hp=gethostbyname(buf2)))
      {
       perror("gethostbyname");
       exit(0);
       }
    printf("bc:");
    fgets(buf2,sizeof(buf2),stdin);
    sscanf(buf2,"%d",&i);
    bc=i;
    printf("rt:");
    fgets(buf2,sizeof(buf2),stdin);
    sscanf(buf2,"%d",&i);
    rt=i;
    if((svt=socket(AF_INET,SOCK_STREAM,0)) < 0)
      {
       perror("socket");
       exit(0);
       }
    sin.sin_family=AF_INET;
    sin.sin_port  = htons(0);
    if(bind(svt,(struct sockaddr*)&sin,sizeof(sin)))
      {
       perror("bind");
       exit(0);
      }
    sin.sin_port  = htons(5997);
    bcopy(hp->h_addr,&sin.sin_addr,hp->h_length);
    if(connect(svt,(struct sockaddr*)&sin,sizeof(sin)))
      {
       perror("Connect");
       exit(0);
      }
  }

fopn(i)    /* i= 0-read binary
                 1-write binary
                 2-read text
                 3-write text */
 short i;
  {
        switch (i)
          {
           case 0:
           ioptr=fopen(buf,"rb");
           break;
           case 1:
           ioptr=fopen(buf,"wb");
           break;
           case 2:
           ioptr=fopen(buf,"r");
           break;
           case 3:
           ioptr=fopen(buf,"w");
          }
        if(ioptr==0)
          {
           printf("\nCAN'T OPEN %s\n",buf);
           return(0);
          }
        return(1);
  }

