#include "ccydalib.h"
#include <errno.h>
#include <stdio.h>

static short tab_id= -1,coord[7],k;
struct EC_DESCR {
        char  EC_name[20];
        char  VME_name[20];
        unsigned char BC;
        unsigned char RT;
        char BLD_name[16];
        char PRC_name[16];
        char OS_name[16];
        short busy_flag;
        } ;
struct EC_DESCR all_ECs[max_EC];
struct tab_opis {
        short n_tup;
        short n_attr;
        short tup_len;
        short n_plan;
        char r_type;
        char stat;
        } t_opi;

void descr_ec_ini()
  {
  short i=0;
Try_5:
   if((tab_id=opnglb("TABLE_OF_EC_DESCR","supersys",&k)) <0)
     {
      if(i!=5)
       {
        ++i;
        goto Try_5;
       }
      syslog(LOG_NOTICE,"Can't open TABLE_OF_EC_DESCR = %x",tab_id);
      printf("Can't open TABLE_OF_EC_DESCR = %x\n",tab_id);
      return;
     }
   if(rlpdbl(&t_opi,tab_id) <0)
     {
      syslog(LOG_NOTICE,"Err. on function rlpdbl!!!");
      printf("Err. on function rlpdbl!!!\n");
      return;
     }
   if(t_opi.n_tup > max_EC)
     {
      syslog(LOG_NOTICE,"Too much number of ECs in TABLE_OF_EC_DESCR (%d > %d)"
         ,t_opi.n_tup,max_EC);
      printf("Too much number of ECs in TABLE_OF_EC_DESCR!\n");
      return;
     }
   coord[5]=t_opi.n_attr; /* number of attributes */
   coord[3]=t_opi.n_tup;  /* number of tuples */
   coord[0]=coord[1]=coord[2]=coord[4]=coord[6]=1;
   k=dtrdbl(all_ECs,sizeof(all_ECs),coord,tab_id);
   if(k < 0)
     {
      syslog(LOG_NOTICE,"Err. to read TABLE_OF_EC_DESCR = %x",k);
      printf("Err. to read TABLE_OF_EC_DESCR = %x\n",k);
      return;
     }
   return;
  }
int find_ec(char *vme, short bc, short rt)
  {
   coord[0]=coord[1]=coord[6]=1;
   coord[4]=coord[5]=8; /* busy_flag */
   for(k=0;k<t_opi.n_tup;k++)
     if(!strcmp(vme,all_ECs[k].VME_name))
       if(bc==all_ECs[k].BC && rt==all_ECs[k].RT)
         {
               /* EC found */
          coord[2]=coord[3]=k+1;  /* tuple number */
          return(0);
         }
   syslog(LOG_NOTICE,"%s BC=%d RT=%d not found in TABLE_OF_EC_DESCR ",vme,bc,rt);
   printf("%s BC=%d RT=%d not found in TABLE_OF_EC_DESCR \n",vme,bc,rt);
   return(-1); /* EC not found */
  }
void descr_ec_set(char *vme, short bc, short rt, short flag)
  {
   if(tab_id < 0)
     return;
   if(find_ec(vme, bc, rt) < 0)
     return;
   k=dtwdbl(&flag,2,coord,tab_id);
   if(k < 0)
     {
      syslog(LOG_NOTICE,"Err. to write TABLE_OF_EC_DESCR = %x",k);
      printf("Err. to write TABLE_OF_EC_DESCR = %x\n",k);
     }
  }
short descr_ec_get(char *vme, short bc, short rt)
  {
  short flag;
   if(tab_id < 0)
     return(-1);
   if(find_ec(vme, bc, rt) < 0)
     return(-1);
   k=dtrdbl(&flag,2,coord,tab_id);
   if(k < 0)
     {
      syslog(LOG_NOTICE,"Err. to read TABLE_OF_EC_DESCR = %x",k);
      printf("Err. to read TABLE_OF_EC_DESCR = %x\n",k);
      return(-1);
     }
   return(flag);
  }

