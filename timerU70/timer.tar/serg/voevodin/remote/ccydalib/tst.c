#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <syslog.h>
int daemon_init()
  {
   pid_t pid;
   if((pid=fork()) < 0)
     return(-1);
   else
     if(pid != 0)
       exit(0);   /* parent goes bye-bye */
   setsid();      /* child becomes session leader */
   chdir("/");    /* change working directory */
   umask(0);      /* clear our file mode creation mask */
   return(0);
  }

