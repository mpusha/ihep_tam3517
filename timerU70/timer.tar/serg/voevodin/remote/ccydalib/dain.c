#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <stdio.h>
#include <syslog.h>
#include <stdlib.h>
#include <unistd.h>
 pid_t pid;
extern char dae_name[];
int daemon_init()
  {
  FILE *fpt;
  char buf[300];
  short i;
  int j;
   if((pid=fork()) < 0)
     return(-1);
   else
     if(pid != 0)
       exit(0);   /* parent goes bye-bye */
   setsid();      /* child becomes session leader */
   chdir("/");    /* change working directory */
   umask(0);      /* clear our file mode creation mask */
   return(0);
  }
void daemon_restart()
  {
  int i;
   for(i=3;i<15;i++)
     close(i);
   execlp(dae_name,dae_name,NULL);
   perror("daemon_restart");
   exit(0);
  }

