#include <stdio.h>
#include "ccydalib.h"
static char r_ccc[]={"TABLE_OF_EC_DESCR"},use_name[]={""},vme[]={"dsoku4"};
static short bc,rt,flag;
main()
  {
   descr_ec_ini();
   bc=1;
   rt=7;
   flag=8;
   descr_ec_set(vme,  bc,  rt, flag);
   descr_ec_set(vme, 1, 2, 16);
   printf("1,7 =%d  1,2=%d \n",descr_ec_get(vme, bc, rt),descr_ec_get(vme, 1, 2));
  }

