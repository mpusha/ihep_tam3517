#include "/usr/usera/voevodin/remote/ccydalib/ccydalib.h"
#include <errno.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/time.h>

char dae_name[100];
extern int mx_ncopied;
static struct reldef rep;
int    i,j,l,k,m,svt,s1;
static int bptr;
static char f_nm[]={"/usr/usera/voevodin/                                     "};
static char tab_name[max_rel][22];
main()
   {
    gethostname(f_nm+20,20);
    if((bptr=open(f_nm,O_RDONLY))== -1)
     {
      printf("Err.open file %s - %s\n",f_nm,strerror(errno));
      exit(0);
     }
    lseek(bptr,0,SEEK_SET);
    i=0;
    memset(tab_name,0,sizeof(tab_name));
    if(read(bptr,tab_name,sizeof(tab_name)))
     while(read(bptr,&rep,sizeof(struct reldef)))
      {
       if(rep.rel_num)
         {
          printf("%d. %s\n",i+1,&tab_name[i][0]);
          printf("   user=%d DB=%d rel.num=%d Data.bl=%d offset=%d length=%d\n",
            rep.nus,rep.ndb,rep.rel_num,rep.dat_bl,rep.dat_off,rep.dat_len);
          printf("         Attribute.bl=%d offset=%d length=%d\n", rep.attr_bl,
            rep.attr_of,rep.attr_len);
          printf("   Nplane=%d Ntup=%d Nattr=%d Tuplength=%d type=0x%x state=0x%x\n",
            rep.re_to_re.third,rep.re_to_re.ntup,rep.re_to_re.nat,rep.re_to_re.lotup,
              rep.re_to_re.rtype,rep.re_to_re.rstate);
          printf("         res1=0x%x res2=0x%x nsub=%d owner=%d nrr=%d nrt=%d nra=%d\n"
           ,rep.re_to_re.res1,rep.re_to_re.res2,rep.re_to_re.nsub,rep.re_to_re.nowner,
             rep.re_to_re.nexlis.nrr,rep.re_to_re.nexlis.nrt,rep.re_to_re.nexlis.nra);
         }
       ++i;
      }
   }

