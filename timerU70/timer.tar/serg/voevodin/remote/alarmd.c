/*
               alarm_texts 
               ------------
    1.Get texts of alarm messages
*/
#include "/usr/usera/voevodin/remote/ccydalib/ccydalib.h"
#include <errno.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/time.h>

static struct log_text {
        int len_ad;
        struct sockaddr host;
        char date[26];
        char b_text[100];
      } log_texts;
static struct log_man {
        unsigned short plan_num;
        unsigned short res1;
        char fl_cy;   /* 0-no cycle, 1-was cycle */
        char res2;
      } log_mans;
static int    i,j,l,svt;
static short  k,max_p;
socklen_t ccvt;
char buf2[9216],din_m[4096],bb_b[80];
static char tab1[]={"LOG_TEXTS"},use_name[]={""};
static char tab2[]={"LOG_MAN"};
static short crd[7],tb_id1,tb_id2;
static struct sockaddr svt_from;
static struct sockaddr_in sin;
struct hostent *hp,*gethostbyname();
static time_t timer;
static int fla_2;
char dae_name[100];

main(int argc, char *argv[])
   {
    strcpy(dae_name, argv[0]);
    daemon_init();
    openlog("alarm_texts:",LOG_CONS,LOG_USER);
    letini(0);
/* socket to get requests */
    if((svt=socket(AF_INET,SOCK_DGRAM,0)) < 0)
      syslog(LOG_NOTICE,"socket:%s\n",strerror(errno));
    sin.sin_family=AF_INET;
    sin.sin_port  = htons(5993);
    if(bind(svt,(struct sockaddr*)&sin,sizeof(sin)))
      syslog(LOG_NOTICE,"bind:%s\n",strerror(errno));
    if((tb_id1=opnglb(tab1,use_name,&i))<0)
      {
       syslog(LOG_NOTICE,"err.open '%s' = %x\n",tab1,tb_id1);
       printf("alarmd::err.open '%s' = %x\n",tab1,tb_id1);
       exit(0);
      }
    if((tb_id2=opnglb(tab2,use_name,&i))<0)
      {
       syslog(LOG_NOTICE,"err.open '%s' = %x\n",tab2,tb_id2);
       printf("alarmd::err.open '%s' = %x\n",tab2,tb_id2);
       exit(0);
      }
    crd[0]=1;
    crd[1]=1;
    crd[2]=1;
    crd[3]=1;
    crd[4]=1;
    crd[5]=4;
    crd[6]=1;
    if((k=dtrdbl(&log_mans,sizeof(struct log_man),crd,tb_id2))<0)
      {
       syslog(LOG_NOTICE,"err.dtrdbl %s = %x\n",tab2,k);
       printf("alarmd::err.dtrdbl %s = %x\n",tab2,k);
       exit(0);
      }
    if(k=rlpdbl(buf2,tb_id1))
      {
       syslog(LOG_NOTICE,"err.rlpdbl %s = %x\n",tab1,k);
       printf("alarmd::err.rlpdbl %s = %x\n",tab1,k);
       exit(0);
      }
    max_p= *(short*)(buf2+6);
    fla_2=0;
    printf("alarmd is started!\n");
    while(1)
      {
       ccvt=sizeof(struct sockaddr);
       while((l=recvfrom(svt,buf2,sizeof(buf2),0,&svt_from,
         &ccvt)) <= 0)
           {
            sprintf(bb_b," %d bytes from %d %d %d %d errno=%d",l
              ,svt_from.sa_data[2]&255
              ,svt_from.sa_data[3]&255
              ,svt_from.sa_data[4]&255
              ,svt_from.sa_data[5]&255,errno);
            syslog(LOG_NOTICE,"recvfrom:%s\n",bb_b);
            syslog(LOG_NOTICE,"recvfrom:%s\n",strerror(errno));
           }
       if(fla_2 && buf2[0])
         continue;  /* I am stopped */
       switch(buf2[0]&255)
         {
          case 0:
	  switch(buf2[2]&255)
	    {
	     case 6: /* stop */
             if(fla_2)
               {
                syslog(LOG_NOTICE,"I got Double Stop Command\n");
               }
             else
               {
                fla_2=1;
                syslog(LOG_NOTICE,"I start Stop Operation\n");
                buf2[0]=buf2[2]=88;
                if(sendto(svt,buf2,8,0,&svt_from
                  ,sizeof(struct sockaddr_in)) <0)
                     syslog(LOG_NOTICE,"sendto after Stop Command:%s\n",strerror(errno));
               }
	     break;
	     case 7: /* restart */
             if(!fla_2)
               {
                syslog(LOG_NOTICE,"I got Start Command without Stop\n");
               }
             else
               {
                fla_2=0;
                syslog(LOG_NOTICE,"I Restart Operation %s\n",dae_name);
                buf2[0]=buf2[2]=89;
                if(sendto(svt,buf2,8,0,&svt_from
                  ,sizeof(struct sockaddr_in)) <0)
                     syslog(LOG_NOTICE,"sendto after Start Command:%s\n",strerror(errno));
                daemon_restart();
               }
	     break;
	    }
	  break;
          case 1:
          log_texts.len_ad=ccvt;
          log_texts.host=svt_from;
          time(&timer);
          memcpy(log_texts.date,ctime(&timer),26);
          for(k=0;k<26;k++)
            if(log_texts.date[k]=='\n')
              log_texts.date[k]=0;
          buf2[101]=0;
          strcpy(log_texts.b_text,buf2+2);
          ++log_mans.plan_num;
          if(log_mans.plan_num > max_p)
            {
             log_mans.plan_num=1;
             log_mans.fl_cy=1;
            }
          crd[0]=crd[1]=log_mans.plan_num;
          crd[2]=crd[3]=crd[4]=1;
          crd[5]=4;
          if((k=dtwdbl(&log_texts,sizeof(struct log_text),crd,tb_id1))<0)
            {
             syslog(LOG_NOTICE,"err.dtwdbl %s = %x\n",tab1,k);
	     rcldbl(tb_id1);
             tb_id1=opnglb(tab1,use_name,&i);
            }
          crd[0]=crd[1]=1;
          if((k=dtwdbl(&log_mans,sizeof(struct log_man),crd,tb_id2))<0)
            {
             syslog(LOG_NOTICE,"err.dtwdbl %s = %x\n",tab2,k);
	     rcldbl(tb_id2);
             tb_id2=opnglb(tab2,use_name,&i);
            }

          break;
          case 2:
          break;
          default:
          syslog(LOG_NOTICE,"Not my packet:%d from=>%d %d %d %d\n",
            buf2[0]&255
            ,svt_from.sa_data[2]&255
            ,svt_from.sa_data[3]&255
            ,svt_from.sa_data[4]&255
            ,svt_from.sa_data[5]&255
             );
          break;
         }
      }
   }

