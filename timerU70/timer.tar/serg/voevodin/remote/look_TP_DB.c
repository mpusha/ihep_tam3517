/*    14.11.2007
     загрузка без параметров     - технологические параметры
     загрузка с любым параметром - физические параметры
*/
#include "/usr/usera/voevodin/remote/ccydalib/ccydalib.h"
#include <errno.h>
#include <syslog.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <sys/time.h>

static struct glob_mem {
	struct sddbd ddbd;	/* DDBD tuple */
	char base_nam[60];	/* base name */
		/* parent table ID=0 not opened */
	  	/* child  copy  ID=0 not exist  */
	  	/* micro  copy  ID=0 not exist  */
	struct g_main glb;
      } opis;
struct tup_opis {
        unsigned short n_tup;
        unsigned short n_attr;
        unsigned short tup_len;
        unsigned short n_plan;
        unsigned char r_type;
        unsigned char r_stat;
            }  r_opis;
struct T_pass {
        short flag1;     /* is set by appl. if <0 - error code */
        short flag2;     /*  */
        short copy;
        char par_name[16];
        char out_form[10];
        short num_items;
        short num_plane;
        short par_type;
            } T_pas;
static short j;
int    i,l,k;
char dae_name[100];
static int bptr;
static char f_nm[]={"/usr/usera/voevodin/ddbd"},use_name[]={""};
static char f_TP[]={"_TP_"};      // Technological passports
static char f_PP[]={"_PP_"};      // Physical passports
static short crd[7],tb_id;
extern char *cel_rd();
static unsigned long N_tab=0,N_par=0,N_str=0;  // tables, parameters, tuples
static char *XX;
main(int argc, char ** argv)
   {
    if((bptr=open(f_nm,O_RDONLY))== -1)
      {
       printf("Err.open file %s\n",f_nm);
       exit(0);
      }
    crd[4]=1;
    crd[5]=8;
    crd[6]=1;
    lseek(bptr,0,SEEK_SET);
    while(read(bptr,&opis,sizeof(struct glob_mem)))
     {
      if(argc==1)
        XX=strstr(opis.ddbd.rena,f_TP);
      else
        XX=strstr(opis.ddbd.rena,f_PP);
      if( XX )  // TP/PP table
       {
        printf("%s\n",opis.ddbd.rena);
        ++N_tab;
        if((tb_id=opnglb(opis.ddbd.rena,use_name,&j))<0)
          {
           printf("   err.open '%s' = %x\n",opis.ddbd.rena,tb_id);
           exit(0);
          }
        if(j=rlpdbl(&r_opis,tb_id))
          {
           printf("    Err. rlpdbl '%s' =  %x\n",opis.ddbd.rena,j);
           exit(0);
          }
        for(i=1;i<=r_opis.n_plan;i++)
         {
          crd[0]=crd[1]=i;
          for(l=1;l<=r_opis.n_tup;l++)
            {
             ++N_str;
             crd[2]=crd[3]=l;
             if((j=dtrdbl(&T_pas,sizeof(struct T_pass),crd,tb_id))<0)
              {
               printf("   err.dtrdbl %s = %x \n",opis.ddbd.rena,j);
               exit(0);
              }
             if(T_pas.par_name[0])
              if(strcmp("reserve",T_pas.par_name))
              {
               T_pas.par_name[15]=0;
               printf("   %s\n",T_pas.par_name);
               ++N_par;
              }
            }
         }
       }
     }
    close(bptr);
    if(argc==1)
      {
       printf("Число TP таблиц =%ld, суммарное число строк в этих таблицах =%ld\n",N_tab,N_str);
       printf("Число именованных технологических параметров=%ld\n",N_par);
      }
    else
      {
       printf("Число PP таблиц =%ld, суммарное число строк в этих таблицах =%ld\n",N_tab,N_str);
       printf("Число именованных физических параметров=%ld\n",N_par);
      }
   }


