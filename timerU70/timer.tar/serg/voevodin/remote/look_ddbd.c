#include "/usr/usera/voevodin/remote/ccydalib/ccydalib.h"
#include <errno.h>
#include <syslog.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/time.h>

static struct glob_mem {
	struct sddbd ddbd;	/* DDBD tuple */
	char base_nam[60];	/* base name */
		/* parent table ID=0 not opened */
	  	/* child  copy  ID=0 not exist  */
	  	/* micro  copy  ID=0 not exist  */
	struct g_main glb;
      } opis;

typedef struct glob_mem *GPDD;

int    i=1,j_j,l,k,svt;
static int bptr;
static char f_nm[]={"/usr/usera/voevodin/ddbd"};
struct hostent *hp,*gethostbyname();
extern char *cel_rd();
char *s_s,bb[120];
char dae_name[100];
main()
   {
    letini(0);
    if((bptr=open(f_nm,O_RDONLY))== -1)
      {
       printf("Err.open file %s\n",f_nm);
       exit(0);
      }
    lseek(bptr,0,SEEK_SET);
    while(read(bptr,&opis,sizeof(struct glob_mem)))
      {
       printf("********************\n");
       printf("  %5d) Base %d ==> %s ==> table %s\n",i,opis.ddbd.dbti,
         opis.base_nam,opis.ddbd.rena);
       printf("       table name len=%d CRC=0x%x \n",opis.ddbd.lena&255,
         opis.ddbd.ncrc&255);
       printf("       attr=%d tuples=%d planes=%d tuplen=%d \n",
         opis.glb.tab_inf.nat,opis.glb.tab_inf.ntup,
           opis.glb.tab_inf.third,opis.glb.tab_inf.lotup);
       printf("       type=0x%x state=%d res1=%d res2=%d subsys=%d\n",
         opis.glb.tab_inf.rtype&255,opis.glb.tab_inf.rstate&255,
          opis.glb.tab_inf.res1,
           opis.glb.tab_inf.res2,opis.glb.tab_inf.nsub&255);
       printf("       owner=%d processor=%d nrt=%d nra=%d \n",
         opis.glb.tab_inf.nowner&255,opis.glb.tab_inf.nexlis.nrr,
           opis.glb.tab_inf.nexlis.nrt,opis.glb.tab_inf.nexlis.nra);
       if(opis.ddbd.n_parent)
         {
          if(re_tu(ncoms,opis.ddbd.n_parent,&COMP))
            goto childX;
          svt=COMP.ncompu;
          if((l=nnam(&svt,t_f))<0)
            goto childX;
          *(buf_+l+svt)=0;
          s_s=(char*)&opis.glb.parent.sin_addr;
          printf("       Parent ==> %s (%d.%d.%d.%d port=%d) ",buf_+l,
            s_s[0]&255,s_s[1]&255,s_s[2]&255,s_s[3]&255,
            ntohs(opis.glb.parent.sin_port));
          if(opis.glb.id_parent)
            printf(" is opened as %d\n",opis.glb.id_parent);
          else
            printf(" is not opened\n");
         }
childX:
       if(opis.ddbd.n_child)
         {
          if(re_tu(ncoms,opis.ddbd.n_child,&COMP))
            goto microX;
          svt=COMP.ncompu;
          if((l=nnam(&svt,t_f))<0)
            goto microX;
          *(buf_+l+svt)=0;
          s_s=(char*)&opis.glb.child.sin_addr;
          printf("       Child  ==> %s (%d.%d.%d.%d port=%d)",buf_+l,
            s_s[0]&255,s_s[1]&255,s_s[2]&255,s_s[3]&255,
            ntohs(opis.glb.parent.sin_port));
          if(opis.glb.id_child)
            printf(" is opened as %d\n",opis.glb.id_child);
          else
            printf(" is not opened\n");
         }
microX:
       if(opis.ddbd.n_micro)
         {
          if(re_tu(ncoms,opis.ddbd.n_micro,&COMP))
            goto comX;
          svt=COMP.ncompu;
          if((l=nnam(&svt,t_f))<0)
            goto comX;
          *(buf_+l+svt)=0;
          printf("       Micro  ==> %s BC=%d RT=%d ",buf_+l,COMP.bus_c,
            COMP.rem_t);
          svt=COMP.nhost;
          if((l=nnam(&svt,t_f))>=0)
            {
             *(buf_+l+svt)=0;
             printf("FEC ==> %s ",buf_+l);
            }
          if(opis.glb.id_micro)
            printf(" is opened as &%x BC=%d RT=%d\n",opis.glb.id_micro&0xffff,
              opis.glb.BC&255,opis.glb.RT&255);
          else
            printf(" is not opened\n");
         }
comX:
       ++i;
      }
    close(bptr);
   }


