/*
                  ws_test
               ------------
    1.Send message to alarmd
*/
#include "/usr/usera/voevodin/remote/ccydalib/ccydalib.h"
#include <errno.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/time.h>
#include <unistd.h>
#include <time.h>
#include <sys/signal.h>

int  svt;
static struct sockaddr_in sin;

main()
   {
//    daemon_init();
    letini(0);
    Xt_al_ini();
    if((svt=socket(AF_INET,SOCK_DGRAM,0)) < 0)
      printf("socket:%s\n",strerror(errno));
    sin.sin_family=AF_INET;
    sin.sin_port  = 0;
    if(bind(svt,(struct sockaddr*)&sin,sizeof(sin)))
      printf("bind:%s\n",strerror(errno));
    Xt_al_text(svt,"Hello, world!!!");
   }
