/**************************************************************************
                Test for 'double' values for 64-bits processor (Alpha)
**************************************************************************/
#include <stdio.h>
#include <values.h>

union dlc
{
  char cha[8];
  double d;
  unsigned long int l;
};
int main( void )
{
  union dlc z1, z2, z3;
  int fl;
  printf( "'double  ' type length: %d bytes\n", sizeof( double ) );
  printf( "'long int' type length: %d bytes\n", sizeof( long int ) );
  z1.d=MINDOUBLE;
  z2.l=0x8000000000000000L;
  do
  {
    fl=0;
    z2.l=z2.l >> 1;
    if (!(z2.l & 0x7ff0000000000000L))
      if ((z2.l & 0x000fffffffffffffL)) fl=1;
    printf( "min=%016lx=%g, value=%016lx=%g -> %s\n",
             z1.l, z1.d, z2.l, z2.d, fl?"bad":"well" );
    printf("min=%2x %2x %2x %2x %2x %2x %2x %2x value=%2x %2x %2x %2x %2x %2x %2x %2x\n",
     z1.cha[0]&255,z1.cha[1]&255,z1.cha[2]&255,z1.cha[3]&255,
      z1.cha[4]&255,z1.cha[5]&255,z1.cha[6]&255,z1.cha[7]&255,
     z2.cha[0]&255,z2.cha[1]&255,z2.cha[2]&255,z2.cha[3]&255,
      z2.cha[4]&255,z2.cha[5]&255,z2.cha[6]&255,z2.cha[7]&255);
    z3.d=z2.d+2.;  /* if bad then break */
  } while (z2.l != 0x0000000000000001L);
  return 0;
}
/*************************************************************************/

