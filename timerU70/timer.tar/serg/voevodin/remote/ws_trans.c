/*
                  ws_trans
               ------------
    1.Get requests on usis03 to access SSUDA and resend it to CS
    2.Get replies from CS and resend it to requester
*/
#include "/usr/usera/voevodin/remote/ccydalib/ccydalib.h"
#include <errno.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/time.h>
#include <unistd.h>
#include <time.h>
#include <sys/signal.h>

static struct bbod {
        char addr[4];
        u_short port;
        struct DDBD_rwr_pac in_pckt;
       } ;
union input {
        struct bbod in_bb;
        char pac[max_gb+10];
       } bbo;
int    i,j,l,k,m,svt,s1;
long ccvt;
static char buf[max_gb],bb_b[80];
static struct sockaddr svt_from;
static struct sockaddr_in sin,sin1;
struct hostent *hp,*gethostbyname();
fd_set read_template;
struct timeval wait;

main()
   {
    daemon_init();
    openlog("ws_trans:",LOG_CONS,LOG_USER);
    Xt_al_ini();
/* socket to get requests */
    if((svt=socket(AF_INET,SOCK_DGRAM,0)) < 0)
      syslog(LOG_NOTICE,"socket:%s\n",strerror(errno));
    sin1.sin_family=sin.sin_family=AF_INET;
    sin.sin_port  = htons(5995);
    if(bind(svt,(struct sockaddr*)&sin,sizeof(sin)))
      syslog(LOG_NOTICE,"bind:%s\n",strerror(errno));
/* socket to get replys on packet */
    if((s1=socket(AF_INET,SOCK_DGRAM,0)) < 0)
      syslog(LOG_NOTICE,"socket:%s\n",strerror(errno));
    sin1.sin_port  = htons(0);
    if(bind(s1,(struct sockaddr*)&sin1,sizeof(sin)))
      syslog(LOG_NOTICE,"bind:%s\n",strerror(errno));
    while(1)
      {
       ccvt=sizeof(struct sockaddr);
       while((l=recvfrom(svt,&bbo,max_gb,0,&svt_from,
         &ccvt)) <= 0)
           {
            if(l < 0 && errno == ECONNREFUSED)
              continue;
            sprintf(bb_b,"ws_rwr:recvfrom: %d bytes from %d %d %d %d errno=%d",l
              ,svt_from.sa_data[2]&255
              ,svt_from.sa_data[3]&255
              ,svt_from.sa_data[4]&255
              ,svt_from.sa_data[5]&255,errno);
            syslog(LOG_NOTICE,"%s\n",bb_b);
            syslog(LOG_NOTICE,"%s\n",strerror(errno));
            Xt_al_text(svt,bb_b);
           }
       sin1.sin_port=bbo.in_bb.port;
       memcpy(&sin1.sin_addr,bbo.in_bb.addr,4);
       if(sendto(s1,&bbo.in_bb.in_pckt,l,0,(struct sockaddr*)&sin1,
         sizeof(struct sockaddr_in)) <0)
           {
            syslog(LOG_NOTICE,"sendto:%s\n",strerror(errno));
            continue;
           }
       wait.tv_sec=19;
       wait.tv_usec=0;
       FD_ZERO(&read_template);
       FD_SET(s1,&read_template);
       if(select(FD_SETSIZE,&read_template,(fd_set*)0,(fd_set*)0,&wait) <0 )
         syslog(LOG_NOTICE,"select:%s\n",strerror(errno));
       if(FD_ISSET(s1,&read_template))
         {
          if((k=read(s1,buf,max_gb))<=0)
            {
             syslog(LOG_NOTICE,"read:%s\n",strerror(errno));
             continue;
            }
          if(sendto(svt,buf,k,0,&svt_from
            ,sizeof(struct sockaddr_in)) <0)
              syslog(LOG_NOTICE,"sendto reply:%s\n",strerror(errno));
         }
       else
         {
          syslog(LOG_NOTICE,"ws_rwr:Time out on reply from CS\n");
          continue;
         }
      }
   }


