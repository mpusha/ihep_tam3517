/*
	:          DDBD_mem
	:      ----------------
	:  1. Create description of all Global tables in the memory
	:  2. Accept opnglb from applications
	:  3. Accept initialize table in FE & EC memory
        :  4. Close opened tables on ws_rwr initialization
        :  5. Close opened tables on fe_rwr initialization
        :  6. Stop on command from DSC
        :  7. Start on command from DSC
*/

#include "/usr/usera/voevodin/remote/ccydalib/ccydalib.h"
#include <errno.h>
#include <syslog.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>

static struct glob_mem {
	struct sddbd ddbd;	/* DDBD tuple */
	char base_nam[60];	/* base name */
		/* parent table ID=0 not opened */
	  	/* child  copy  ID=0 not exist  */
	  	/* micro  copy  ID=0 not exist  */
	struct g_main glb;
      } *opis;
static struct Que {
	short glob_id;	         /* num.in glob_mem */
	short pct_tip;	         /* 0 ==> free */
	struct sockaddr_in app_pr;  /* addr.of caller host */
        time_t ttt;              /* time of request */
       } rep_que[100];

struct DDBD_rwr_pac in_pckt,out_pckt;
typedef struct glob_mem *GPDD;

short i16ir(),i16im(),i16ri(),i16rm(),i16mi(),i16mr();
static short f_list[3][3]={
    {0,1,2},   /*i to r,i to m*/
    {3,0,4},   /*r to i,r to m*/
    {5,6,0},   /*m to i,m to r*/
   };
int    i,j_j,l,k,svt;
static int bptr,fla_1,fla_2;
static char f_nm[]={"/usr/usera/voevodin/ddbd"};
static char f1_nm[]={"/usr/usera/voevodin/ddbd_list"};
static char f2_nm[]={"/usr/usera/voevodin/ddbd_que"};
FILE *fsave;
socklen_t  ccvt;
static struct sockaddr_in sin,svt_from;
static struct sockaddr *svt_fromX;
struct hostent *hp,*gethostbyname();
extern char *cel_rd();
char bb[120],dae_name[100];

main(int argc, char *argv[])
   {
    strcpy(dae_name, argv[0]);
    daemon_init();
    openlog("ddbd_mem:",LOG_CONS,LOG_USER);
    letini(0);
    Xt_al_ini();
    fla_2=0;
    if(!set_rel(nddbd))
       {
ex_0:
        printf("DDBD is absent\n");
        syslog(LOG_NOTICE,"DDBD is absent\n");
        exit(0);
       }
    block = to_cat[0].rel_dat_b + patc->alb;
    offs = patc->alo;
    i=n_tup-1;			/* from tuple 2 */
    j_j=0;
    redbl(cdb[0],block,buf_,size2b);
    while(i--)
      {
       nex_t();	          	/* from tuple 2 */
       if(buf_[offs]) ++j_j;	/* j_j = num.of global tables */
      }
    if(!j_j)
      {
       printf("No global tables\n");
       syslog(LOG_NOTICE,"No global tables\n");
       exit(0);
      }
    i= j_j * sizeof(struct glob_mem);
    opis = (GPDD)malloc(i);
    if(!opis)
      {
       printf("DDBD_mem:No memory\n");
       syslog(LOG_NOTICE,"DDBD_mem:No memory\n");
       exit(0);
      }
    if(!set_rel(nddbd)) goto ex_0;
    block = to_cat[0].rel_dat_b + patc->alb;
    offs = patc->alo;
    i=n_tup-1;			/* from tuple 2 */
    k=0;
    redbl(cdb[0],block,buf_,size2b);
    fsave=fopen(f1_nm,"w");
    while(i--)
      {
       nex_t();	          	/* from tuple 2 */
       if(buf_[offs])
         {
          memcpy(&(opis+k)->ddbd,buf_+offs,l_tup);
          fprintf(fsave,"%d.  %s\n",k+1,(opis+k)->ddbd.rena);
         }
       k++;
      }
    fclose(fsave);
    i=j_j;
    k=0;
    while(i--)
      {
       if(re_tu(nbss,(opis+k)->ddbd.dbti,(opis+k)->base_nam))
         {
ex_1:
          printf("DDBD_mem:Error global table %s\n",(opis+k)->ddbd.rena);
          syslog(LOG_NOTICE,"DDBD_mem:Error global table %s\n",(opis+k)->ddbd.rena);
          exit(0);
         }
       (opis+k)->glb.id_parent=(opis+k)->glb.id_child=
          (opis+k)->glb.id_micro=0; /*not opened*/
       (opis+k)->glb.parent.sin_family=AF_INET;
       (opis+k)->glb.child.sin_family =AF_INET;
       (opis+k)->glb.parent.sin_port  = htons(5996);
       (opis+k)->glb.child.sin_port   = htons(5996);
       if(re_tu(ncoms,(opis+k)->ddbd.n_parent,&COMP)) goto ex_1;
               /* parent processor type */
       (opis+k)->glb.tab_inf.nexlis.nrr=COMP.type_pro&255;
       svt=COMP.ncompu;
       if((l=nnam(&svt,t_f))<0) goto ex_1;
       *(buf_+l+svt)=0;
       if(!(hp=gethostbyname(buf_+l)))
         {
          syslog(LOG_NOTICE,"parent gethostbyname:%s\n",strerror(errno));
          goto ex_1;
         }
       memcpy(&(opis+k)->glb.parent.sin_addr,hp->h_addr,hp->h_length);
       if((opis+k)->ddbd.n_child)	/* child RAM */
         {
          if(re_tu(ncoms,(opis+k)->ddbd.n_child,&COMP)) goto ex_1;
               /* child processor type */
          (opis+k)->glb.tab_inf.nexlis.nrt=COMP.type_pro&255;
          svt=COMP.ncompu;
          if((l=nnam(&svt,t_f))<0) goto ex_1;
          *(buf_+l+svt)=0;
          if(!(hp=gethostbyname(buf_+l)))
            {
             syslog(LOG_NOTICE,"child gethostbyname:%s\n",strerror(errno));
             goto ex_1;
            }
          memcpy(&(opis+k)->glb.child.sin_addr,hp->h_addr,hp->h_length);
         }
       if((opis+k)->ddbd.n_micro)	/* micro RAM */
         {
          if(re_tu(ncoms,(opis+k)->ddbd.n_micro,&COMP)) goto ex_1;
               /* micro processor type */
          (opis+k)->glb.tab_inf.nexlis.nra=COMP.type_pro&255;
          (opis+k)->glb.BC=COMP.bus_c;
          (opis+k)->glb.RT=COMP.rem_t;
         }
       ++k;	/* next global table */
      }
    printf("\nThere are %d global tables. Net address length=%d\n",
     j_j,hp->h_length);
    syslog(LOG_NOTICE,"\nThere are %d global tables. Net address length=%d\n",
     j_j,hp->h_length);
    fsave=fopen("/usr/users/ssuda1/work/cs_N_1.txt","w");
    fprintf(fsave,"Распределённые БД ССУДА хранят %d глобальных таблиц\n",j_j);
    chmod("/usr/users/ssuda1/work/cs_N_1.txt",S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH);
    fclose(fsave);
    fla_1=0;
    if((bptr=creat(f_nm,0666))== -1)
      printf("Err.open file %s\n",f_nm);
    lseek(bptr,0,SEEK_SET);
    write(bptr,opis,j_j*sizeof(struct glob_mem));
    if((svt=socket(AF_INET,SOCK_DGRAM,0)) < 0)
      syslog(LOG_NOTICE,"socket:%s\n",strerror(errno));
    sin.sin_family=AF_INET;
    sin.sin_port  = htons(5995);
    if(bind(svt,(struct sockaddr*)&sin,sizeof(sin)))
      syslog(LOG_NOTICE,"bind:%s\n",strerror(errno));
    while(1)
      {
       in_pckt.pac_tip=0;
       ccvt=sizeof(struct sockaddr);
       while((l=recvfrom(svt,&in_pckt,sizeof(in_pckt),0,
         (struct sockaddr*)&svt_from,&ccvt)) <= 0)
           {
            if(l < 0 && errno == ECONNREFUSED)
              continue;
            if(fla_2)  /* program is stopped by DSC */
              continue;
            svt_fromX=(struct sockaddr*)&svt_from;
            sprintf(bb,"DDBD:recvfrom: %d bytes from %d %d %d %d errno=%d",l
              ,svt_fromX->sa_data[2]&255
              ,svt_fromX->sa_data[3]&255
              ,svt_fromX->sa_data[4]&255
              ,svt_fromX->sa_data[5]&255,errno);
            syslog(LOG_NOTICE,"%s\n",bb);
            syslog(LOG_NOTICE,"%s\n",strerror(errno));
            Xt_al_text(svt,bb);
           }
       if(fla_2)
         {
          if(in_pckt.pac_tip == 6)
            goto dal;
          if(in_pckt.pac_tip == 7)
            goto dal;
          continue;
         }
dal:
       fla_1=0;
       if(!(hp=gethostbyaddr((char*)&svt_from.sin_addr,4,
        svt_from.sin_family)))
         {
          syslog(LOG_NOTICE,"gethostbyaddr:%s\n",strerror(errno));
          continue;
         }
       strcpy(bb,hp->h_name);
       for(l=0;l<sizeof(bb);l++)
         if(bb[l]=='.')
           bb[l]=0;
       if(!(l=namn(bb,0,t_f)))
         {
          syslog(LOG_NOTICE,"namn for %s\n",bb);
          continue;
         }
       i=1;
       while(!re_tu(ncoms,i,&COMP))
         {
          ++i;
          if(l==COMP.ncompu)
            goto Com_yes;
         }
       syslog(LOG_NOTICE,"Err. read tuple for computer %d tuple=%d\n",l,i);
       continue;
Com_yes:
       cur_type=COMP.type_pro;
       switch(in_pckt.pac_tip)
         {
          case 0:       /* ws_rwr was reloaded */
          for(i=0;i<j_j;i++)
            if((opis+i)->ddbd.n_parent==l)
              (opis+i)->glb.id_parent=0;
          break;
          case 1:	/* opnglb */
          if((k=fi_crc(in_pckt.t_nam)) <0 )   /* no such table */
            {
             syslog(LOG_NOTICE,"No such Table in DB ==>%s\n",in_pckt.t_nam);
             in_pckt.glb.id_parent=0;
             in_pckt.glb.id_child=0x8040;
             goto err_t;
            }
          if(!(opis+k)->glb.id_parent) goto not_ope;
          if(!(opis+k)->glb.id_child && (opis+k)->glb.tab_inf.rtype&16)
            goto not_ope;
/*          if(!(opis+k)->glb.id_micro && (opis+k)->glb.tab_inf.rtype&128)
            goto not_ope;
*/
          goto yes_ope;
          case 2:       /* fe_rwr was reloaded */
          for(i=0;i<j_j;i++)
            if((opis+i)->ddbd.n_child==l)
              (opis+i)->glb.id_child=0;
          break;
          case 3:	/* initialize table in FE & EC */
          case 4:	/* initialize table in FE */
          case 5:	/* initialize table in EC */
          if((k=fi_crc(in_pckt.t_nam)) <0 )
            {
             printf("%s not found\n",in_pckt.t_nam);
             syslog(LOG_NOTICE,"%s not found\n",in_pckt.t_nam);
             break;  /* no such table */
            }
not_ope:
          if((l=fi_fr_q())==255)
            {
             fsave=fopen(f2_nm,"w");
             for(i=0;i<100;i++)
               {
                memcpy(bb,(char*)&rep_que[i].app_pr.sin_addr,4);
                fprintf(fsave,"%d. ",i+1);
                fprintf(fsave," glob_id=%d processor=%d port=%d %d.%d.%d.%d \n",
                  rep_que[i].glob_id,rep_que[i].pct_tip,ntohs(rep_que[i].app_pr.sin_port),
                    bb[0]&255,bb[1]&255,
                      bb[2]&255,bb[3]&255);
               }
             fclose(fsave);
             printf("DDBD_mem:Que is full!!!\n");
             Xt_al_text(svt,"DDBD_mem:Que is full!!!\n");
             syslog(LOG_NOTICE,"DDBD_mem:Que is full!!!\n");
             continue;
            }
          fill_que();
          fill_out();
          if((k=sendto(svt,&out_pckt,sizeof(struct DDBD_rwr_pac),0,
            (struct sockaddr*)&(opis+k)->glb.parent,sizeof(struct sockaddr))) <0 )
              syslog(LOG_NOTICE,"sendto:%s\n",strerror(errno));
          break;
          case 6:       /* stop till start */
          if(fla_2)
            {
             syslog(LOG_NOTICE,"I got Double Stop Command\n");
            }
          else
            {
             fla_2=1;
             syslog(LOG_NOTICE,"I start Stop Operation\n");
             out_pckt.pac_tip=out_pckt.n_proces=88;
             if(sendto(svt,&out_pckt,8,0,(struct sockaddr*)&svt_from
               ,sizeof(struct sockaddr_in)) <0)
                  syslog(LOG_NOTICE,"sendto after Stop Command:%s\n",strerror(errno));
            }
          continue;
          case 7:       /* start after stop */
          if(!fla_2)
            {
             syslog(LOG_NOTICE,"I got Start Command without Stop\n");
            }
          else
            {
             fla_2=0;
             syslog(LOG_NOTICE,"I Restart Operation %s\n",dae_name);
             out_pckt.pac_tip=out_pckt.n_proces=89;
             if(sendto(svt,&out_pckt,8,0,(struct sockaddr*)&svt_from
               ,sizeof(struct sockaddr_in)) <0)
                  syslog(LOG_NOTICE,"sendto after Start Command:%s\n",strerror(errno));
             daemon_restart();
            }
          continue;
          case 11:	/* reply to opnglb */
          rest_que();
          if(in_pckt.glb.id_parent)
            {
             (opis+k)->glb.id_parent=in_pckt.glb.id_parent;
             (opis+k)->glb.id_child=in_pckt.glb.id_child;
             (opis+k)->glb.id_micro=in_pckt.glb.id_micro;
             memcpy(&(opis+k)->glb.tab_inf,&in_pckt.glb.tab_inf,
               sizeof(struct relis)-sizeof(struct relref));
             (opis+k)->glb.tab_inf.res1=(opis+k)->ddbd.dbti; /* for ssudalib */
yes_ope:
             memcpy(&in_pckt.glb.id_parent,&(opis+k)->glb.id_parent,
                 sizeof(struct g_main));
/*printf("k=%d 1=%s 2=%s p=%d c=%d m=%d\n\15",k,in_pckt.t_nam,
(opis+k)->ddbd.rena,
(opis+k)->glb.id_parent,
(opis+k)->glb.id_child,
(opis+k)->glb.id_micro
);  */
             if(cur_type!=my_type)
               {
                mypreob16(&in_pckt.glb.tab_inf.res1);
                mypreob16(&in_pckt.glb.tab_inf.res2);
                mypreob16(&in_pckt.glb.tab_inf.nexlis.nrr);
                mypreob16(&in_pckt.glb.tab_inf.nexlis.nrt);
                mypreob16(&in_pckt.glb.tab_inf.nexlis.nra);
                mypreob16(&in_pckt.glb.tab_inf.ntup);
                mypreob16(&in_pckt.glb.tab_inf.nat);
                mypreob16(&in_pckt.glb.tab_inf.lotup);
                mypreob16(&in_pckt.glb.tab_inf.third);
                mypreob16(&in_pckt.glb.parent.sin_family);
                mypreob16(&in_pckt.glb.child.sin_family);
               }
             if(sendto(svt,&in_pckt.glb.id_parent,sizeof(struct g_main),0,
               (struct sockaddr*)&svt_from,sizeof(struct sockaddr)) <0 )
                 syslog(LOG_NOTICE,"send:%s\n",strerror(errno));
             fla_1=1;
            }
          else   /* error open */
            {
err_t:
             if(sendto(svt,&in_pckt.glb.id_parent,sizeof(struct g_main),0,
               (struct sockaddr*)&svt_from,sizeof(struct sockaddr)) <0 )
                 syslog(LOG_NOTICE,"send:%s\n",strerror(errno));
            }
          break;
          case 13:	/* reply to 3 */
          rest_que();
          (opis+k)->glb.id_child=in_pckt.glb.id_child;
          (opis+k)->glb.id_micro=in_pckt.glb.id_micro;
          if(sendto(svt,&(opis+k)->glb.id_child,4,0,(struct sockaddr*)&svt_from,
            sizeof(struct sockaddr)) <0 )
              syslog(LOG_NOTICE,"send:%s\n",strerror(errno));
          break;
          case 14:	/* reply to 4 */
          rest_que();
          (opis+k)->glb.id_child=in_pckt.glb.id_child;
          if(sendto(svt,&(opis+k)->glb.id_child,2,0,(struct sockaddr*)&svt_from,
            sizeof(struct sockaddr)) <0 )
              syslog(LOG_NOTICE,"send:%s\n",strerror(errno));
          break;
          case 15:	/* reply to 5 */
          rest_que();
          (opis+k)->glb.id_micro=in_pckt.glb.id_micro;
          if(sendto(svt,&(opis+k)->glb.id_micro,2,0,(struct sockaddr*)&svt_from,
            sizeof(struct sockaddr)) <0 )
              syslog(LOG_NOTICE,"send:%s\n",strerror(errno));
          break;
          case 99:
          syslog(LOG_NOTICE,"ddbd_mem:Was packet 99\n");
          rest_que();
          break;
          default:
          syslog(LOG_NOTICE,"ddbd_mem:Was bad packet %d\n",in_pckt.pac_tip);
          memset(&out_pckt,0,sizeof(out_pckt));
          if(sendto(svt,&out_pckt,sizeof(out_pckt),0,(struct sockaddr*)&svt_from,
            sizeof(struct sockaddr)) <0 )
              syslog(LOG_NOTICE,"send:%s\n",strerror(errno));
          break;
         }
       if(fla_1)
         {
          lseek(bptr,0,SEEK_SET);
          write(bptr,opis,j_j*sizeof(struct glob_mem));
         }
      }
   }
nex_t()
   {
    offs += l_tup;
    if(offs+l_tup > size2b)
      {
       offs -= sizeb;
       ++block;
       redbl(cdb[0],block,buf_,size2b);
      } 
   }
fi_crc(name)
 char *name;
  {
   unsigned short nm_l=0,i,j;
   register crc_0=0;

    while(name[nm_l])
      {
       i=0;
       crc_0 ^= name[nm_l];
       if(crc_0 & 0x80) i= 0x39;	/**** genpol ***/
       crc_0 = crc_0 <<1^i;
       ++nm_l;
      }
    crc_0 &=255;
    nm_l &= 255;
    for(n_tup=0;n_tup<j_j;n_tup++)
      {
        if(nm_l!=((opis+n_tup)->ddbd.lena&255) || crc_0!=((opis+n_tup)->ddbd.ncrc&255))
          continue;
        for(i=0;i<nm_l;i++)
	  if(name[i]!=(opis+n_tup)->ddbd.rena[i])
            goto het_;
        return(n_tup);	/* number in the glob_mem */
het_:
       continue;
      }
    return(-1);
  }
fi_fr_q()
   {
    register x;
    time_t curt;
    curt=time(NULL);
    for(x=0;x<100;x++)
      {
       if(rep_que[x].pct_tip == 0)
         return(x);
       if(curt-rep_que[x].ttt > 120)  /* time out */
         {
          rep_que[x].pct_tip=0;        /* free que */
            return(x);
         }
      }
    return(255);	/* que is full */
   }
fill_que()
  {
   rep_que[l].glob_id=k;
   rep_que[l].pct_tip=cur_type; /*  processor type on appl. */
   rep_que[l].app_pr=svt_from;
   rep_que[l].ttt=time(NULL);
  }
rest_que()
  {
   l=in_pckt.n_que;
   k=rep_que[l].glob_id;
   svt_from=rep_que[l].app_pr;
   cur_type=rep_que[l].pct_tip;
   rep_que[l].pct_tip=0;        /* free que */
  }
fill_out()
  {
   out_pckt.pac_tip=in_pckt.pac_tip;
   out_pckt.pac_flag=in_pckt.pac_flag;
   out_pckt.bd_num=(opis+k)->ddbd.dbti;
   out_pckt.n_que=l;
   out_pckt.n_proces=my_type;
   out_pckt.glb.tab_inf.nexlis.nrt=(opis+k)->glb.tab_inf.nexlis.nrt; /* child */
   out_pckt.glb.tab_inf.nexlis.nra=(opis+k)->glb.tab_inf.nexlis.nra; /* micro */
   out_pckt.glb.BC=(opis+k)->glb.BC;
   out_pckt.glb.RT=(opis+k)->glb.RT;
   out_pckt.glb.child=(opis+k)->glb.child;
   memcpy(out_pckt.t_nam,(opis+k)->ddbd.rena,20);
   memcpy(out_pckt.b_nam,(opis+k)->base_nam,60);
   if(my_type == (opis+k)->glb.tab_inf.nexlis.nrr) return(0);
   mypreob16(&out_pckt.bd_num);
   mypreob16(&out_pckt.glb.tab_inf.nexlis.nrt);
   mypreob16(&out_pckt.glb.tab_inf.nexlis.nra);
  }
mypreob16(i16)
  short *i16;
   {
    switch(f_list[my_type-1][cur_type-1])
      {
       case 1:
       *i16=i16ir(*i16);
       break;
       case 2:
       *i16=i16im(*i16);
       break;
       case 3:
       *i16=i16ri(*i16);
       break;
       case 4:
       *i16=i16rm(*i16);
       break;
       case 5:
       *i16=i16mi(*i16);
       break;
       case 6:
       *i16=i16mr(*i16);
       break;
      }
   }


