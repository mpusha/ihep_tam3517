/*
	:         tabstart 
	:      ----------------
*/

#include "/usr/usera/voevodin/rt-data/ccydalib/ccydalib.h"
#include <errno.h>
#include <stdio.h>
#include <sys/time.h>

struct DDBD_rwr_pac out_pckt;

int    i,j_j,l,k,svt,ccvt;
char buf[256],buf2[]={"pcoku3"};

fd_set read_template;
struct timeval wait;
static struct sockaddr_in sin,svt_from;
struct hostent *hp,*gethostbyname();

main()
   {
    if((svt=socket(AF_INET,SOCK_DGRAM,0)) < 0)
      perror("tabstart:socket");
    sin.sin_family=AF_INET;
    sin.sin_port  = htons(0);
    if(bind(svt,(struct sockaddr*)&sin,sizeof(sin)))
      perror("tabstart:bind");
    if(!(hp=gethostbyname(buf2)))
      perror("gethostbyname");
    svt_from.sin_family=AF_INET;
    svt_from.sin_port  = htons(5995);
    bcopy(hp->h_addr,&svt_from.sin_addr,hp->h_length);
eche:
    out_pckt.pac_tip=5;    /* load table to EC */
    printf("Global table name:");
    gets(out_pckt.t_nam);
    if((k=sendto(svt,&out_pckt,sizeof(out_pckt),0,(struct sockaddr*)&svt_from,
      sizeof(svt_from))) < 0)
        perror("send");

    wait.tv_sec=30;
    wait.tv_usec=0;
    FD_ZERO(&read_template);
    FD_SET(svt,&read_template);
    k=select(FD_SETSIZE,&read_template,(fd_set*)0,(fd_set*)0,&wait);
    if(k<0) goto eche;
    *(short *)buf=0;
    if(FD_ISSET(svt,&read_template))
      {
       if((l=read(svt,buf,256))<0)
         perror("read");
       if(*(short *)buf)
         printf("Table is loaded as %x\n",*(short *)buf);
       else
         printf("Table is not loaded\n");
       goto eche;
      }
    printf("tabstart:Time out\n");
    goto eche;
   }


