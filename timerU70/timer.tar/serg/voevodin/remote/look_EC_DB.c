#include "/usr/usera/voevodin/remote/ccydalib/ccydalib.h"
#include <errno.h>
#include <syslog.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/time.h>

#define Num_of_MIL 20
#define Num_of_EC_tabs 2000

static struct glob_mem {
	struct sddbd ddbd;	/* DDBD tuple */
	char base_nam[60];	/* base name */
		/* parent table ID=0 not opened */
	  	/* child  copy  ID=0 not exist  */
	  	/* micro  copy  ID=0 not exist  */
	struct g_main glb;
      } opis;
struct tup_opis {
        unsigned short n_tup;
        unsigned short n_attr;
        unsigned short tup_len;
        unsigned short n_plan;
        unsigned char r_type;
        unsigned char r_stat;
            }  r_opis;
static short j;
static unsigned short bs,n,M_index=0, M_index1=0, M_index2=0, M_mic[100];  // M_index1
static struct M_tab {
      char relnam[20];
      short dbti;
      short n_micro;
      short n_parent;
      long length;
     } M_array[Num_of_EC_tabs];   //  M_index
static struct MIL {
      long length;
      char ds_name[20];
      char BC;
     } bc_mil[Num_of_MIL];   // M_index2
int    i,l,k,svt;
static int bptr;
static char f_nm[]={"/usr/usera/voevodin/ddbd"};
struct hostent *hp,*gethostbyname();
extern char *cel_rd();
char *s_s,bb[120];
char dae_name[100];
unsigned long Sum_total=0, Sum_EC;
main()
   {
    letini(0);
    memset(bc_mil, 0, sizeof(bc_mil));
    if((bptr=open(f_nm,O_RDONLY))== -1)
      {
       printf("Err.open file %s\n",f_nm);
       exit(0);
      }
    lseek(bptr,0,SEEK_SET);
    while(read(bptr,&opis,sizeof(struct glob_mem)))
     if(opis.ddbd.n_micro)  // If there is EC copy
       {
        for(k=0;k<M_index1;k++)
          if(M_mic[k]==opis.ddbd.n_micro)
            goto yes_1;
        M_mic[M_index1]=opis.ddbd.n_micro;
        ++M_index1;
yes_1:
        memcpy(M_array[M_index].relnam, opis.ddbd.rena, 20);
        M_array[M_index].length=opis.glb.tab_inf.ntup*opis.glb.tab_inf.third*opis.glb.tab_inf.lotup;
        if( ! M_array[M_index].length)
          {
           if( (j=opnglb(M_array[M_index].relnam, "", &bs) ) < 0)
            {
             printf("*** Err. to open %s ***\n",M_array[M_index].relnam);
            }
           else
            {
             if(n=rlpdbl(&r_opis,j))
               printf("*** Err. rlpdbl %x ***\n",n);
             else
              M_array[M_index].length=r_opis.n_tup*r_opis.tup_len*r_opis.n_plan;
            }
          }
        M_array[M_index].n_micro=opis.ddbd.n_micro;
        M_array[M_index].n_parent=opis.ddbd.n_parent;
        M_array[M_index].dbti=opis.ddbd.dbti;
        ++M_index;
       }
    close(bptr);
    for(k=0;k<M_index1;k++)
      {
       Sum_EC=0;
       for(i=0;i<M_index;i++)
        if(M_mic[k] == M_array[i].n_micro)
         {
          Sum_EC += M_array[i].length;
         }
       if(re_tu(ncoms, M_mic[k], &COMP))
         {
          printf("Error to read from COMPUTERS\n");
          exit(0);
         }
       svt=COMP.ncompu;
       if((l=nnam(&svt,t_f))<0)
         {
          printf("Error to get EC name\n");
          exit(0);
         }
       *(buf_+l+svt)=0;
       printf("%d.%s BC=%d RT=%d ",k+1,buf_+l,COMP.bus_c,COMP.rem_t);
       svt=COMP.nhost;
       if((l=nnam(&svt,t_f))>=0)
         {
          *(buf_+l+svt)=0;
          printf("FEC ==> %s Total Tables Size =%ld\n",buf_+l, Sum_EC);
         }
       if( !M_index2)   // Length for each MIL 1553
         {
          bc_mil[0].BC=COMP.bus_c;
          strcpy(bc_mil[0].ds_name, buf_+l);
          bc_mil[0].length=Sum_EC;
          ++M_index2;
          goto yes_2;
         }
       else
         for(j=0;j<M_index2;j++)
           if(bc_mil[j].BC==COMP.bus_c && !strcmp(bc_mil[j].ds_name, buf_+l))
             {
              bc_mil[j].length += Sum_EC;
              goto yes_2;
             }
         bc_mil[M_index2].BC=COMP.bus_c;
         strcpy(bc_mil[M_index2].ds_name, buf_+l);
         bc_mil[M_index2].length += Sum_EC;
         ++M_index2;
yes_2:
       Sum_total += Sum_EC;
       for(i=0;i<M_index;i++)
        if(M_mic[k] == M_array[i].n_micro)
         {
          if(re_tu(ncoms,M_array[i].n_parent,&COMP))
           {
            printf("Error to read from COMPUTERS\n");
            exit(0);
           }
          svt=COMP.ncompu;
          if((l=nnam(&svt,t_f))<0)
            {
             printf("Error to get WS name\n");
             exit(0);
            }
          *(buf_+l+svt)=0;
          printf("      %s from %s Base %d Size %ld\n",
             M_array[i].relnam, buf_+l, M_array[i].dbti,  M_array[i].length);
         }
      }
    printf("****    MIL 1553 buses loading:\n");
    for(j=0;j<M_index2;j++)
      printf("%d.    %s BC=%d Loading=%d bytes\n",j+1,bc_mil[j].ds_name,bc_mil[j].BC,bc_mil[j].length);
    printf("======  Total Equipment Controllers SSUDA DB size = %ld ======\n",Sum_total);
   }


