/*
	:          WS_lall
	:      ----------------
	:  1. Send own net address to vt_tl of FE's
	:  2. Accept request from EC to initialise SSUDA and tasks
	:  3. Accept request from FE to initialise SSUDA
	:  4. Accept CL from VPV
*/

#include "/usr/usera/voevodin/remote/ccydalib/ccydalib.h"
#include <errno.h>
#include <stdio.h>
#include <sys/time.h>
#include <sys/signal.h>
#include <sys/types.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/wait.h>

extern int bptr;

static struct comput COMP;      /* COMPUTERS tuple */
static struct sddbd to_ddbd;	/* DDBD tuple */
static pid_t pid;
static union wait status1;
static union in_ou
  {
   struct DDBD_rwr_pac out_pckt;
   unsigned char pac[sizeof(struct DDBD_rwr_pac)];
  } bbo;

short i16ir(),i16im(),i16ri(),i16rm(),i16mi(),i16mr();
static short f_list[3][3]={
    {0,1,2},   /*i to r,i to m*/
    {3,0,4},   /*r to i,r to m*/
    {5,6,0},   /*m to i,m to r*/
   };
static char FE_tab[max_comp];   /* max number of computer's */
int    i,j,j2,j_j,l,k,svt,s1;
socklen_t ccvt;
fd_set read_template;
struct timeval wait1;
static short tasks,ec_tsks,mc_tsks;
static char t_tasks[]={"TASKS"};
static char t_ectsks[]={"EC_TSKS"};
static char t_mctsks[]={"MC_TASKS"};

short zz;
char buf[800],buf2[270],rltab[8000];
char c,bc,rt,*pbuf,*pbu;
FILE *ioptr,*fopen();
static int fla_2;

struct EC_TSKS {
 	char  tip;
	char  prio;
	short delay;
	short to_TASKS;
	};
struct MC_TASKS {
        short to_fec;
 	char  BC;
	char  RT;
 	char  MB;
	char  MC;
	char  nam_tas[60];
	} formcload;
static struct TASKS {
	char vpvname[4];
	char exefile[40];
	short comp;
 	struct EC_TSKS to_tsks[10];
	} forload;
static struct sockaddr_in sin,svt_from;
struct hostent *hp,*gethostbyname();
char bb[160],DS_n[80],DS_n1[80];
static short BC_1,RT_1,super_flag=0;
extern char *cel_rd();
char dae_name[100];

main(int argc, char *argv[])
   {
    strcpy(dae_name, argv[0]);
    daemon_init();
    openlog("ws_lall:",LOG_CONS,LOG_USER);
    letini(0);
    Xt_al_ini();
    j=j_j= *(short *)cel_rd(0,ncoms,r_l);  /* number of computers */
    if((svt=socket(AF_INET,SOCK_DGRAM,0)) < 0)
      syslog(LOG_NOTICE,"socket:%s\n",strerror(errno));
    sin.sin_family=AF_INET;
    sin.sin_port  = htons(5998);
    if(bind(svt,(struct sockaddr*)&sin,sizeof(sin)))
      syslog(LOG_NOTICE,"bind:%s\n",strerror(errno));
    if(!set_rel(nddbd))
       {
        syslog(LOG_NOTICE,"DDBD table is absent\n\15");
        exit(0);
       }
    i=n_tup-1;			/* from tuple 2 */
    k=2;
    svt_from.sin_family=AF_INET;
    svt_from.sin_port  = htons(5998); /* to vt_tl */
    bbo.out_pckt.b_nam[0]=0;
    bbo.out_pckt.b_nam[1]=2;        /* set my net address */
    while(i--)
      {
       if(re_tu(nddbd,k,&to_ddbd))
         {
          syslog(LOG_NOTICE,"WS_lall:Error DDBD table:line=%d\n\15",k);
          goto next_g;
         }
       if(to_ddbd.n_child)
         {
          if(FE_tab[to_ddbd.n_child-1]) goto next_g;
          if(re_tu(ncoms,to_ddbd.n_child,&COMP)) goto next_g;
          if((l=nnam(&COMP.nhost,t_f))<0) goto next_g;
          *(buf_+l+COMP.nhost)=0;
          if(!(hp=gethostbyname(buf_+l)))
            {
             syslog(LOG_NOTICE,"child gethostbyname:%s\n",strerror(errno));
             goto next_g;
            }
          memcpy(&svt_from.sin_addr,hp->h_addr,hp->h_length);
          FE_tab[to_ddbd.n_child-1]=1;
          if((l=sendto(svt,bbo.out_pckt.b_nam,2,0,
            (struct sockaddr*)&svt_from,sizeof(struct sockaddr))) <0 )
              syslog(LOG_NOTICE,"sendto:%s\n",strerror(errno));
         }
next_g:
       k++;
      }    /* All FE's got my net address */
    fla_2=0;
    descr_ec_ini();
    while(1)
      {
       *(short *)(bbo.pac+2)=0;
       ccvt=sizeof(struct sockaddr);
       while((l=recvfrom(svt,bbo.pac,sizeof(struct DDBD_rwr_pac),0,
         (struct sockaddr*)&svt_from,&ccvt)) <= 0)
           syslog(LOG_NOTICE,"recvfrom:%s\n",strerror(errno));
       if(!(hp=gethostbyaddr((char*)&svt_from.sin_addr,4,svt_from.sin_family)))
         {
          syslog(LOG_NOTICE,"gethostbyaddr:%s\n",strerror(errno));
          continue;
         }
       if(bbo.pac[3]==6)  /* Stop */
         {
          if(fla_2)
            {
             syslog(LOG_NOTICE,"I got Double Stop Command\n");
            }
          else
            {
             fla_2=1;
             syslog(LOG_NOTICE,"I start Stop Operation\n");
             bbo.out_pckt.pac_tip=bbo.out_pckt.n_proces=88;
             if(sendto(svt,&bbo,8,0,(struct sockaddr*)&svt_from
               ,sizeof(struct sockaddr_in)) <0)
                  syslog(LOG_NOTICE,"sendto after Stop Command:%s\n",strerror(errno));
            }
          continue;
         }
       if(bbo.pac[3]==7)  /* Restart */
         {
          if(!fla_2)
            {
             syslog(LOG_NOTICE,"I got Start Command without Stop\n");
            }
          else
            {
             fla_2=0;
             syslog(LOG_NOTICE,"I Restart Operation %s\n",dae_name);
             bbo.out_pckt.pac_tip=bbo.out_pckt.n_proces=89;
             if(sendto(svt,&bbo,8,0,(struct sockaddr*)&svt_from
               ,sizeof(struct sockaddr_in)) <0)
                  syslog(LOG_NOTICE,"sendto after Start Command:%s\n",strerror(errno));
             daemon_restart();
            }
          continue;
         }
       if(fla_2)  /* was stop from DSC */
         continue;
       strcpy(bb,hp->h_name);
       strcpy(DS_n,hp->h_name);
       for(pid=0;pid<sizeof(bb);pid++)
         if(bb[pid]=='.')
           bb[pid]=0;
       strcpy(DS_n1,bb);   /* short VME name */
       BC_1=bbo.pac[0];
       RT_1=bbo.pac[1];
       if(!(l=namn(bb,0,t_f)))
         {
          syslog(LOG_NOTICE,"namn for %s\n",bb);
          continue;
         }
       pid=fork();
       if(pid<0)
         syslog(LOG_NOTICE,"fork:%s\n",strerror(errno));
       if(pid)
         {
          if(wait(&status1)== -1)
            syslog(LOG_NOTICE,"wait:%s\n",strerror(errno));
          continue;
         }
                       /* CHILD PROCESS */
       close(svt);
       tasks=namn(t_tasks,0,r_n);
       ec_tsks=namn(t_ectsks,0,r_n);
       mc_tsks=namn(t_mctsks,0,r_n);
       if(!tasks || !ec_tsks || !mc_tsks)
         {
          syslog(LOG_NOTICE,"System table TASKS or EC_TSKS or MC_TASKS is absent\n\15");
         }
       switch(bbo.pac[3])
         {
          case 5:
                        /* l=host number,pac[0]=bc,pac[1]=rt */
          if(bbo.pac[4])
           if(bbo.pac[4]!=1)
            {           /* load task to EC */
             if(!tasks || !ec_tsks)
               break;
             j= *(short *)cel_rd(0,tasks,r_l);  /* number of tasks */
             k=1;
             while(j--)
               {
                if(re_tu(tasks,k,forload.vpvname))
                  {
                   syslog(LOG_NOTICE,"WS_lall:error table TASKS tuple %d\n\15",k);
                   continue;
                  }
                if( *(int *)(bbo.pac+4) == *(int *)forload.vpvname)
                  {
                   forload.to_tsks[0].tip=0;
                   forload.to_tsks[0].prio=0;
                   forload.to_tsks[0].delay=0;
                   k=1;
                   while(j_j--)
                     {
                      if(re_tu(ncoms,k,&COMP))
                        {
                         syslog(LOG_NOTICE,"WS_lall:error table COMPUTER tuple %d\n\15",k);
                         continue;
                        }
                      if(bbo.pac[0]==COMP.bus_c && bbo.pac[1]==COMP.rem_t
                       && l==COMP.nhost)
                        {
                         forload.comp=k;
                         task_loader(0);
                         goto yxod;
                        }
                      ++k;
                     }
                   goto yxod;
                  }
                ++k;
               }
             break;
            }
          else           /* load to MicroController */
            {
                        /* l=host number,pac[0]=BC,pac[1]=RT,pac[5]=MB,pac[6]=MC */
                        /* pac[7]-pac[10]=prog.name in EC */
             if(!mc_tsks)
               goto yxod;
             bbo.pac[11]=0;
             j= *(short *)cel_rd(0,mc_tsks,r_l);  /* number of MC_tasks */
             k=1;
             while(j--)
               {
                if(re_tu(mc_tsks,k,&formcload))
                  {
                   syslog(LOG_NOTICE,"WS_lall:error table MC_TASKS tuple %d\n",k);
                   continue;
                  }
                if(l==formcload.to_fec && bbo.pac[0]==formcload.BC 
                 && bbo.pac[1]==formcload.RT
                  && bbo.pac[5]==formcload.MB && bbo.pac[6]==formcload.MC)
                    {
                     if((svt=socket(AF_INET,SOCK_DGRAM,0)) < 0)
                       {
                        syslog(LOG_NOTICE,"ws_lall:child:socket:%s\n",strerror(errno));
                        goto yxod;
                       }
                     sin.sin_family=AF_INET;
                     sin.sin_port  = htons(0);
                     if(bind(svt,(struct sockaddr*)&sin,sizeof(sin)))
                       {
                        syslog(LOG_NOTICE,"ws_lall:child:bind:%s\n",strerror(errno));
                        goto yxod;
                       }
                     svt_from.sin_port  = htons(5996);  /* send packet 8 */
                     ioptr=fopen(formcload.nam_tas,"rb");
                     if(ioptr==0)
                       {
                        syslog(LOG_NOTICE,"\nws_lall:CAN'T OPEN %s",buf);
                        goto yxod;
                       }
                     buf[0]=formcload.BC;
                     buf[1]=formcload.RT;
                     buf[2]=8;
/*
                     buf[3]='M';
                     buf[4]='L';
                     buf[5]='D';
                     buf[6]='R';
*/
                     buf[3]=bbo.pac[7];
                     buf[4]=bbo.pac[8];
                     buf[5]=bbo.pac[9];
                     buf[6]=bbo.pac[10];
                     buf[7]=formcload.MB;
                     buf[8]=formcload.MC;
                     buf[9]=0;                 /* not last block */
                     *(short*)(buf+10)=0;      /* offset by 16 */
mc_cyc:
                     j=0;
                     for(i=0;i<192;i++)
                       {
                        j2=fgetc(ioptr);
                        buf[14+i]=j2;
                        if(j2==EOF)
                          {
                           buf[9]=1;           /* last block */
                           break;
                          }
                        ++j;
                       }
                     *(short*)(buf+12)=j;      /* num.of data bytes */
                     j2=0;
one_more:
                     if(sendto(svt,buf,j+14,0,
                       (struct sockaddr*)&svt_from,sizeof(svt_from)) < 0 )
                         syslog(LOG_NOTICE,"ws_lall:child:sendto:%s\n",strerror(errno));
mc_wai:
                     wait1.tv_sec=30;
                     wait1.tv_usec=0;
                     FD_ZERO(&read_template);
                     FD_SET(svt,&read_template);
                     if(select(FD_SETSIZE,&read_template,(fd_set*)0,
                       (fd_set*)0,&wait1)<0)
                         goto next_bl;
                     if(FD_ISSET(svt,&read_template))
                       {
                        if((i=read(svt,buf2,20))<0)
                          syslog(LOG_NOTICE,"child:read-mc:%s\n",strerror(errno));
                        if(buf2[0]!=buf[0] ||
                          buf2[1]!=buf[1] ||
                           buf2[2]!=buf[2])
                            {
                             syslog(LOG_NOTICE,"ws_lall:load-mc:Not my reply %d=%d %d=%d %d=%d\n",
                               buf2[0],buf[0],buf2[1],buf[1],buf2[2],buf[2]);
                             goto mc_wai;
                            }
                        switch(buf2[3])
                          {
                           case 1:
        sprintf(bb,"ws_lall:Load %s to MicroController = no %s in ME-186\n",
          formcload.nam_tas,&bbo.pac[7]);
                           printf("%s\15",bb);
                           Xt_al_text(svt,bb);
                           syslog(LOG_NOTICE,"%s\n",bb);
                           goto mc_yxod;
                           case 2:       /* no read from task in ME-186 */
                           goto one_more;
                           case 0:
                           if(buf[9])
                             {
                          sprintf(bb,"File %s to MicroController %s is loaded\n",
                                formcload.nam_tas,&bbo.pac[7]);
                              printf("%s\15",bb);
                              Xt_al_text(svt,bb);
                              syslog(LOG_NOTICE,"%s\n",bb);
                              goto mc_yxod;
                             }
                           break;
                          }
                        goto next_bl;
                       }
                     sprintf(bb,"ws_lall:Time out on load %s to MicroController %s\n",
                       formcload.nam_tas,&bbo.pac[7]);
                     printf("%s\15",bb);
                     Xt_al_text(svt,bb);
                     if(j2==3)
                       {
                        sprintf(bb,"ws_lall:File %s is not loaded to MicroController %s\n",
                          formcload.nam_tas,&bbo.pac[7]);
                        printf("%s\15",bb);
                        Xt_al_text(svt,bb);
                        goto mc_yxod;
                       }
                     else
                       {
                        ++j2;
                        goto one_more;
                       }
next_bl:
                     *(short*)(buf+10) += ((j+15)/16);  /* offset by 16 */
                     if(buf[9] == 0)
                       goto mc_cyc; 
mc_yxod:
                     close(svt);
                     fclose(ioptr);
                     goto yxod;
                    }
                k++;
               }
             syslog(LOG_NOTICE,"WS_lall:Can't find file to load to MicroController \n     BC=%d RT=%d MB=%d MC=%d",bbo.pac[0]&255,bbo.pac[1]&255,bbo.pac[5]&255,
bbo.pac[6]&255,&bbo.pac[7]);
             goto mc_yxod;
            }
                	/* initialize EC if bbo.pac[4]==0 */
          super_flag=1;
          descr_ec_set(DS_n1,BC_1,RT_1,super_flag);   /* Start reload of EC */
          if(FE_tab[l-1]) /* there are global tables */
            {
             k=1;
             while(j--)
               {
                if(re_tu(ncoms,k,&COMP))
                  {
                   syslog(LOG_NOTICE,"WS_lall:error table COMPUTER tuple %d\n\15",k);
                   continue;
                  }
                if(bbo.pac[0]==COMP.bus_c && bbo.pac[1]==COMP.rem_t
                 && l==COMP.nhost)
                  {
                   if((s1=socket(AF_INET,SOCK_DGRAM,0)) < 0)
                     syslog(LOG_NOTICE,"ws_lall:child:socket:%s\n",strerror(errno));
                   sin.sin_family=AF_INET;
                   sin.sin_port  = htons(0);
                   if(bind(s1,(struct sockaddr*)&sin,sizeof(sin)))
                     syslog(LOG_NOTICE,"ws_lall:child:bind:%s\n",strerror(errno));
                   if(!(hp=gethostbyname(ss_name)))  /* SSUDA server */
                     syslog(LOG_NOTICE,"ws_lall:child:gethostbyname:%s\n",strerror(errno));
                   svt_from.sin_family=AF_INET;
                   svt_from.sin_port  = htons(5995);
                   bcopy(hp->h_addr,&svt_from.sin_addr,hp->h_length);
                   bbo.out_pckt.pac_tip=5;    /* load table to EC */
                   j2= *(short *)cel_rd(0,nddbd,r_l)-1;  /* num.of tables */
                   i=2;
                   while(j2--)
                     {
                      if(re_tu(nddbd,i,&to_ddbd))
                        {
                         syslog(LOG_NOTICE,"WS_lall:Error DDBD table:line=%d\n\15",k);
                         goto next_tu;
                        }
                      if(!to_ddbd.lena)
                        goto next_tu;
                      if(l!= to_ddbd.n_child || k!= to_ddbd.n_micro)
                        goto next_tu;
                      memcpy(bbo.out_pckt.t_nam,to_ddbd.rena,to_ddbd.lena);
                      bbo.out_pckt.t_nam[to_ddbd.lena]=0;
                      if(sendto(s1,&bbo.out_pckt,sizeof(struct DDBD_rwr_pac)
                        ,0,(struct sockaddr*)&svt_from,sizeof(svt_from)) < 0 )
                          syslog(LOG_NOTICE,"ws_lall:child:sendto:%s\n",strerror(errno));
                      wait1.tv_sec=200;
                      wait1.tv_usec=0;
                      FD_ZERO(&read_template);
                      FD_SET(s1,&read_template);
                      if(select(FD_SETSIZE,&read_template,(fd_set*)0,
                        (fd_set*)0,&wait1)<0)
                          goto next_tu;
                      if(FD_ISSET(s1,&read_template))
                        {
                         if(read(s1,buf_,256)<0)
                           syslog(LOG_NOTICE,"child:read:%s\n",strerror(errno));
                         if(*(short *)buf_)
                           {
                            sprintf(bb,"Table %s is loaded as %x\n",
                             bbo.out_pckt.t_nam,*(short *)buf_);
                            printf("%s\15",bb);
                            Xt_al_text(s1,bb);
                            syslog(LOG_NOTICE,"%s\n",bb);
                           }
                         else
                           {
                            sprintf(bb,"ws_lall:Table %s is not loaded\n",
                             bbo.out_pckt.t_nam);
                            printf("%s\15",bb);
                            Xt_al_text(s1,bb);
                            syslog(LOG_NOTICE,"%s\n",bb);
                            super_flag=2;
                            descr_ec_set(DS_n1,BC_1,RT_1,super_flag);   /* No table */
                            goto yxod;
                           }
                         goto next_tu;
                        }
                      sprintf(bb,"WS_lall:Time out on table %s\n",
                        bbo.out_pckt.t_nam);
                      printf("%s\15",bb);
                      Xt_al_text(s1,bb);
                      syslog(LOG_NOTICE,"%s\n",bb);
                      super_flag=2;
                      descr_ec_set(DS_n1,BC_1,RT_1,super_flag);   /* No table */
                      goto yxod;
next_tu:
                      ++i;
                     }
                   goto load_task;
                  }
                ++k;
               }
            }
load_task:
          if(!tasks || !ec_tsks)
            goto yxod;
          k=1;
          while(j_j--)
            {
             if(re_tu(ncoms,k,&COMP))
               {
                syslog(LOG_NOTICE,"WS_lall:error table COMPUTER tuple %d\n\15",k);
                continue;
               }
             if(bbo.pac[0]==COMP.bus_c && bbo.pac[1]==COMP.rem_t
              && l==COMP.nhost)
               {
                j= *(short *)cel_rd(0,ec_tsks,r_l);  /* number of computers */
                i=1;
                while(j--)
                  {
                   if(re_tu(ec_tsks,i,&forload.comp))
                     {
                      syslog(LOG_NOTICE,"WS_lall:error table EC_TSKS tuple %d\n\15",k);
                      continue;
                     }
                   if(forload.comp==k)
                     {      /* tasks for this EC are found */
                      for(i=0;i<10;i++)
                        if(forload.to_tsks[i].to_TASKS)
                          {
                           if(re_tu(tasks,forload.to_tsks[i].to_TASKS,&forload))
                             {
                              syslog(LOG_NOTICE,"WS_lall:error table TASKS tuple %d\n\15",
                                forload.to_tsks[i].to_TASKS);
                              continue;
                             }
                           task_loader(i);
                          }
                      goto yxod;
                     }
                   ++i;
                  }
                goto yxod;
               }
             ++k;
            }
         }
yxod:
       if(super_flag==1)
         {
          super_flag=0;
          descr_ec_set(DS_n1,BC_1,RT_1,super_flag);   /* End of reload */
         }
       close(bptr);
       exit(0);
      }
   }
static struct head {
        unsigned short dss;
        unsigned short dsp;
        unsigned short dcs;
        char prior;
        char tip;
        char nm[4];
        short peri;
        unsigned short leng;
        unsigned short dds;
        } *phead;
static struct rtit {
   unsigned short offset;
   unsigned short segm;
    } *item;
static struct task {
        unsigned short ip;
        char gost;
        } pts;
static struct shead {
  char x4d;
  char x5a;
  short lim;      /*image 512*/
  short lfi;      /*file 512 */
  short rtn;      /*num.of rel.tab.items*/
  short sh;       /*header 16*/
  short min;      /*16*/
  short max;
  short ss;
  short sp;
  short chs;
  short ip;
  short cs;
  short ofrtn;    /*offset rel.tab.*/
  short over;
   } *ph;
static struct segtab {
  char c0;
  char c1;                /* may be 80 */
  unsigned short dmax;    /* absol.addr.in par. */
  unsigned short dno;     /* related addr.in par. */
  unsigned short dmin;    /* length in par. */
  char sgn;
  char cln;
  char ovn;
  char csu;
        } *stb;
static struct pspbms {
  short of;
  char ds;
  char inter;
  char i20;     /*int 20*/
  char mem[4];
  char bs[2];   /*bytes num.in seg.*/
  char u1[2];
  char ta[4];
  char cb[4];
  char ee[4];
  char u2[58];
  char inter1;
  char i21;
  char retf;
   } psp;
static int fien,fil;
typedef struct shead *SHEAD;
typedef struct head *PHEAD;
typedef struct rtit *ITEM;
void handler(int);
static fd_set read_temp;
static struct timeval Iwait;

task_loader(num)
 short num;                      /* num - index of EC_TSKS array */
  {
    short i,j,k,l,n,ni,ncs,*ii;  /* struct TASKS is filled */
        psp.of=0;
        psp.ds=1;
        psp.inter=0xcd;
        psp.i20=0x20;
        psp.inter1=0xcd;
        psp.i21=0x21;
        psp.retf=0xcb;
        signal(SIGPIPE,handler);
        if(linum())
          {
           sprintf(bb,"ws_lall:task %s IS NOT LOADED\n\15",forload.exefile);
           syslog(LOG_NOTICE,"%s\n\15",bb);
           Xt_al_text(s1,bb);
           goto bcelo;
          }
	zz=3;
begin:
        ioptr=fopen(forload.exefile,"rb");
        if(ioptr==0)
          {
           sprintf(bb,"\nws_lall:CAN'T OPEN file %s",forload.exefile);
           syslog(LOG_NOTICE,"%s",bb);
           Xt_al_text(s1,bb);
           goto bcelo;
          }
        c=fgetc(ioptr);
        buf[0]=c;            /* record type */
        if(c != 0x4d)
          {
erf:
           syslog(LOG_NOTICE,"\nws_lall:ERR.FILE FORMAT:%s",forload.exefile);
	   goto bcelo;
          }
        ph= (SHEAD)buf;
        j=1;
        for(i=sizeof(struct shead)-1;i>0;i--)
          buf[j++]=fgetc(ioptr);
        if(ph->x4d!=0x4d || ph->x5a!=0x5a)goto erf;
        pbuf=buf+sizeof(struct shead);
        phead=(PHEAD)(buf+sizeof(struct shead));
        pts.ip=ph->ip;
        if(forload.to_tsks[num].tip & 0x80)
          pts.gost = zz;        /* GO on load */
        else
          pts.gost=0x80 | zz;   /* stop on load */
        phead->dss=ph->ss;
        phead->dsp=ph->sp;
        phead->dcs=ph->cs;
        phead->leng=ph->min +(ph->lfi<<5)-ph->sh +16+8;
c_01:
        phead->prior=forload.to_tsks[num].prio;
        phead->tip=forload.to_tsks[num].tip & 0x7f;
        c=j=0;
        for(i=4;i>0;i--)
          {
           phead->nm[j]=forload.vpvname[j];
           ++j;
          }
        if(phead->nm[0]=='#')
          pts.gost &=0x7f;     /* start after load */
        if((phead->tip & 63)==3)
          phead->peri=forload.to_tsks[num].delay;
        bcopy(phead,buf2+3,16);
        buf2[0]=bbo.pac[0];   /* BC */
        buf2[1]=bbo.pac[1];   /* RT */
        buf2[2]=4;
        if(send_bl(buf2,128))
          goto bcelo;
        receive(pbuf,&k);
        if(*pbuf!=0)
          {
           syslog(LOG_NOTICE,"ws_lall:Reply on header(type 4)=%x length %d\n\15",*pbuf,k);
           sprintf(bb,"ws_lall:task %s IS NOT LOADED\n\15",forload.exefile);
           syslog(LOG_NOTICE,"%s\n\15",bb);
           Xt_al_text(s1,bb);
           super_flag=4;
           descr_ec_set(DS_n1,BC_1,RT_1,super_flag);   /* End of reload */
           goto bcelo;
          }
        pbuf += 5;
        k= *(short*)pbuf;        /*relocation constant*/
        bcopy(&psp,buf2+3,sizeof(struct pspbms));
        buf2[2]=5;
        if(send_bl(buf2,sizeof(struct pspbms)+3))
          goto bcelo;
        i=ph->ofrtn-sizeof(struct shead);
        while(i-- >0)
          fgetc(ioptr);        /*start of rel.tab.*/
        ni=ph->rtn;            /*num.of rel.tab.items*/
        ncs=0;
        if((i=ph->rtn*4)>sizeof(rltab))
          {
           syslog(LOG_NOTICE,"ws_lall:TOO MANY RELOCATION ITEMS\n");
           sprintf(bb,"ws_lall:task %s IS NOT LOADED\n\15",forload.exefile);
           syslog(LOG_NOTICE,"%s\n\15",bb);
           Xt_al_text(s1,bb);
           super_flag=4;
           descr_ec_set(DS_n1,BC_1,RT_1,super_flag);   /* End of reload */
           goto bcelo;
          }
        pbuf=rltab;
        item =(ITEM)rltab;
        while(i-- >0)
          *pbuf++ =fgetc(ioptr);       /*rel.tab.*/
        for(i=ni;i>0;i--)
          {
           if(item->offset & 0xfff0)   /* offset inside parag. 0-15 */
             {
              item->segm += (item->offset >> 4);
              item->offset &= 0x0f;
             }
           item->offset += ((item->segm&7)<<4); /* offset inside 128 bytes */
           item->segm &= 0xfff8;                /* segment on 128 bytes blocks */
           item++;
          }
        i=(ph->sh<<4)-ph->ofrtn-(ph->rtn<<2);
        while(i--)
          fgetc(ioptr);    /*to image*/
        *(short*)buf=16;   /*from DS+256*/
        buf[2]=1;          /*as DS*/
        pbuf=buf+3;
        for(i=128;i>0;i--)
          {
           if(feof(ioptr))break;
           *pbuf++ =fgetc(ioptr);      /*first 128*/
           ++ncs;
          }
        while(ncs>0)
          {
           pbu=buf+3;
           pbuf=buf+3+128;
           for(i=128;i>0;i--)
             {
              if(feof(ioptr))break;
              *pbuf++ =fgetc(ioptr);
              ++ncs;
             }
           pbuf=buf+3+128;
           i= *(short*)buf-16;        /* 256 bytes offset to DS */
           item=(ITEM)rltab;
           for(j=ni;j>0;j--)
             {
              if((unsigned)i==item->segm)
                {
                 ii=(short*)(pbu+item->offset);
                 *ii += k;     /*relocate*/
                }
              ++item;
             }
           i=128+3;
/*
           if(ncs<128)
             i=ncs+3;
*/
           bcopy(buf,buf2+3,i);
           buf2[2]=5;
           if(send_bl(buf2,i+3))
             goto bcelo;
           for(i=128;i>0;i--)
             *pbu++ = *pbuf++;
           ncs -= 128;
           *(unsigned*)buf += 8;
          }
        bcopy(&pts,buf2+3,3);
        buf2[2]=3;
        if(send_bl(buf2,128))
          goto bcelo;
        receive(buf,&i);
        if(*buf!=0)
          {
           syslog(LOG_NOTICE,"TASK SET ERR.=%d\n",*buf);
/*
           sprintf(bb,"ws_lall:task %s IS NOT LOADED\n\15",forload.exefile);
           syslog(LOG_NOTICE,"%s\n\15",bb);
           Xt_al_text(s1,bb);
           super_flag=4;
           descr_ec_set(DS_n1,BC_1,RT_1,super_flag);
*/
           goto bcelo;
          }
        sprintf(bb,"TASK %s is loaded TO %s BC=%d RT=%d\n",
          forload.exefile,DS_n,buf2[0]&255,buf2[1]&255);
        syslog(LOG_NOTICE,"ws_lall:%s",bb);
        printf("ws_lall:%s",bb);
        Xt_al_text(s1,bb);
bcelo:
        if(svt)
          close(svt);
        if(ioptr)
          fclose(ioptr);
        return(0);
   }
receive(bl_d,dl_bl)
 char *bl_d;
 short *dl_bl;
  {
   int k;
    *bl_d=77;
    Iwait.tv_sec=20;
    Iwait.tv_usec=0;
    FD_ZERO(&read_temp);
    FD_SET(svt,&read_temp);
    k=select(FD_SETSIZE,&read_temp,(fd_set*)0,(fd_set*)0,&Iwait);
    if(k<0)
      return;
    if(FD_ISSET(svt,&read_temp))
      {
       k=recv(svt,bl_d,10,0);
       if(k <= 0)
         syslog(LOG_NOTICE,"ws_lall:receive:recv:%s\n",strerror(errno));
       return;       /* packet is accepted */
      }
    syslog(LOG_NOTICE,"ws_lall:receive:Time Out\n");
  }
send_bl(bl_d,dl_bl)
 char *bl_d;
 int dl_bl;
  {
   int cc;
   if((bl_d[0] > 8) || (bl_d[1] > 30))
     {
      syslog(LOG_NOTICE,"ws_lall:BC=%d RT=%d\n",bl_d[0]&255,bl_d[1]&255);
     }
   if((cc=send(svt,bl_d,dl_bl,0)) <= 0)
     {
      syslog(LOG_NOTICE,"ws_lall:send_bl:send:%s\n",strerror(errno));
      return(1);
     }
   if(bl_d[2]==5 )
     {
      Iwait.tv_sec=20;
      Iwait.tv_usec=0;
      FD_ZERO(&read_temp);
      FD_SET(svt,&read_temp);
      cc=select(FD_SETSIZE,&read_temp,(fd_set*)0,(fd_set*)0,&Iwait);
      if(cc<0)
        return(1);
      if(FD_ISSET(svt,&read_temp))
        {
         cc=recv(svt,bl_d+3,2,0); /* wait for last data block */
         if(cc<=0)
           {
            syslog(LOG_NOTICE,"ws_lall:send_bl:recv:%s\n",strerror(errno));
            return(1);
           }
         return(0);       /* packet is accepted */
        }
      syslog(LOG_NOTICE,"ws_lall:send_bl:recv:Time Out\n");
      return(1);
     }
   return(0);
  }
void handler(a)
 int a;
  {
   printf("ws_lall:Signal %d\n",a);
  }
linum()
  {
   short i;
    if(re_tu(ncoms,forload.comp,&COMP)) return(1);
    if(!(i=getname(buf2,100,COMP.nhost,t_f))) return(1);
    buf2[i]=0;
    if(!(hp=gethostbyname(buf2)))
      {
         syslog(LOG_NOTICE,"ws_lall:linum:gethostbyname:%s\n",strerror(errno));
       return(1);
       }

    if((svt=socket(AF_INET,SOCK_STREAM,0)) < 0)
      {
       syslog(LOG_NOTICE,"ws_lall:linum:socket:%s\n",strerror(errno));
       return(1);
       }
    bzero((char*) &sin,sizeof(sin));
    sin.sin_family=AF_INET;
    sin.sin_port  = htons(0);
    if(bind(svt,(struct sockaddr*)&sin,sizeof(sin)))
      {
       syslog(LOG_NOTICE,"ws_lall:linum:bind:%s\n",strerror(errno));
       return(1);
      }
    sin.sin_port  = htons(5997);
    bcopy(hp->h_addr,&sin.sin_addr,hp->h_length);
    if(connect(svt,(struct sockaddr *)&sin,sizeof(sin)))
      {
       syslog(LOG_NOTICE,"ws_lall:linum:connect:%s\n",strerror(errno));
       return(1);
      }
   return(0);
  }

