/**************************************************************************
   Test for 'double' values for 64-bits processor (Alpha).

   Trying to ignore signal. It is dangerously for arithmetics division.

   Argument: "f" - write to file "t.txt";
   Argument: "0" - values <= 0.
**************************************************************************/
#include <stdio.h>
#include <values.h>
#include <signal.h>

FILE *fid;
/*************************************************************************/
void T_dbl( int si )  /* si=0: value>=0;  si=1: value<=0 */
{
  union dlc
  {
    double d;
    unsigned long int l;
  } z1, z2, z3;
  int fl;
  z1.d=MINDOUBLE;
  if (si) z1.l |=0x8000000000000000L;
  fprintf( fid, "'double' type minimal: %016lx=%g\n", z1.l, z1.d );
  z2.l=0x8000000000000000L;
  do
  {
    fl=0;
    z2.l=z2.l >> 1;
    if (si) z2.l |=0x8000000000000000L;
    if (!(z2.l & 0x7ff0000000000000L))
      if ((z2.l & 0x000fffffffffffffL)) fl=1;
    fprintf( fid, "\nvalue=%016lx=%g\t-> %s", z2.l, z2.d, fl?"bad":"well" );
    z3.d=z2.d+2.e-200;  /* if bad then signal */
    fprintf(fid," z3.d=%016lx=%g ",z3.l,z3.d);
    if (si) z2.l &=~0x8000000000000000L;
  } while (z2.l != 0x0000000000000001L);
  fprintf( fid, "\nOk\n" );
}
/*************************************************************************/
void hdlr_sig( int signum )
 {
  double a;
  fprintf( fid, " -> signal %d", signum );
/*  a=1.1 +1.1;  */
 }
/*************************************************************************/
int main( int narg, char *sarg[] )
{
  int k, si=0;
  for (k=1; k<narg; k++) if (sarg[k][0] == '0') si=1;
  for (k=1; k<narg; k++) if (sarg[k][0] == 'f') fid=fopen( "t.txt", "wt" );
  if (!fid) fid=stdout;

  fprintf( fid, "'double  ' type length: %d bytes\n", sizeof( double ) );
  fprintf( fid, "'long int' type length: %d bytes\n", sizeof( long int ) );

/*  signal( SIGTRAP, hdlr_sig ); fprintf( fid, "'SIGTRAP' signal: %d\n",
SIGTRAP );
*/
  signal( SIGFPE, hdlr_sig );  fprintf( fid, "'SIGFPE' signal: %d\n",
SIGFPE );

  T_dbl( si );

  if (fid != stdout) fclose( fid );
  return 0;
}
/*************************************************************************/


