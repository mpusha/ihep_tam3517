#include <errno.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

static struct sockaddr svt_from;
static struct sockaddr_in sin;
struct hostent *hp,*gethostbyname();

FILE *ioptr,*fopen(),*fls;
int    s1,s2;
short zz;
char buf[600],buf2[270],rltab[8000];
char c,bc,rt,*pbuf,*pbu;
static short i,j,k,l,n,ni,ncs,*ii;

static struct head {
        unsigned short dss;
        unsigned short dsp;
        unsigned short dcs;
        char prior;
        char tip;
        char nm[4];
        short peri;
        unsigned short leng;
        unsigned short dds;
        } *phead;
static struct rtit {
   unsigned short offset;
   unsigned short segm;
    } *item;
static struct task {
        unsigned short ip;
        char gost;
        } pts;
static struct shead {
  char x4d;
  char x5a;
  short lim;      /*image 512*/
  short lfi;      /*file 512 */
  short rtn;      /*num.of rel.tab.items*/
  short sh;       /*header 16*/
  short min;      /*16*/
  short max;
  short ss;
  short sp;
  short chs;
  short ip;
  short cs;
  short ofrtn;    /*offset rel.tab.*/
  short over;
   } *ph;
static struct segtab {
  char c0;
  char c1;                /* may be 80 */
  unsigned short dmax;    /* absol.addr.in par. */
  unsigned short dno;     /* related addr.in par. */
  unsigned short dmin;    /* length in par. */
  char sgn;
  char cln;
  char ovn;
  char csu;
        } *stb;
static struct pspbms {
  short of;
  char ds;
  char inter;
  char i20;     /*int 20*/
  char mem[4];
  char bs[2];   /*bytes num.in seg.*/
  char u1[2];
  char ta[4];
  char cb[4];
  char ee[4];
  char u2[58];
  char inter1;
  char i21;
  char retf;
   } psp;
static int fien,fil;
typedef struct shead *SHEAD;
typedef struct head *PHEAD;
typedef struct rtit *ITEM;

main()
  {
        psp.of=0;
        psp.ds=1;
        psp.inter=0xcd;
        psp.i20=0x20;
        psp.inter1=0xcd;
        psp.i21=0x21;
        psp.retf=0xcb;
        linum();
	zz=3;
begin:
	if(!fname())exit(0);
        strcpy(rltab+3000,buf);
	if(!fopn(0))goto begin;
        if(!fls) fls=fopen("d.lst","w");
        fprintf(fls,"%s\n",buf);
        c=fgetc(ioptr);
        buf[0]=c;            /* record type */
        if(c != 0x4d)
          {
erf:
           printf("\nERR.FILE FORMAT");
           fclose(ioptr);
	   exit(0);
          }
        ph= (SHEAD)buf;
        j=1;
        for(i=sizeof(struct shead)-1;i>0;i--)
          buf[j++]=fgetc(ioptr);
        if(ph->x4d!=0x4d || ph->x5a!=0x5a)goto erf;
        pbuf=buf+sizeof(struct shead);
        phead=(PHEAD)(buf+sizeof(struct shead));
        pts.ip=ph->ip;
        pts.gost=0x80 | zz;
        phead->dss=ph->ss;
        phead->dsp=ph->sp;
        phead->dcs=ph->cs;
        phead->leng=ph->min +(ph->lfi<<5)-ph->sh +16;
c_01:
        printf("\nPRIORITY,TYPE,PROG.NAME:");
        scanf("%d",&i);
        if(getchar()!=',')goto c_01;
        phead->prior=i;
        scanf("%d",&i);
        if(getchar()!=',')goto c_01;
        phead->tip=i;
        c=j=0;
        for(i=4;i>0;i--)
          {
           if(c!='\n')
             {
              c=phead->nm[j++]=getchar();
              if(c=='\n')
              phead->nm[j-1]=' ';
             }
           else
             phead->nm[j++]=' ';
          }
        while(c!='\n')c=getchar();
        if((phead->tip & 63)==3)
          {
           printf("\nPERIOD OF RESTARTING:");
           scanf("%d",&i);
           while(getchar()!='\n') ;
           phead->peri=i;
          }
fprintf(fls,"ip=%4x dss=%4x dsp=%4x dcs=%4x leng=%4x dds=%4x\n",
  pts.ip,phead->dss,phead->dsp,phead->dcs,phead->leng,phead->dds);
        bcopy(phead,buf2+3,16);
        buf2[0]=bc;
        buf2[1]=rt;
        buf2[2]=4;
        pbuf += 5;
        k= 0;        /*relocation constant*/
        bcopy(&psp,buf2+3,sizeof(struct pspbms));
        buf2[2]=2;
        i=ph->ofrtn-sizeof(struct shead);
        while(i-- >0)
          fgetc(ioptr);        /*start of rel.tab.*/
        ni=ph->rtn;            /*num.of rel.tab.items*/
        ncs=0;
        if((i=ph->rtn*4)>sizeof(rltab))
          {
           printf("TOO MANY RELOCATION ITEMS\n");
           goto bcelo;
          }
        pbuf=rltab;
        item =(ITEM)rltab;
        while(i-- >0)
          *pbuf++ =fgetc(ioptr);       /*rel.tab.*/
        for(i=ni;i>0;i--)
          {
           if(item->offset > 0xfff0)
             {
              item->segm += ((item->offset & 0xfff0) >> 4);
              item->offset &= 0x0f;
             }
           item->offset += ((item->segm&15)<<4);
           item->segm &= 0xfff0;
           item++;
          }
        i=(ph->sh<<4)-ph->ofrtn-(ph->rtn<<2);
fprintf(fls,"sh=%d ofrtn=%d rtn=%d i=%d\n",ph->sh,ph->ofrtn,ph->rtn,i);
        while(i--)
          fgetc(ioptr);    /*to image*/
        *(short*)buf=16;   /*from DS*/
        buf[2]=1;          /*as DS*/
        pbuf=buf+3;
        for(i=256;i>0;i--)
          {
           if(feof(ioptr))break;
           *pbuf++ =fgetc(ioptr);      /*first 256*/
           ++ncs;
          }
        while(ncs>0)
          {
           pbu=buf+3;
           pbuf=buf+259;
           for(i=256;i>0;i--)
             {
              if(feof(ioptr))break;
              *pbuf++ =fgetc(ioptr);
              ++ncs;
             }
           pbuf=buf+259;
           i= *(short*)buf-16;
           item=(ITEM)rltab;
           for(j=ni;j>0;j--)
             {
              if((unsigned)i==item->segm)
                {
                 ii=(short*)(pbu+item->offset);
                 *ii += k;     /*relocate*/
                }
              ++item;
             }
           i=259;
           if(ncs<256)
             i=ncs+3;
           bcopy(buf,buf2+3,i);
           buf2[2]=5;
for(s1=0;s1<16;s1++)
  {
           fprintf(fls,"addr=%x data=",
             *(short *)(buf2+3)+s1);
   for(s2=0;s2<16;s2++)
     fprintf(fls,"%2x ",*(buf2+s1*16+s2+6)&255);
   fprintf(fls,"\n");

  }
           for(i=256;i>0;i--)
             *pbu++ = *pbuf++;
           ncs -= 256;
           *(unsigned*)buf += 16;
          }
        printf("TASK LOADED\n");
bcelo:
        if(fls)
          {
           fclose(fls);
           fls=0;
          }
        fclose(ioptr);
        exit(0);
   }
fname()
  {
   printf("File name:");
   gets(buf);
   if(!buf[0]) return(0);
   return(1);
  }

linum()
  {
  }

fopn(i)    /* i= 0-read binary
                 1-write binary
                 2-read text
                 3-write text */
 short i;
  {
        switch (i)
          {
           case 0:
           ioptr=fopen(buf,"rb");
           break;
           case 1:
           ioptr=fopen(buf,"wb");
           break;
           case 2:
           ioptr=fopen(buf,"r");
           break;
           case 3:
           ioptr=fopen(buf,"w");
          }
        if(ioptr==0)
          {
           printf("\nCAN'T OPEN %s",buf);
           return(0);
          }
        return(1);
  }

