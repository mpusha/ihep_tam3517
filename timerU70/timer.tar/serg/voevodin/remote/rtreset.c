#include <errno.h>
#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

fd_set read_template;
struct timeval wait;

int    i,j,l,k,svt,ccvt,s1;
char buf2[256],buf[256];
static struct sockaddr svt_from;
static struct sockaddr_in sin;
struct hostent *hp,*gethostbyname();

main()
   {
    printf("Host name:");
    fgets(buf2,sizeof(buf2),stdin);
    i=0;
    while(buf2[i])
      {
       if(buf2[i]=='\n')
         buf2[i]=0;
       ++i;
      }
    if(!(hp=gethostbyname(buf2)))
     {
      perror("gethostbyname");
      exit(0);
     }
    printf("bc:");
    fgets(buf2,sizeof(buf2),stdin);
    sscanf(buf2,"%d",&i);
    printf("rt:");
    fgets(buf2,sizeof(buf2),stdin);
    sscanf(buf2,"%d",&j);
    if((s1=svt=socket(AF_INET,SOCK_DGRAM,0)) < 0)
      perror("VTsocket");
    sin.sin_family=AF_INET;
    sin.sin_port  = htons(0);
    if(bind(svt,(struct sockaddr*)&sin,sizeof(sin)))
      perror("VTbind");
    sin.sin_port  = htons(5996);
    bcopy(hp->h_addr,&sin.sin_addr,hp->h_length);
    buf2[0]=i;  /* bc */
    buf2[1]=j;  /* rt */
    buf2[2]=10; /* reset */
    if((k=sendto(svt,buf2,3,0,(struct sockaddr*)&sin,sizeof(sin))) < 0)
      perror("send");
    wait.tv_sec=2;
    wait.tv_usec=0;
    FD_ZERO(&read_template);
    FD_SET(s1,&read_template);
    k=select(FD_SETSIZE,&read_template,(fd_set*)0,(fd_set*)0,&wait);
    if(k<0) 
      exit(0);
    if(FD_ISSET(svt,&read_template))
      {
       if((l=read(svt,buf,256))<0)
         perror("read");
       buf[l]=0;
       printf("Reset was done!!!\n");
      }
   }

