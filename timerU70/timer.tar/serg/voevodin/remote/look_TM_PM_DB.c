/*    14.11.2007
     загрузка без параметров     - технологические параметры
     загрузка с любым параметром - физические параметры
*/
#include "/usr/usera/voevodin/remote/ccydalib/ccydalib.h"
#include <errno.h>
#include <syslog.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <sys/time.h>

static struct glob_mem {
	struct sddbd ddbd;	/* DDBD tuple */
	char base_nam[60];	/* base name */
		/* parent table ID=0 not opened */
	  	/* child  copy  ID=0 not exist  */
	  	/* micro  copy  ID=0 not exist  */
	struct g_main glb;
      } opis;
struct tup_opis {
        unsigned short n_tup;
        unsigned short n_attr;
        unsigned short tup_len;
        unsigned short n_plan;
        unsigned char r_type;
        unsigned char r_stat;
            }  r_opis;
struct _U70_Appl {
   short next_task;        /* No. of the next task (if there is a packet) */
   char prog_name[20];     /* Name of task */
   char bmp_name[20];      /* Name of bitmap file for this task */
   char host_name[16];     /* Name of host */
   short type;             /* Type of node/task - bitmap:         */
                           /* 1 - initialisation of general appl. */
                           /* 2 - permission to access of phys. data */
                           /* 4 - permission to access of tech. data */
                           /* 8 - permission to write data to eqp. */
                           /* 16- permission to edit data  */
                           /* 32- initialisation of resident task */
                           /* 64- kill task and return to the previous menu*/
                           /* 128- there is cold copy exist */
                           /* 256- there is bitmap exist (in the directory*/
//                          /usr/users/ssuda1/work/*.bmp )
   short regimes;
   char param[60];         /* String of parameters (ASCII) for appl. */
   char P_name[20];        /* Name of table P_MAIN of phys. data */
   short plane1;           /* No. of plane for P_MAIN table */
   short tuple1;           /* No. of string for P_MAIN table */
   char T_name[20];        /* Name of table T_MAIN of tech. data */
   short plane2;           /* No. of plane for T_MAIN table */
   short tuple2;           /* No. of string for T_MAIN table */
} U70_Appl;

static short j;
int    i,l,k;
char dae_name[100];
static int bptr;
static char f_nm[]={"/usr/usera/voevodin/ddbd"},use_name[]={""};
static char f_TP[]={"_TM_"};      // Technological 
static char f_PP[]={"_PM_"};      // Physical 
static short crd[7],tb_id;
extern char *cel_rd();
static unsigned long N_tab=0,N_par=0,N_str=0;  // tables, parameters, tuples
static char *XX;
main(int argc, char ** argv)
   {
    if((bptr=open(f_nm,O_RDONLY))== -1)
      {
       printf("Err.open file %s\n",f_nm);
       exit(0);
      }
    lseek(bptr,0,SEEK_SET);
    while(read(bptr,&opis,sizeof(struct glob_mem)))
     {
      if(argc==1)
        XX=strstr(opis.ddbd.rena,f_TP);
      else
        XX=strstr(opis.ddbd.rena,f_PP);
      if( XX )  // TP/PP table
       {
        printf("%s\n",opis.ddbd.rena);
        ++N_tab;
       }
     }
    close(bptr);
    if(argc==1)
      {
       printf("Число TM таблиц =%ld\n",N_tab);
      }
    else
      {
       printf("Число PM таблиц =%ld\n",N_tab);
      }
/*
    if( (tb_id=opnglb( "U70_APPLICATIONS", "", &k ))<0)
      {
       printf("Err.open U70_APPLICATIONS = %x\n",tb_id);
       exit(0);
      }
    if(i=rlpdbl(&r_opis,tb_id))
      {
       printf("Err.rlpdbl U70_APPLICATIONS = %x\n",i);
       exit(0);
      }
    crd[2]=1;
    crd[3]=1;
    crd[4]=1;
    crd[5]=r_opis.n_attr;
    crd[6]=1;
    for(i=1;i<=r_opis.n_plan;i++)
      {
       crd[0]=crd[1]=i;
       if((k=dtrdbl(&U70_Appl,sizeof(struct _U70_Appl),crd,tb_id))<0)
         {
          printf("Err.dtrdbl U70_APPLICATIONS = %x\n",k);
          exit(0);
         }
       if(U70_Appl.prog_name[0])
        if(U70_Appl.bmp_name[0])
         ++N_str;
       printf("  %s\n",U70_Appl.bmp_name);
      }
    printf("Число BMP  =%ld\n",N_str);
*/
   }



