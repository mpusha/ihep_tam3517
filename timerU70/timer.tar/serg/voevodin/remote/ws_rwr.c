/*
                  ws_rwr
               ------------
    1.Get request opnglb from DDBD_mem
    2.Load table copies to RAM of a FE & EC
    3.Get requests on DB access
    4.Send mes.to DDBD_mem on start
    5.Stop and close everything on command from DSC.
    6.Start on command from DSC.
*/
#include "/usr/usera/voevodin/remote/ccydalib/ccydalib.h"
#include <errno.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/time.h>
#include <unistd.h>
#include <time.h>
#include <sys/signal.h>

extern int mx_ncopied;
static struct DDBD_rwr_pac reply;
static pid_t pid;

union input {
        struct DDBD_rwr_pac in_pckt;
        struct ws_rwr in_reg;
        char pac[max_gb];
       } bbo;
static struct EC_T_LO {		/* only for #NET */
	unsigned short ss_off;
	char ss_nam[20];	/* table name */
	char ss_net[8];   	/* network address */
	unsigned short ss_tup;
	unsigned short ss_at;
	unsigned short ss_lotup;
	unsigned short ss_third;
      } *opis2;
typedef struct EC_T_LO *TO_LO;
static struct EC_reldef {	/* only for #RWR */
	unsigned short offset;
	char t_nam[20];		/* table name */
	char type_pro;		/* processor type */
	char net_len;		/* length of net address */
	char net_ad[10];   	/* network address */
	unsigned short ntup;
	unsigned short nat;
	unsigned short lotup;
	unsigned short third;
      } *opis1;
short empty(),i16ir(),i16im(),i16ri(),i16rm(),i16mi(),i16mr();
static short f_list[3][3]={
    {0,1,2},   /*i to r,i to m*/
    {3,0,4},   /*r to i,r to m*/
    {5,6,0},   /*m to i,m to r*/
   };
int    i,j,l,k,m,svt,s1;
static int bptr,was_wr[num_db];
socklen_t ccvt;
short n_DB,n_TB,tab_id;
char buf2[8192],din_m[4096],bb_b[80];
static short crd[7],fla_1,fla_2;
static char f_nm[]={"/usr/usera/voevodin/                                     "};
static char tab_name[max_rel][22];
static struct sockaddr svt_from;
static struct sockaddr_in sin;
struct hostent *hp,*gethostbyname();
fd_set read_template;
struct timeval wait;
static time_t t1,t2;

extern char *cel_rd();
char dae_name[100];

main(int argc, char *argv[])
   {
    memset(tab_name,0,sizeof(tab_name));
    strcpy(dae_name, argv[0]);
    daemon_init();
    openlog("ws_rwr:",LOG_CONS,LOG_USER);
    letini(0);
    Xt_al_ini();
    for(i=0;i<num_db;i++)
      was_wr[i]=0;
    t1=time(NULL);
    fla_2=0;
/* socket to get requests */
    if((svt=socket(AF_INET,SOCK_DGRAM,0)) < 0)
      syslog(LOG_NOTICE,"socket:%s\n",strerror(errno));
    sin.sin_family=AF_INET;
    sin.sin_port  = htons(5996);
    if(bind(svt,(struct sockaddr*)&sin,sizeof(sin)))
      syslog(LOG_NOTICE,"bind:%s\n",strerror(errno));
/* socket to get replys on packet */
    if((s1=socket(AF_INET,SOCK_DGRAM,0)) < 0)
      syslog(LOG_NOTICE,"socket:%s\n",strerror(errno));
    sin.sin_port  = htons(5994);
    if(bind(s1,(struct sockaddr*)&sin,sizeof(sin)))
      syslog(LOG_NOTICE,"bind:%s\n",strerror(errno));
    if(!(hp=gethostbyname(ss_name)))
      syslog(LOG_NOTICE,"gethostbyname(%s):%s\n",ss_name,strerror(errno));
    else
      {
       memcpy(&sin.sin_addr,hp->h_addr,hp->h_length);
       sin.sin_port  = htons(5995); /* to DDBD_mem */
       reply.pac_tip=0;             /* I am starting */
       if(sendto(svt,&reply,sizeof(struct DDBD_rwr_pac),0,
         (struct sockaddr*)&sin,sizeof(struct sockaddr_in)) <0)
           syslog(LOG_NOTICE,"sendto ddbd_mem:%s\n",strerror(errno));
      }
    gethostname(f_nm+20,20);
    if((bptr=creat(f_nm,0666))== -1)
      printf("Err.open file %s - %s\n",f_nm,strerror(errno));
    while(1)
      {
       bbo.in_pckt.pac_tip=0;
       reply.glb.id_parent=reply.glb.id_child=reply.glb.id_micro=0;
       ccvt=sizeof(struct sockaddr);
       t2=time(NULL);
       if((t2-t1) > 90000)
         {
          t1=t2;
          for(i=0;i<num_db;i++)
            if(was_wr[i])
              {
               fsync(cdb[i]); /* copy to disc */
               was_wr[i]=0;
              }
         }
       while((l=recvfrom(svt,&bbo,max_gb,0,&svt_from,
         &ccvt)) <= 0)
           {
            if(l < 0 && errno == ECONNREFUSED)
              continue;
            if(fla_2)  /* was stop from DSC */
              continue;
            sprintf(bb_b,"ws_rwr:recvfrom: %d bytes from %d %d %d %d errno=%d",l
              ,svt_from.sa_data[2]&255
              ,svt_from.sa_data[3]&255
              ,svt_from.sa_data[4]&255
              ,svt_from.sa_data[5]&255,errno);
            syslog(LOG_NOTICE,"%s\n",bb_b);
            syslog(LOG_NOTICE,"%s\n",strerror(errno));
            Xt_al_text(svt,bb_b);
            reply.pac_tip=reply.n_proces=99;
            if(sendto(svt,&reply,8,0,&svt_from
              ,sizeof(struct sockaddr_in)) <0)
                 syslog(LOG_NOTICE,"sendto after recvfrom:%s\n",strerror(errno));
           }
       if(fla_2)
         {
          if(bbo.in_pckt.pac_tip == 6)
            goto dal;
          if(bbo.in_pckt.pac_tip == 7)
            goto dal;
          continue;
         }
dal:
       fla_1=0;  /* 1 ==> new table was opened, so write current state to file */
       cur_type=bbo.in_pckt.n_proces;
       reply.n_que=bbo.in_pckt.n_que;
       switch(bbo.in_pckt.pac_tip&255)
         {
          case 1: 	/* opnglb */
          reply.pac_tip=11;
          if(!cdb[bbo.in_pckt.bd_num])
            if(i=inidbl(bbo.in_pckt.bd_num))
              {
er_ex:
               reply.glb.id_parent=0;
               reply.glb.id_child=i;   /* error code */
               if(my_type != cur_type)
                 preob16(&reply.glb.id_child,my_type,cur_type);
               break;
              }
          memcpy(reply.t_nam,bbo.in_pckt.t_nam,sizeof(reply.t_nam));
          if(!(l=namn(bbo.in_pckt.t_nam,bbo.in_pckt.bd_num,r_n)))
            {
             i=0x8041;
             goto er_ex;
            }
          for(j=0;j<max_rel;j++)
            if(rtab[j].rel_num==l && rtab[j].ndb==bbo.in_pckt.bd_num)
             {
              memcpy(&bbo.in_pckt.glb.tab_inf,&rtab[j].re_to_re,sizeof(struct relis)-sizeof(struct relref));
              memcpy(&reply.glb.tab_inf,&bbo.in_pckt.glb.tab_inf,sizeof(struct relis));
              goto lo_cop; 
             }
          for(j=0;j<max_rel;j++)
            if(rtab[j].rel_num==0)goto ec_fr;
          i=0x8010;
          goto er_ex;
ec_fr:
          fla_1=1;
          memcpy(&tab_name[j][0],bbo.in_pckt.t_nam,22);
          rtab[j].nus=1;	/* owner number 1 */
          rtab[j].ndb=cur_db=bbo.in_pckt.bd_num;
          rtab[j].rel_num=l;
          patc=(PATC)cel_rd(cur_db,l,r_d);
          rtab[j].dat_bl=to_cat[cur_db].rel_dat_b+patc->alb;
          rtab[j].dat_off=patc->alo;
          rtab[j].dat_len=patc->ald;
          patc=(PATC)cel_rd(cur_db,l,a_l);
          rtab[j].attr_bl=to_cat[cur_db].rel_at_b+patc->alb;
          rtab[j].attr_of=patc->alo;
          rtab[j].attr_len=patc->ald;
          p3=(P3)cel_rd(cur_db,l,r_l);
          memcpy(&bbo.in_pckt.glb.tab_inf,p3,sizeof(struct relis)-sizeof(struct relref));
          memcpy(&reply.glb.tab_inf,&bbo.in_pckt.glb.tab_inf,sizeof(struct relis));
          memcpy(&rtab[j].re_to_re,&bbo.in_pckt.glb.tab_inf,sizeof(struct relis));
          p3= &rtab[j].re_to_re;
          if(p3->rtype&1)
            {
             redbl(cdb[cur_db],rtab[j].attr_bl,buf_,sizeb);
             patli=(PATLI)(buf_ + rtab[j].attr_of);
             p3->nsub=patli->adli;  /* attr.length for matrix */
            }
lo_cop:
          reply.glb.id_parent=j+1;         /* not 0 */
          if(rtab[j].re_to_re.rtype & 16)  /* child copy */
            {
             if(DB_TB_ini()) break;
             send_to_FE();
            }
          if(rtab[j].re_to_re.rtype & 128)  /* micro copy */
            {
             if(!(rtab[j].re_to_re.rtype & 16)) /* DB_TB_ini was done ? */
               if(DB_TB_ini()) break;
             send_to_EC();
            }
          break;
          case 2:	/* DB transaction up to max_gb bytes */
          cur_type=bbo.in_reg.n_proc;
          bbo.in_reg.coord[6]=0;      /* local DB */
          if(i=setdbl(bbo.in_reg.n_q&255))
            {
dbl_rep: 
             if(my_type != cur_type)
               preob16(&i,my_type,cur_type);
             bbo.in_reg.coord[0] =i;
             bbo.in_reg.func=1;       /* reply */
             if(sendto(svt,&bbo.in_reg.func,8,0,&svt_from,
              sizeof(sin)) < 0)
               {
                sprintf(bb_b,"ws_rwr:reply:sendto:to %d %d %d %d errno=%d"
                  ,svt_from.sa_data[2]&255
                  ,svt_from.sa_data[3]&255
                  ,svt_from.sa_data[4]&255
                  ,svt_from.sa_data[5]&255,errno);
                Xt_al_text(svt,bb_b);
                syslog(LOG_NOTICE,"%s\n",bb_b);
                syslog(LOG_NOTICE,"%s\n",strerror(errno));
               }
             continue;
            }
          if((unsigned short)bbo.in_reg.buf_size > max_gb)
            bbo.in_reg.buf_size=max_gb;
          switch(bbo.in_reg.func&255) /* function */
            {
             case 0:    /* dtrdbl */
             memcpy(crd,bbo.in_reg.coord,sizeof(crd));
             if((i=mydtrdbl(&bbo.in_reg.coord[0],bbo.in_reg.buf_size,
               crd,bbo.in_reg.tbl_id-1)))
                 goto dbl_rep;
             i=mx_ncopied;
bib_rep:
             bbo.in_reg.func=3;       /* last data */
             bbo.in_reg.tbl_id =i;
             bbo.in_reg.buf_size =0;  /* offset */
             if(my_type != cur_type)
               preob16(&bbo.in_reg.tbl_id,my_type,cur_type);
             if(sendto(svt,&bbo.in_reg.func,i+5,0,&svt_from,sizeof(sin)) < 0)
               syslog(LOG_NOTICE,"dtrdbl:sendto:%s\n",strerror(errno));
             break;
             case 1:    /* dtwdbl */
             i=mydtwdbl(bbo.pac+sizeof(struct ws_rwr),bbo.in_reg.buf_size,
               bbo.in_reg.coord,bbo.in_reg.tbl_id-1);
             goto dbl_rep;
             case 2:    /* adirdbl */
             i=adirdbl();
             goto dbl_rep;
             case 3:    /* dirdbl  */
             i=dirdbl();
             goto dbl_rep;
             case 4:    /* rdirdbl */
             i=rdirdbl();
             goto dbl_rep;
             case 5:    /* tdirdbl */
             i=tdirdbl();
             goto dbl_rep;
             case 6:    /* txrdbl */
             i=(bbo.in_reg.tbl_id>>8)&0xff; /* dictionary */
             j=bbo.in_reg.tbl_id&0xff;      /* text number */
	     if(!(i=getname(bbo.in_reg.coord,512,j,i)))
               goto dbl_rep;
             goto bib_rep;
             case 7:    /* reddbl */
             i=reddbl(bbo.in_reg.buf_size,bbo.in_reg.tbl_id-1);
             goto dbl_rep;
             case 8:    /* rlpdbl */
             i=0x8000;
             goto dbl_rep;
             case 9:    /* tupdbl */
             if((i=tupdbl(bbo.in_reg.coord,bbo.in_reg.buf_size,
               bbo.in_reg.coord[0],bbo.in_reg.tbl_id-1)) <0 )
                 goto dbl_rep;
             goto bib_rep;
             case 10:   /* atrdbl */
             if((i=atrdbl(bbo.in_reg.coord,bbo.in_reg.buf_size,
               bbo.in_reg.coord[0],bbo.in_reg.tbl_id-1)) <0 )
                 goto dbl_rep;
             if(my_type != cur_type)
                preob16(&bbo.in_reg.coord[1],my_type,cur_type);
             i += 4;
             goto bib_rep;
            }
          continue;
          case 3:	/* initialize table in FE & EC */
          reply.pac_tip=13;
          if(DB_TB_ini()) break;  /* n_DB,n_TB,reply.tab_inf are set */
          send_to_FE();
          send_to_EC();
          break;
          case 4:	/* initialize table in FE */
          reply.pac_tip=14;
          if(DB_TB_ini()) break;
          send_to_FE();
          break;
          case 5:	/* initialize table in EC */
          reply.pac_tip=15;
          if(DB_TB_ini()) break;
          send_to_EC();
          break;
          case 6:	/* stop till start */
          if(fla_2)
            {
             syslog(LOG_NOTICE,"I got Double Stop Command\n");
            }
          else
            {
             fla_2=1;
             syslog(LOG_NOTICE,"I start to Stop Operation\n");
             reply.pac_tip=reply.n_proces=88;
             if(sendto(svt,&reply,8,0,&svt_from
               ,sizeof(struct sockaddr_in)) <0)
                  syslog(LOG_NOTICE,"sendto after Stop Command:%s\n",strerror(errno));
            }
          continue;
          case 7:	/* start after stop */
          if(!fla_2)
            {
             syslog(LOG_NOTICE,"I got Start Command without Stop\n");
            }
          else
            {
             fla_2=0;
             syslog(LOG_NOTICE,"I Restart Operation %s\n",dae_name);
             reply.pac_tip=reply.n_proces=89;
             if(sendto(svt,&reply,8,0,&svt_from
               ,sizeof(struct sockaddr_in)) <0)
                  syslog(LOG_NOTICE,"sendto after Start Command:%s\n",strerror(errno));
             daemon_restart();
            }
          continue;
          default:
          sprintf(bb_b,"ws_rwr:Not my packet:%d len:%d %d %d %d %d %d %d %d %d from=>%d %d %d %d",
            bbo.in_pckt.pac_tip&255,l
            ,bbo.pac[0]&255,bbo.pac[1]&255,bbo.pac[2]&255,bbo.pac[3]&255
            ,bbo.pac[4]&255,bbo.pac[5]&255,bbo.pac[6]&255,bbo.pac[7]&255
            ,svt_from.sa_data[2]&255
            ,svt_from.sa_data[3]&255
            ,svt_from.sa_data[4]&255
            ,svt_from.sa_data[5]&255
             );
          Xt_al_text(svt,bb_b);
          syslog(LOG_NOTICE,"%s\n",bb_b);
          reply.pac_tip=reply.n_proces=99;
          break;
         }
       cur_type=bbo.in_pckt.n_proces;
       if(my_type != cur_type)
         {
          preob16(&reply.glb.tab_inf.ntup,my_type,cur_type);
          preob16(&reply.glb.tab_inf.nat,my_type,cur_type);
          preob16(&reply.glb.tab_inf.lotup,my_type,cur_type);
          preob16(&reply.glb.tab_inf.third,my_type,cur_type);
         }
       if(sendto(svt,&reply,sizeof(struct DDBD_rwr_pac),0,&svt_from
         ,sizeof(struct sockaddr_in)) <0)
           syslog(LOG_NOTICE,"sendto:%s\n",strerror(errno));
       if(fla_1)
         {
          lseek(bptr,0,SEEK_SET);
          write(bptr,tab_name,sizeof(tab_name));
          write(bptr,&rtab[0],sizeof(rtab));
         }
      }
   }
DB_TB_ini()
   {
    reply.n_que=bbo.in_pckt.n_que;
    n_DB=bbo.in_pckt.bd_num;
    if(!cdb[n_DB])
      {
       cdb[n_DB]=fope(bbo.in_pckt.b_nam);
       redbl(cdb[n_DB],1,&to_cat[n_DB],sizeof(struct cata));
      }
    if(!(n_TB=namn(bbo.in_pckt.t_nam,n_DB,r_n)))
      {
       syslog(LOG_NOTICE,"No table:%s\n",bbo.in_pckt.t_nam);
       return(1);
      }
   p3=(P3)cel_rd(n_DB,n_TB,r_l);
   memcpy(&reply.glb.tab_inf,p3,sizeof(struct relis)-sizeof(struct relref));
   return(0);
   }
send_to_FE()
  {
   cur_type=bbo.in_pckt.glb.tab_inf.nexlis.nrt; /* child processor type */
   buf2[0]=buf2[1]=0;                           /* load table */
   buf2[2]=7;                                   /* table in FE */
   send_real(4000);
   reply.glb.id_child=tab_id;
  }
send_real(pacsize)
 int pacsize;
  {
   int i,j,l,ii;
   opis2=(TO_LO)(buf2+3);
   opis2->ss_off=0;
   tab_id=0;
   memcpy(opis2->ss_nam,bbo.in_pckt.t_nam,20);
   memcpy(&opis2->ss_tup,&reply.glb.tab_inf,8);
   if(my_type != cur_type)
     {
      preob16(&opis2->ss_tup,my_type,cur_type);
      preob16(&opis2->ss_at,my_type,cur_type);
      preob16(&opis2->ss_lotup,my_type,cur_type);
      preob16(&opis2->ss_third,my_type,cur_type);
     }
   i=3+sizeof(struct EC_T_LO);
   j=reply.glb.tab_inf.nat;
   if(j > sizeof(din_m)/2)
     {
      sprintf(bb_b,"Too much attributes = %d table %s\n",j,opis2->ss_nam);
      syslog(LOG_NOTICE,"%s\n",bb_b);
      Xt_al_text(svt,bb_b);
      j=sizeof(din_m)/2;
     }
   l=0;
   patc=(PATC)cel_rd(n_DB,n_TB,a_l);
   block= to_cat[n_DB].rel_at_b + patc->alb;
   offs = patc->alo;
   redbl(cdb[n_DB],block,buf_,size2b);
   while(j--)
     {
      *(short *)(din_m+l)= *(short *)(buf2+i)= *(short *)(buf_+offs);
      i += 2;
      l += 2;
      offs += sizeof(struct atli);
      if(offs >= sizeb)
        {
         block += offs/sizeb;
         offs %= sizeb;
         redbl(cdb[n_DB],block,buf_,size2b);
        }
     }
   if(wri_b(i))
     goto reterr;
   tab_id = *(short *)(buf_+4);
   k=reply.glb.tab_inf.ntup*reply.glb.tab_inf.third; /* num.of tuples */
   l=1;
   while(l<=k)
     {
      i=25;   /* to buf2 behind name */
tu_eche:
      if(re_tu1(n_TB,l,buf2+i))
        {
         syslog(LOG_NOTICE,"ws_rwr:err.read %d tuple\n",l);
         tab_id=0;
         goto reterr;
        }
      i += pr_dat(buf2+i,reply.glb.tab_inf.nat,my_type,cur_type);
      ++l;
      if(i<pacsize && l<=k)
         goto tu_eche;
/*      if(i > (pacsize+25))
        {
         ii=(i-25)/2;
         if(wri_b(ii+25))
           goto reterr;
         memcpy(buf2+25,buf2+ii+25,i-25-ii);
         if(wri_b(i-ii))
           goto reterr;
         continue
        }
*/
      if(wri_b(i)) goto reterr;
      if(tab_id != *(short *)(buf_+4))
        {
         syslog(LOG_NOTICE,"ws_rwr:table %s = %s BC=%d RT=%d tab_id %x = %x\n",
           bbo.in_pckt.t_nam,opis2->ss_nam,buf2[0]&255,buf2[1]&255,
            tab_id,*(short *)(buf_+4));
         tab_id=0;
         goto reterr;
        }
      fla_1=1;
     }
reterr:
   return(0);
  }
send_to_EC()
  {
   cur_type=bbo.in_pckt.glb.tab_inf.nexlis.nra; /* microprocessor type */
   buf2[0]=bbo.in_pckt.glb.BC;                  /* bc */
   buf2[1]=bbo.in_pckt.glb.RT;                  /* rt */
   buf2[2]=9;                                   /* open table */
   send_real(200);
   reply.glb.id_micro=tab_id;
  }
set_rel1(nre)
  short nre;
   {
       if(!nre)return(0);
       p3=(P3)cel_rd(n_DB,nre,r_l);
       n_tup=p3->ntup;
       l_tup=p3->lotup;
       n_plan=p3->third;
       patc=(PATC)cel_rd(n_DB,nre,r_d);
       return(1);
   }
re_tu1(n_tab,n_tu,arra)
  char *arra;
  short n_tab,n_tu;
   {
    if(!set_rel1(n_tab)) return(1);	/* error */
    if(n_tu <1 || n_tu > (n_tup*n_plan)) return(1);
    block = to_cat[n_DB].rel_dat_b + patc->alb + (n_tu-1)*l_tup/sizeb;
    offs = patc->alo + (n_tu-1)*l_tup % sizeb;
    if(offs >= sizeb)
      {
       block += offs/sizeb;
       offs %= sizeb;
      }
    redbl(cdb[n_DB],block,buf_,size2b);
    memcpy(arra,buf_+offs,l_tup);
    return(0);
   }
wri_b(i)
  int i;
  {
  int nn=0;
repe:
   if(sendto(s1,buf2,i,0,(struct sockaddr*)&bbo.in_pckt.glb.child,
    sizeof(struct sockaddr_in)) <0)
     {
      syslog(LOG_NOTICE,"sendto:%s\n",strerror(errno));
      tab_id=0;
      return(1);
     }
/* data or table & attributes descriptions are sent */
wa_repe:
   wait.tv_sec=19;
   wait.tv_usec=0;
   FD_ZERO(&read_template);
   FD_SET(s1,&read_template);
   if(select(FD_SETSIZE,&read_template,(fd_set*)0,(fd_set*)0,&wait) <0 )
     syslog(LOG_NOTICE,"select:%s\n",strerror(errno));
   if(FD_ISSET(s1,&read_template))
     {
      if(read(s1,buf_,256)<0)
        syslog(LOG_NOTICE,"read:%s\n",strerror(errno));
      if(buf_[0] != buf2[0] || buf_[1] != buf2[1] || buf_[2] != buf2[2])
        {
         tab_id=0;
         syslog(LOG_NOTICE,"ws_rwr:Not my reply(recv-send) BC=%d-%d RT=%d-%d Block=%d-%d\n",
           buf_[0]&255,buf2[0]&255,buf_[1]&255,buf2[1]&255,buf_[2]&255,buf2[2]&255);
         return(1);
        }
      if(!*(short *)(buf_+6) && buf_[3]==1)
        {              /* there is such table */
         tab_id= *(short *)(buf_+4);
         return(1);
        }
      if(buf_[3])
        {
         if(!nn)
           {
            ++nn;
            goto repe; /* try once more */
           }
         sprintf(bb_b,"ws_rwr:BC=%d RT=%d packet=%d error=%x\n",buf_[0],buf_[1],
                buf_[2],buf_[3]&255);
         syslog(LOG_NOTICE,"%s\n",bb_b);
         Xt_al_text(svt,bb_b);
         tab_id=0;
         return(1);
        }
      if(!opis2->ss_off)
        {
         if((i-3) != *(unsigned short *)(buf_+6))
           goto wa_repe; /* first request to load table */
/* printf("i=%d new_offset=%d\n",i,*(unsigned short *)(buf_+6)); */
        }
      opis2->ss_off= *(unsigned short *)(buf_+6);
     }
   else
     {
      Xt_al_text(svt,"ws_rwr:Time out on port 5994 (load table copy)\n");
      syslog(LOG_NOTICE,"ws_rwr:Time out on port 5994 (load table copy)\n");
      tab_id=0;
      return(1);
     }
   return(0);
  }
pr_dat(buf,nat,from,to)
 char *buf;
 int nat,from,to;
  {
   int j,m,i;
     i=j=0;    /* to din_m */
     for(m=0;m<nat;m++)
       {
        switch(din_m[j+1]&255)
          {
           case 2:
           case 8:
           preob16(buf+i,from,to);
           break;
           case 3:
           preob32(buf+i,from,to);
           break;
           case 4:
           fpreob32(buf+i,from,to);
           break;
           case 5:
           fpreob64(buf+i,from,to);
          }
        i += din_m[j]&255;
        j += 2;
       }
     return(i);
  }
preob16(i16,from,to)
  short *i16,from,to;
   {
    switch(f_list[from-1][to-1])
      {
       case 1:
       *i16=i16ir(*i16);
       break;
       case 2:
       *i16=i16im(*i16);
       break;
       case 3:
       *i16=i16ri(*i16);
       break;
       case 4:
       *i16=i16rm(*i16);
       break;
       case 5:
       *i16=i16mi(*i16);
       break;
       case 6:
       *i16=i16mr(*i16);
       break;
      }
   }
preob32(i32,from,to)
  int *i32;
  int from,to;
   {
    switch(f_list[from-1][to-1])
      {
       case 1:
       *i32=i32ir(*i32);
       break;
       case 2:
       *i32=i32im(*i32);
       break;
       case 3:
       *i32=i32ri(*i32);
       break;
       case 4:
       *i32=i32rm(*i32);
       break;
       case 5:
       *i32=i32mi(*i32);
       break;
       case 6:
       *i32=i32mr(*i32);
       break;
      }
   }
fpreob32(f32,from,to)
  float *f32;
  int from,to;
   {
    switch(f_list[from-1][to-1])
      {
       case 1:
       *f32=f32ir(*f32);
       break;
       case 2:
       *f32=f32im(*f32);
       break;
       case 3:
       *f32=f32ri(*f32);
       break;
       case 4:
       *f32=f32rm(*f32);
       break;
       case 5:
       *f32=f32mi(*f32);
       break;
       case 6:
       *f32=f32mr(*f32);
       break;
      }
   }
double f64ir(),f64ri(),f64im(),f64mi(),f64rm(),f64mr();
fpreob64(f64,from,to)
  double *f64;
  int from,to;
   {
    switch(f_list[from-1][to-1])
      {
       case 1:
       *f64=f64ir(*f64);
       break;
       case 2:
       *f64=f64im(*f64);
       break;
       case 3:
       *f64=f64ri(*f64);
       break;
       case 4:
       *f64=f64rm(*f64);
       break;
       case 5:
       *f64=f64mi(*f64);
       break;
       case 6:
       *f64=f64mr(*f64);
       break;
      }
   }

static int lj,num_preo;
static unsigned short work[4];
short myrw_dbl();
char ex_buf_[max_gb];

mydtrdbl(addr,b_len,coord,id_r)
 char *addr;
 unsigned short b_len,id_r,*coord;
  {
    rw_fl=0;	/* read data */
    return(myrw_dbl(addr,b_len,coord,id_r));
  }

mydtwdbl(addr,b_len,coord,id_r)
 char *addr;
 unsigned short b_len,id_r,*coord;
  {
    rw_fl=1;	/* write data */
    return(myrw_dbl(addr,b_len,coord,id_r));
  }

short myrw_dbl(addr,b_len,coord,id_r)
 char *addr;
 unsigned short b_len,id_r,*coord;
  {
   short i,j,k;
   char *ox_ax;
   int ss=0;
    if(!b_len)
      return(0x8001);
    if(!coord[0] || !coord[1] || !coord[2] ||
       !coord[3] || !coord[4] || !coord[5])
         return(0x8000);
    if(i=idrel(id_r))
      return(i);
    p3= &to_rdf->re_to_re;
    if(rw_fl && p3->nowner)
      if(to_rdf->nus != 1 || to_rdf->nus != p3->nowner)
        return(0x8050);
    if(rw_fl && !(p3->rstate&1))
      return(0x8050);
    if(coord[0]>coord[1] || coord[2]>coord[3] || coord[4]>coord[5] ||
       coord[1]>p3->third || coord[3]>p3->ntup || coord[5]>p3->nat)
        return(0x8000);
    work[0]=work[1]=work[2]=work[3]=0;
    j=coord[5]-coord[4]+1;  /* j=num. of columns */
    if(j > sizeof(din_m)/2)
      {
       syslog(LOG_NOTICE,"TOO much attributes = %d\n",j);
       j=sizeof(din_m)/2;
      }
    l=0;
    block=to_rdf->attr_bl+
      (coord[4]-1)*sizeof(struct atli)/sizeb;
    offs = to_rdf->attr_of+
      (coord[4]-1)*sizeof(struct atli)%sizeb;
    if(offs >= sizeb)
      {
       block += offs/sizeb;
       offs %= sizeb;
      }                                     // block/offset = на описание столбца в coord[4]
    redbl(cdb[cur_db],block,buf_,size2b);
    while(j--)
      {
       *(short *)(din_m+l)= *(short *)(buf_+offs);    // по байту длина/тип
       ss += din_m[l]&255;   /* length of subrow */
       l += 2;
       offs += sizeof(struct atli);
       if(offs >= sizeb)
         {
          block += offs/sizeb;
          offs %= sizeb;
          redbl(cdb[cur_db],block,buf_,size2b);
         }
      }
    ox_ax=addr;
    num_preo=(coord[3]-coord[2]+1)*(coord[1]-coord[0]+1); /* num. of rows */
    if(rw_fl && my_type!=cur_type)
      {
       i=0;
       while(num_preo--)
         {
          if((i+ss) > b_len) break;
          i += pr_dat(ox_ax+i,coord[5]-coord[4]+1,cur_type,my_type);
         }
      }
    if(coord[4]==1 && coord[5]==p3->nat)      // все столбцы
     {
      if(coord[2]==1 && coord[3]==p3->ntup)   // все строки
        {
         lj=(long)p3->ntup*p3->lotup*(coord[1]-coord[0]+1);
         if(lj>max_rw)
           return(0x80a0);
         k=work[3]=lj;	/* data length */
        }
      else
        {
         lj=(long)p3->lotup*(coord[3]-coord[2]+1);
         if(lj>max_rw)
           return(0x80a0);
	 work[2]=lj;      	/* data length inside plane */
         work[3]=coord[0];	/* current plane */
        }
     }
    else
      {
       work[1]=fi_at(coord[4],work);	/* work[0]=attr.offset
                                      	   work[1]=attr.length */
       if(coord[4]!=coord[5])
         {
          i=fi_at(coord[5],&j);
	  work[1]=i+j-work[0];
         }                    	/* work[1]=data length inside tuple */
       work[2]=coord[2];   	/* current tuple */
       work[3]=coord[0];    	/* current plane */
      }
    mx_ncopied=0;
    if(work[0] || work[1])
      {
by_attr:
       k=work[1];
       block=(long)(work[3]-1)*p3->ntup*p3->lotup+
             (long)(work[2]-1)*p3->lotup+
                   work[0];
      }
    else
     {
      if(work[2])
        {
by_tup:
         k=work[2];
         block=(long)(work[3]-1)*p3->ntup*p3->lotup+
               (long)(coord[2]-1)*p3->lotup;
        }
      else   	/* by planes */
        block=(long)(coord[0]-1)*p3->ntup*p3->lotup;
     }
    block += to_rdf->dat_off; 	/* block= data offset */
    i=block%sizeb;
    block=to_rdf->dat_bl+block/sizeb;
    if(cur_db!=rw_db || block!=cur_bl)
     {
      if(cur_db==rw_db && (block-1)==cur_bl)
        i += sizeb;
      else
        {
         redbl(cdb[cur_db],block,rab,size2b);
	 rw_db=cur_db;
         cur_bl=block;
        }
     }
    if(k>b_len)
      {
       k=b_len;
      }
    b_len -= k;
oth_bl:
    if((i+k)<=size2b)
      j=0;
    else  /* outside of buf */
      {
       j=i+k-size2b;
       k=size2b-i;
      }
    if(!rw_fl)
      {
       mx_ncopied += k;
       while(k--)
	 *addr++ = rab[i++];
      }
    else
      {
       while(k--)
         rab[i++]= *addr++;
       wribl(cdb[cur_db],cur_bl,rab,size2b);
       was_wr[cur_db]=1;   /* was write */
      }
    if(j)
      {
       cur_bl += 2;
       redbl(cdb[cur_db],cur_bl,rab,size2b);
       block=cur_bl;
       i=0;
       k=j;
       goto oth_bl;
      }
    if(work[0] || work[1])
     {
      if(++work[2]<=coord[3])
        goto bat;
      else
       {
        if(++work[3]>coord[1])
          goto he_bce;
        else
          {
           work[2]=coord[2];
           goto bat;
          }
       }
     }
    else
     {
      if(work[2])
       {
        if(++work[3]>coord[1])
          goto he_bce;
        else
          goto btu;
       }
      else
        goto he_bce;
     }
bat:
    if(b_len) goto by_attr;
    goto he_bce;
btu:
    if(b_len) goto by_tup;
he_bce:
    if(!rw_fl && my_type!=cur_type)
      {
       i=0;
       while(num_preo--)
         {
          if((ss+i) > mx_ncopied) break;
          i += pr_dat(ox_ax+i,coord[5]-coord[4]+1,my_type,cur_type);
         }
      }
    return(0);
  }

