#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/mman.h>


int main()
{
  int mfd;
  unsigned char *gpio4,*padconf;
  int ver,i;
  unsigned long outena_map,data_out1,data_out2, cm_fclken1_core,cm_iclken1_core;
  unsigned long debounc_en;
  unsigned long gpio_data;
  printf("Hello embedded world!!!\n");

//  if(iopl(3)!=0) { perror(strerror(errno)); return(0); } // set privelege level for I/O operation 
  mfd=open("/dev/mem",O_RDWR|O_SYNC);
  if (mfd<0) {
    perror("mem open");
    exit(1);
  }

  padconf=mmap(NULL,0x1000,PROT_READ|PROT_WRITE,MAP_SHARED,mfd,0x48002000);
  if (padconf==MAP_FAILED) {
    perror("mmap padconf");
    return(1);
  }
  gpio4=mmap(NULL,0x1000,PROT_READ|PROT_WRITE,MAP_SHARED,mfd,0x49054000);
  if (gpio4==MAP_FAILED) {
    perror("mmap gpio4");
    return(1);
  }

  close(mfd); //No need to keep mfd open after mmap
  printf("PADcf 116 117  %x\n",*(unsigned long *)(padconf+0x13C)); //gpio 116 117
  printf("PADcf 118 119  %x\n",*(unsigned long *)(padconf+0x140)); //gpio 118 119


  *(unsigned long *)(padconf+0x13C)=0x00040004; //0x00040004 0x011c011c set mode 4 on gpio 116 117 inp enable and pull up
  *(unsigned long *)(padconf+0x140)=0x011c011c; //set mode 4 on gpio 118 119 inp enable and pull up

  printf("PADcf116 117  %x\n",*(unsigned long *)(padconf+0x13C));
  printf("PADcf118 119  %x\n",*(unsigned long *)(padconf+0x140));

  
  printf("GPIO sysstat %x\n",*(unsigned long *)(gpio4+0x14));
  printf("GPIO control %x\n",*(unsigned long *)(gpio4+0x30));

  outena_map=*(unsigned long *)(gpio4+0x34);

  outena_map &= ~(1<<(117%32)); 
  *(unsigned long *)(gpio4+0x34)=outena_map;
  printf("GPIO output ena %x\n",*(unsigned long *)(gpio4+0x34));


  gpio_data = *(unsigned long *)(gpio4+0x3C);
  
  while(1) 
  {
   gpio_data |= (1<<(117%32)); 
   *(unsigned long *)(gpio4+0x3C)=gpio_data;
//usleep(1);
//   for(int j=0;j<5;j++);
   gpio_data &= ~(1<<(117%32)); 
   *(unsigned long *)(gpio4+0x3C)=gpio_data;
   gpio_data |= (1<<(117%32)); 
   *(unsigned long *)(gpio4+0x3C)=gpio_data;
usleep(1);
//   for(int j=0;j<5;j++);
   gpio_data &= ~(1<<(117%32)); 
   *(unsigned long *)(gpio4+0x3C)=gpio_data;

  //  printf("inp=%x \n",(~(*(unsigned long *)(gpio4+0x38))>>20)&0xf);//~(1<<(117%32));
  //  usleep(100); 
//    *(unsigned long *)(gpio4+0x3C)= data_out1;
  }
  munmap(gpio4,0x1000);
} 
