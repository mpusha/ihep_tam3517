#include <QSettings>
#include <QTimer>
#include <QWSServer>
#include "mainwindow.h"

#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
  QMainWindow(parent),
  ui(new Ui::MainWindow)
{
  ui->setupUi(this);
  ui->centralWidget->setVisible(false);
  //ui->Ch1Start->setEnabled(false);
  ui->Ch1Start->setDisabled(true);
  ui->Ch1Time->setText("1.000 000 c");
   setWindowFlags(Qt::FramelessWindowHint);
   setAttribute(Qt::WA_TranslucentBackground);
   setAttribute(Qt::WA_NoSystemBackground);
//   ui->Ch1Time->setStyleSheet("QPushButton { border: 2px solid #8f8f91;"
//                              "font: bold 20px; color: rgb(0,20, 200);"
//                              "font-family: Arial;"
//                              "border-radius: 16px;"
//                              "background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,"
//                              "stop: 0 #f6f7fa, stop: 1 #dadbde);"
//                              "min-width: 80px;}"
//                              "QPushButton:pressed {"
//                              "background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,"
//                              "stop: 0 #dadbde, stop: 1 #f6f7fa);}"
//                              "QPushButton:flat { border: none;}" /* для плоской кнопки границы нет */
//                              "QPushButton:default { border-color: navy;}"); /* делаем кнопку по умолчанию выпуклой */

  iniFileName=QString("/home/work/.config/IHEP/tiu70.conf");
  setTimerParameters();
  QTimer *timer = new QTimer(this);
  connect(timer, SIGNAL(timeout()), this, SLOT(setTimerParameters()));
  timer->start(10000);
  move(-9,-9);
  scrSvr=new myScrSaver;
  QWSServer::setScreenSaver(scrSvr);
  QSettings *Ini ;
  Ini = new QSettings(iniFileName,QSettings::NativeFormat);
  Ini->beginGroup("Control");
  timeOutScrSvr=Ini->value("scr_saver_time",300000).toInt();
  Ini->endGroup();
  delete Ini;
  QWSServer::setScreenSaverInterval(timeOutScrSvr);
  //QWSServer::setCursorVisible( false );
}

MainWindow::~MainWindow()
{
  delete ui;
}
void MainWindow::setTimerParameters(void)
{
  int i;
  QSettings *Ini ;
  Ini = new QSettings(iniFileName,QSettings::NativeFormat);
  QString current="TParameter";
  Ini->beginReadArray(current+"_Time");
  for(int i=0;i<24;i++){
    Ini->setArrayIndex(i);
    time[i]=Ini->value("Time",1).toDouble();
  }
  Ini->endArray();

  Ini->beginGroup(current);
  int OnOff=Ini->value("OnOffCh", 0).toInt();
  for(i=0;i<24;i++){
    OO[i]=OnOff&1;
    OnOff>>=1;
  }
  int StStA=Ini->value("StartCh0_11", 0).toInt();
  for(i=0;i<12;i++){
    Strt[i]=StStA&3;
    StStA>>=2;
  }
  int StStB=Ini->value("StartCh12_23", 0).toInt();
  for(i=12;i<24;i++){
    Strt[i]=StStB&3;
    StStB>>=2;
  }
  Ini->endGroup();
  Ini->beginGroup("Control");
  ctrl=Ini->value("ManualMode", 0).toInt();
  status=Ini->value("status",0).toInt();

  Ini->endGroup();


  //-----------------------------------------


  Ini->beginGroup("ImitatorParameters");
  int Mode=Ini->value("Mode",0).toInt();
  //int Regim=Ini->value("Regime",2).toInt();

  if(Mode==0){
    NC=Ini->value("NC_normal",0.185).toDouble();
    B1=Ini->value("B1_normal",0.225).toDouble();
    B2=Ini->value("B2_normal",0.255).toDouble();
    KC1=Ini->value("KC1_normal",2.225).toDouble();
    KC2=Ini->value("KC2_normal",7.34).toDouble();
    Tcycle=Ini->value("TCycle_normal",9.9).toDouble();
  }
  else if(Mode==1){
    NC=Ini->value("NC_short",0.185).toDouble();
    B1=Ini->value("B1_short",0.225).toDouble();
    B2=Ini->value("B2_short",0.255).toDouble();
    KC1=Ini->value("KC1_short",2.225).toDouble();
    KC2=Ini->value("KC2_short",3.5).toDouble();
    Tcycle=Ini->value("TCycle_short",5).toDouble();
  }
  else{
    NC=Ini->value("NC_user",0.185).toDouble();
    B1=Ini->value("B1_user",0.225).toDouble();
    B2=Ini->value("B2_user",0.255).toDouble();
    KC1=Ini->value("KC1_user",2.225).toDouble();
    KC2=Ini->value("KC2_user",7.34).toDouble();
    Tcycle=Ini->value("TCycle_user",9.9).toDouble();
  }
  Ini->endGroup();



  delete Ini ;

  for(i=0;i<24;i++)
    showParamOnScr(i);
// Page 1-3 down header
  if(ctrl){
    ui->label1->setText(trUtf8("Таймер не управляется СУ У70!"));
    ui->label1->setStyleSheet("QLabel {font: bold 20px; color: rgb(244,0,0);}");
    ui->label2->setText(trUtf8("Таймер не управляется СУ У70!"));
    ui->label2->setStyleSheet("QLabel {font: bold 20px; color: rgb(244,0,0);}");
    ui->label3->setText(trUtf8("Таймер не управляется СУ У70!"));
    ui->label3->setStyleSheet("QLabel {font: bold 20px; color: rgb(244,0,0);}");
    ui->ImitatorLabel->setText(trUtf8("Таймер не управляется СУ У70!"));
    ui->ImitatorLabel->setStyleSheet("QLabel {font: bold 20px; color: rgb(244,0,0);}");
  }
  else{
    ui->label1->setText(trUtf8("Таймер работает от системы управления."));
    ui->label1->setStyleSheet("QLabel {font: bold 20px; color: rgb(0,0,0);}");
    ui->label2->setText(trUtf8("Таймер работает от системы управления."));
    ui->label2->setStyleSheet("QLabel {font: bold 20px; color: rgb(0,0,0);}");
    ui->label3->setText(trUtf8("Таймер работает от системы управления."));
    ui->label3->setStyleSheet("QLabel {font: bold 20px; color: rgb(0,0,0);}");
  }
// page 4 parameters
  ui->ChINC->setText(QString("%1").arg(NC,5,'f',3,'0'));
  ui->ChIB1->setText(QString("%1").arg(B1,5,'f',3,'0'));
  ui->ChIB2->setText(QString("%1").arg(B2,5,'f',3,'0'));
  ui->ChIKC1->setText(QString("%1").arg(KC1,5,'f',3,'0'));
  ui->ChIKC2->setText(QString("%1").arg(KC2,5,'f',3,'0'));
  ui->ChITcycle->setText(QString("%1").arg(Tcycle,5,'f',3,'0'));
  QString msg=trUtf8("Ошибка");
  if((status==MESS_IMIT_IMITATION)&&(ctrl!=1)){
    msg=trUtf8("Работает имитатор");
    ui->ImitatorLabel->setStyleSheet("QLabel {font: bold 20px; color: rgb(0,0,255);}");
  }
  else if((status==MESS_OK)&&(ctrl!=1)){
    msg=trUtf8("Магнитный цикл У-70");
    ui->ImitatorLabel->setStyleSheet("QLabel {font: bold 20px; color: rgb(0,0,0);}");
  }
  if(status&MESS_TIMER_ERR){
    msg+=trUtf8(" таймера");
    ui->ImitatorLabel->setStyleSheet("QLabel {font: bold 20px; color: rgb(255,0,0);}");
  }
  if(status&MESS_IMIT_ERR){
    msg+=trUtf8(" имитатора");
    ui->ImitatorLabel->setStyleSheet("QLabel {font: bold 20px; color: rgb(255,0,0);}");
  }

  ui->ImitatorLabel->setText(msg);
  ui->centralWidget->setVisible(true);
}

void MainWindow::showParamOnScr(int i)
{
  QString st;
  QString tmp;

  switch(Strt[i]){
  case 0:
    st=trUtf8("НЦ");
  break;
  case 1:
    st=trUtf8("В2");
  break;
  case 2:
    st=trUtf8("КС1");
  break;
  case 3:
    st=trUtf8("Екр");
  break;
  }
  QList<QWidget *> widgets = findChildren<QWidget *>();
  for(int j=0,count=widgets.count();j<count;j++)
  {
    QWidget * w = widgets[j];

    QPushButton * btn = qobject_cast<QPushButton *>(w);
    if(btn){
      if((btn->objectName()==QString("Ch%1Start").arg(i+1))){
        btn->setText(st);
          if(OO[i]) btn->setEnabled(true); else btn->setEnabled(false);
      }
      if((btn->objectName()==QString("Ch%1Time").arg(i+1))){
        tmp=QString("Ch%1=%2").arg(i+1).arg(time[i],8,'f',6,'0');
        if(i>8) tmp=tmp.insert(10," "); else tmp=tmp.insert(9," ");
        btn->setText(tmp);
        if(OO[i]) btn->setEnabled(true); else btn->setEnabled(false);
      }
    }
  }
}
