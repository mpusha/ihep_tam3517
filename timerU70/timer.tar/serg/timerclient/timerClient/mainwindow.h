#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "myscrsaver.h"

#define MESS_OK             0
#define MESS_TIMER_ERR      1
#define MESS_TIMER_MANUAL   2
#define MESS_IMIT_ERR       4
#define MESS_IMIT_IMITATION 8

namespace Ui {
class MainWindow;
}
class MainWindow : public QMainWindow
{
  Q_OBJECT
  
public:
  explicit MainWindow(QWidget *parent = 0);
  ~MainWindow();
  QString iniFileName;
  void setParamVisual(int i);
  void showParamOnScr(int i);
  myScrSaver *scrSvr;
public slots:
  void setTimerParameters(void);
private:
  Ui::MainWindow *ui;
  double time[24];
  int Strt[24],OO[24],ctrl,status;
  double NC,B1,B2,KC1,KC2,Tcycle;
  int timeOutScrSvr;
};

#endif // MAINWINDOW_H
